# Dummy file to preclude import errors
# Should be reimplemented for MicroPython
# Reason:
# Completely different underlying impl in MicroPython.
