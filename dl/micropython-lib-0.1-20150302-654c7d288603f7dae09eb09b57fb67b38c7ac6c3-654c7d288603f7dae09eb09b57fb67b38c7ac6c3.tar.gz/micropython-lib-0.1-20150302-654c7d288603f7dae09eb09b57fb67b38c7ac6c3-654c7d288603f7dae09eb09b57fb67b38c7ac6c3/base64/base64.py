def encodebytes():
    raise NotImplementedError

def b64encode():
    raise NotImplementedError
