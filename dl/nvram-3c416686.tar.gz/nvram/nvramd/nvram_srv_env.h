#ifndef NVRAM_SRV_ENV_H
#define NVRAM_SRV_ENV_H

void __nvram_init(int index);
void __nvram_close(int index);
int __nvram_get_flash_max_len(int index);
char const *__nvram_bufget(int index, char *name);
int __nvram_bufset(int index, char *name, char *value);
void __nvram_buflist(int index);
void __nvram_buflist_to_str(int index, char *str, int str_len);
int __nvram_commit(int index);
int __nvram_clear(int index);
char *__getNvramName(int index);

#endif /* NVRAM_SRV_ENV_H */
