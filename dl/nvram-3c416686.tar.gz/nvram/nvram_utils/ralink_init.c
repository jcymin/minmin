#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include "nvram.h"
#if !defined(CONFIG_SUPPORT_OPENWRT)
#include <linux/autoconf.h>
#endif
#define DEFAULT_FLASH_ZONE_NAME "dev1"

//#define CONFIG_ANDROID
#if defined(CONFIG_ANDROID)
#define ETC_LOCATION "/data/router"
#else
#define ETC_LOCATION ""
#endif

enum dbdc_mprofile_num {
	NONE,
	DEV1_2G,
	DEV1_5G,
	DEV2_2G,
	DEV2_5G,
#if defined (RTDEV_DBDC_MODE)
	DEV2_B0_5G,	/* RTDEV_B0_5G */
#else
	DEV1_B0_5G,	/* RT2860_B0_5G */
#endif
	DEV3_B1_5G	/* WIFI3_B1_5G */
};

struct gen_cmd_mapping {
	char cmd[12];
	int nv_zone;
	int dbdc_idx;
} gen_cmd_map[] = {
	{ "dev1",	DEV1_NVRAM, NONE },
	{ "2860",	DEV1_NVRAM, NONE },
	{ "rt2860", 	DEV1_NVRAM, NONE },
	{ "dev2",	DEV2_NVRAM, NONE },
	{ "rtdev",	DEV2_NVRAM, NONE },
	{ "dev3",	DEV3_NVRAM, NONE },
	{ "wifi3",	DEV3_NVRAM, NONE },
	{ "dev1_2G_D5", DEV3_NVRAM, DEV1_2G },
	{ "dev1_5G_D5", DEV1_NVRAM, DEV1_5G },
	{ "dev1_2G_D2", DEV1_NVRAM, DEV1_2G },
	{ "dev1_5G_D2", DEV3_NVRAM, DEV1_5G },
	{ "dev2_2G",	DEV2_NVRAM, DEV2_2G },
	{ "dev2_5G", 	DEV3_NVRAM, DEV2_5G },
	{ "",		NONE, NONE }
};

int set_usage(char *aout)
{
/* Open usage for new nvram naming */
//#ifndef CONFIG_CC_OPTIMIZE_FOR_SIZE
	int i, num;

	printf("Usage example: \n");
	num = getNvramNum();
	for (i = 0; i < num; i++){
		printf("\t%s %s ", aout, getNvramName(i));
		printf("lan_ipaddr 1.2.3.4\n");
	}
//#endif
	return -1;
}

int ra_nv_set(int argc,char **argv)
{
	int index, rc;
	char *fz, *key, *value;

	if (argc == 1 || argc > 5)
		return set_usage(argv[0]);

	if (argc == 2) {
		fz = DEFAULT_FLASH_ZONE_NAME;
		key = argv[1];
		value = "";
	} else if (argc == 3) {
		fz = DEFAULT_FLASH_ZONE_NAME;
		key = argv[1];
		value = argv[2];
	} else {
		fz = argv[1];
		key = argv[2];
		value = argv[3];
	}

	if ((index = getNvramIndex(fz)) == -1) {
		printf("%s: Error: \"%s\" flash zone not existed\n", argv[0], fz);
		return set_usage(argv[0]);
	}

	nvram_init(index);
	rc = nvram_set(index, key, value);
	nvram_close(index);
	return rc;
}

int get_usage(char *aout)
{ 
/* Open usage for new nvram naming */
//#ifndef CONFIG_CC_OPTIMIZE_FOR_SIZE
	int i;

	printf("Usage: \n");
	for (i = 0; i < getNvramNum(); i++){
		printf("\t%s %s ", aout, getNvramName(i));
		printf("lan_ipaddr\n");
	}
//#endif
	return -1;
}

int ra_nv_get(int argc, char *argv[])
{
	char *fz;
	char *key;

	int index;

	if (argc != 3 && argc != 2)
		return get_usage(argv[0]);

	if (argc == 2) {
		fz = DEFAULT_FLASH_ZONE_NAME;
		key = argv[1];
	} else {
		fz = argv[1];
		key = argv[2];
	}

	if ((index = getNvramIndex(fz)) == -1) {
		printf("%s: Error: \"%s\" flash zone not existed\n", argv[0], fz);
		return get_usage(argv[0]);
	}

//fprintf(stderr, "[%s][%d] before nvram_init(%d)", __func__, __LINE__, index);
	nvram_init(index);
	printf("%s\n", nvram_bufget(index, key));
	nvram_close(index);
	return 0;
}

void gen_cert(int mode)
{
#if defined(CONFIG_RT2860V2_STA_WPA_SUPPLICANT) || defined(WAPI_SUPPORT)
	char cmd[4120];
	const char *file_name;
#endif

	nvram_init(mode);
#ifdef CONFIG_RT2860V2_STA_WPA_SUPPLICANT
	if (mode == CERT_NVRAM) {
		file_name = nvram_bufget(CERT_NVRAM, "CACLCertFile");
		if (strlen(file_name) > 0)
		{
			memset(cmd, 0, 4120);
			sprintf(cmd, "nvram_get cert CACLCert > %s", file_name);
			system(cmd);
		}
		file_name = nvram_bufget(CERT_NVRAM, "KeyCertFile");
		if (strlen(file_name) > 0)
		{
			memset(cmd, 0, 4120);
			sprintf(cmd, "nvram_get cert KeyCert > %s", file_name);
			system(cmd);
		}
	}
#endif
#ifdef WAPI_SUPPORT
	if (mode == WAPI_NVRAM) {
		file_name = nvram_bufget(WAPI_NVRAM, "ASCertFile");
		if (strlen(file_name) > 0)
		{
			memset(cmd, 0, 4120);
			sprintf(cmd, "nvram_get wapi ASCert > %s", file_name);
			system(cmd);
		}
		file_name = nvram_bufget(WAPI_NVRAM, "UserCertFile");
		if (strlen(file_name) > 0)
		{
			memset(cmd, 0, 4096);
			sprintf(cmd, "nvram_get wapi UserCert > %s", file_name);
			system(cmd);
		}
	}
#endif
}
#if defined CONFIG_EXTEND_NVRAM
void gen_cert_tr069(char *cert_type)
{
	char cmd[4120];
	const char *file_name;
	
   nvram_init(DEV1_NVRAM);
   if(strcmp(cert_type, "tr069_ca")==0){
		file_name = nvram_bufget(CONFIG2_NVRAM, "TR_CA_CERT_FILE");
		if (strlen(file_name) > 0)
		{
			memset(cmd, 0, 2048);
			sprintf(cmd, "nvram_get tr069cert TR069_CA > %s", file_name);
			system(cmd);
		}
	}else {
		
		file_name = nvram_bufget(CONFIG2_NVRAM, "TR_CLIENT_CERT_FILE");
		if (strlen(file_name) > 0)
		{
			memset(cmd, 0, 4096);
			sprintf(cmd, "nvram_get tr069cert TR069_CC > %s", file_name);
			system(cmd);
		}
	}
}
#endif

static FILE *prepare_dat_path(int mode, int dbdc_mprofile_idx, char *path)
{
	FILE *fp = NULL;
	char cmd[128];

	if (path){
		//printf("mode=%d, dbdc_idx=%d path=%s|\n", mode, dbdc_mprofile_idx, path);
		fp = fopen(path, "w+");
	}

	if(fp)
		return fp;


	memset(cmd, 0, sizeof(cmd));
	switch(dbdc_mprofile_idx){
	case DEV1_2G:
		snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/RT2860", ETC_LOCATION);
		system(cmd);
		snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/RT2860/RT2860_2G.dat", ETC_LOCATION);
		fp = fopen(cmd, "w+");
		break;
	case DEV1_5G:
		snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/RT2860", ETC_LOCATION);
		system(cmd);
		snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/RT2860/RT2860_5G.dat", ETC_LOCATION);
		fp = fopen(cmd, "w+");
		break;
	case DEV2_2G:
		snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/RT2860", ETC_LOCATION);
		system(cmd);
		snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/iNIC/iNIC_ap_2G.dat", ETC_LOCATION);
		fp = fopen(cmd, "w+");
		break;
	case DEV2_5G:
		snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/RT2860", ETC_LOCATION);
		system(cmd);
		snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/iNIC/iNIC_ap_5G.dat", ETC_LOCATION);
		fp = fopen(cmd, "w+");
		break;
#if defined (RTDEV_DBDC_MODE)
	case DEV2_B0_5G:
#else
	case DEV1_B0_5G:
#endif
		snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/", ETC_LOCATION);
		system(cmd);
		snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/MT7615A_B0_5G.dat", ETC_LOCATION);
		fp = fopen(cmd, "w+");
		break;
	case DEV3_B1_5G:
		snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/", ETC_LOCATION);
		system(cmd);
		snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/MT7615A_B1_5G.dat", ETC_LOCATION);
		fp = fopen(cmd, "w+");
		break;
	case NONE:
	default:
		if (mode == DEV1_NVRAM) {
			snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/RT2860", ETC_LOCATION);
			system(cmd);
			snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/RT2860/RT2860.dat", ETC_LOCATION);
			fp = fopen(cmd, "w+");
		} else if (mode == DEV2_NVRAM) {
			snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/iNIC", ETC_LOCATION);
			system(cmd);
			snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/iNIC/iNIC_ap.dat", ETC_LOCATION);
			fp = fopen(cmd, "w+");
#if defined (CONFIG_RT2561_AP) || defined (CONFIG_RT2561_AP_MODULE)
			snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/RT2561", ETC_LOCATION);
			system(cmd);
			snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/RT2561/RT2561.dat", ETC_LOCATION);
			fp = fopen(cmd, "w+");
#elif defined (CONFIG_RTDEV_PLC)
			snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/PLC", ETC_LOCATION);
			system(cmd);
			snprintf(cmd, sizeof(cmd), "%s/etc/PLC/plc.dat", ETC_LOCATION);
			fp = fopen(cmd, "w+");
#endif
		} else if (mode == DEV3_NVRAM) {
			snprintf(cmd, sizeof(cmd), "mkdir -p %s/etc/Wireless/WIFI3", ETC_LOCATION);
			system(cmd);
			snprintf(cmd, sizeof(cmd), "%s/etc/Wireless/WIFI3/RT2870AP.dat", ETC_LOCATION);
			fp = fopen(cmd, "w+");
		} else {
			return NULL;
		}
	}
	//printf("mode=%d, dbdc_idx=%d, cmd=%s|\n", mode, dbdc_mprofile_idx, cmd);

	return fp;
}

int gen_config(int mode, int dbdc_mprofile_idx, char *path)
{
	FILE *fp = prepare_dat_path(mode, dbdc_mprofile_idx, path);
	int  i, ssid_num = 1;
	char wmm_enable[32];

	nvram_init(mode);

	/*
	nvram_bufset(mode, "SystemName", "RalinkAP");
	nvram_bufset(mode, "ModuleName", "RT2860");
	nvram_commit(mode);
	*/

	if (NULL == fp){
		printf(" fopen failed.\n");
		return 0;
	}
	fprintf(fp, "#The word of \"Default\" must not be removed\n");
	fprintf(fp, "Default\n");

#define FPRINT_NUM(x) fprintf(fp, #x"=%d\n", atoi(nvram_bufget(mode, #x)));
#define FPRINT_STR(x) fprintf(fp, #x"=%s\n", nvram_bufget(mode, #x));
/*
#define FPRINT_STR(x) {char const* ptr; ptr=nvram_bufget(mode, #x);\
	fprintf(fp, #x"=%s\n", (strncmp(ptr,"\"\"",2) ? ptr : NULL));}
*/
	if ((DEV1_NVRAM == mode) 
		|| (DEV2_NVRAM == mode)
		|| (DEV3_NVRAM == mode)
		) {
		FPRINT_NUM(CountryRegion);
		FPRINT_NUM(CountryRegionABand);
		FPRINT_STR(CountryCode);
		FPRINT_NUM(BssidNum);
		ssid_num = atoi(nvram_get(mode, "BssidNum"));
		if (ssid_num > 16)
			ssid_num = 16;
		else if (ssid_num < 0)
			ssid_num = 0;

		FPRINT_STR(SSID);
		FPRINT_STR(SSID1);
		FPRINT_STR(SSID2);
		FPRINT_STR(SSID3);
		FPRINT_STR(SSID4);
		FPRINT_STR(SSID5);
		FPRINT_STR(SSID6);
		FPRINT_STR(SSID7);
		FPRINT_STR(SSID8);
		FPRINT_STR(SSID9);
		FPRINT_STR(SSID10);
		FPRINT_STR(SSID11);
		FPRINT_STR(SSID12);
		FPRINT_STR(SSID13);
		FPRINT_STR(SSID14);
		FPRINT_STR(SSID15);
		FPRINT_STR(SSID16);
		FPRINT_STR(WirelessMode);
		FPRINT_STR(Channel);
		FPRINT_NUM(BasicRate);
		FPRINT_NUM(BeaconPeriod);
		FPRINT_NUM(DtimPeriod);
		FPRINT_NUM(TxPower);
		FPRINT_NUM(DisableOLBC);
		FPRINT_NUM(BGProtection);
		FPRINT_NUM(TxPreamble);
		FPRINT_NUM(RTSThreshold);
		FPRINT_NUM(FragThreshold);
		FPRINT_NUM(TxBurst);

		//WmmCapable
		bzero(wmm_enable, sizeof(wmm_enable));
		snprintf(wmm_enable, 2, "%s", nvram_bufget(mode, "WmmCapable"));
		for (i = 1; i < ssid_num; i++)
		{
			snprintf(wmm_enable+strlen(wmm_enable), 3, ";%s",
					nvram_bufget(mode, "WmmCapable"));
		}
		fprintf(fp, "WmmCapable=%s\n", wmm_enable);

		FPRINT_STR(APAifsn);
		FPRINT_STR(APCwmin);
		FPRINT_STR(APCwmax);
		FPRINT_STR(APTxop);
		FPRINT_STR(APACM);
		FPRINT_STR(BSSAifsn);
		FPRINT_STR(BSSCwmin);
		FPRINT_STR(BSSCwmax);
		FPRINT_STR(BSSTxop);
		FPRINT_STR(BSSACM);
		FPRINT_STR(AckPolicy);
		FPRINT_STR(APSDCapable);
		FPRINT_STR(NoForwarding);
		FPRINT_NUM(NoForwardingBTNBSSID);
		FPRINT_STR(HideSSID);
		FPRINT_NUM(ShortSlot);
		FPRINT_NUM(AutoChannelSelect);
		FPRINT_STR(AutoChannelSkipList);
		FPRINT_NUM(ACSCheckTime);
		FPRINT_NUM(VLANID);
		FPRINT_NUM(VLANPriority);
		FPRINT_NUM(VLANTag);

		/* WPS Setting */
		FPRINT_STR(WscConfMode);
		FPRINT_STR(WscConfStatus);

		FPRINT_NUM(CSPeriod);

		/*Security Setting */
		FPRINT_STR(IEEE8021X);
		FPRINT_STR(PreAuth);
		FPRINT_STR(AuthMode);
		FPRINT_STR(EncrypType);
		FPRINT_STR(RekeyInterval);
		FPRINT_STR(RekeyMethod);
		FPRINT_STR(PMKCachePeriod);
		FPRINT_STR(WPAPSK);
		FPRINT_STR(WPAPSK1);
		FPRINT_STR(WPAPSK2);
		FPRINT_STR(WPAPSK3);
		FPRINT_STR(WPAPSK4);
		FPRINT_STR(WPAPSK5);
		FPRINT_STR(WPAPSK6);
		FPRINT_STR(WPAPSK7);
		FPRINT_STR(WPAPSK8);
		FPRINT_STR(WPAPSK9);
		FPRINT_STR(WPAPSK10);
		FPRINT_STR(WPAPSK11);
		FPRINT_STR(WPAPSK12);
		FPRINT_STR(WPAPSK13);
		FPRINT_STR(WPAPSK14);
		FPRINT_STR(WPAPSK15);
		FPRINT_STR(WPAPSK16);
		FPRINT_STR(DefaultKeyID);
		FPRINT_STR(Key1Type);
		FPRINT_STR(Key1Str);
		FPRINT_STR(Key1Str1);
		FPRINT_STR(Key1Str2);
		FPRINT_STR(Key1Str3);
		FPRINT_STR(Key1Str4);
		FPRINT_STR(Key1Str5);
		FPRINT_STR(Key1Str6);
		FPRINT_STR(Key1Str7);
		FPRINT_STR(Key1Str8);
		FPRINT_STR(Key1Str9);
		FPRINT_STR(Key1Str10);
		FPRINT_STR(Key1Str11);
		FPRINT_STR(Key1Str12);
		FPRINT_STR(Key1Str13);
		FPRINT_STR(Key1Str14);
		FPRINT_STR(Key1Str15);
		FPRINT_STR(Key1Str16);
		FPRINT_STR(Key2Type);
		FPRINT_STR(Key2Str);
		FPRINT_STR(Key2Str1);
		FPRINT_STR(Key2Str2);
		FPRINT_STR(Key2Str3);
		FPRINT_STR(Key2Str4);
		FPRINT_STR(Key2Str5);
		FPRINT_STR(Key2Str6);
		FPRINT_STR(Key2Str7);
		FPRINT_STR(Key2Str8);
		FPRINT_STR(Key2Str9);
		FPRINT_STR(Key2Str10);
		FPRINT_STR(Key2Str11);
		FPRINT_STR(Key2Str12);
		FPRINT_STR(Key2Str13);
		FPRINT_STR(Key2Str14);
		FPRINT_STR(Key2Str15);
		FPRINT_STR(Key2Str16);
		FPRINT_STR(Key3Type);
		FPRINT_STR(Key3Str);
		FPRINT_STR(Key3Str1);
		FPRINT_STR(Key3Str2);
		FPRINT_STR(Key3Str3);
		FPRINT_STR(Key3Str4);
		FPRINT_STR(Key3Str5);
		FPRINT_STR(Key3Str6);
		FPRINT_STR(Key3Str7);
		FPRINT_STR(Key3Str8);
		FPRINT_STR(Key3Str9);
		FPRINT_STR(Key3Str10);
		FPRINT_STR(Key3Str11);
		FPRINT_STR(Key3Str12);
		FPRINT_STR(Key3Str13);
		FPRINT_STR(Key3Str14);
		FPRINT_STR(Key3Str15);
		FPRINT_STR(Key3Str16);
		FPRINT_STR(Key4Type);
		FPRINT_STR(Key4Str);
		FPRINT_STR(Key4Str1);
		FPRINT_STR(Key4Str2);
		FPRINT_STR(Key4Str3);
		FPRINT_STR(Key4Str4);
		FPRINT_STR(Key4Str5);
		FPRINT_STR(Key4Str6);
		FPRINT_STR(Key4Str7);
		FPRINT_STR(Key4Str8);
		FPRINT_STR(Key4Str9);
		FPRINT_STR(Key4Str10);
		FPRINT_STR(Key4Str11);
		FPRINT_STR(Key4Str12);
		FPRINT_STR(Key4Str13);
		FPRINT_STR(Key4Str14);
		FPRINT_STR(Key4Str15);
		FPRINT_STR(Key4Str16);

		/* WAPI Security Setting */
		FPRINT_STR(WapiPsk1);
		FPRINT_STR(WapiPsk2);
		FPRINT_STR(WapiPsk3);
		FPRINT_STR(WapiPsk4);
		FPRINT_STR(WapiPsk5);
		FPRINT_STR(WapiPsk6);
		FPRINT_STR(WapiPsk7);
		FPRINT_STR(WapiPsk8);
		FPRINT_STR(WapiPsk9);
		FPRINT_STR(WapiPsk10);
		FPRINT_STR(WapiPsk11);
		FPRINT_STR(WapiPsk12);
		FPRINT_STR(WapiPsk13);
		FPRINT_STR(WapiPsk14);
		FPRINT_STR(WapiPsk15);
		FPRINT_STR(WapiPsk16);
		FPRINT_STR(WapiPskType);
		FPRINT_STR(Wapiifname);
		FPRINT_STR(WapiAsCertPath);
		FPRINT_STR(WapiUserCertPath);
		FPRINT_STR(WapiAsIpAddr);
		FPRINT_STR(WapiAsPort);
#if defined (CONFIG_DOT11W_PMF_SUPPORT)
		FPRINT_NUM(PMFMFPC);
		FPRINT_NUM(PMFMFPR);
		FPRINT_NUM(PMFSHA256);
#endif

		/* HT/VHT Setting */
		FPRINT_NUM(HT_HTC);
		FPRINT_NUM(HT_RDG);
		FPRINT_NUM(HT_LinkAdapt);
		FPRINT_NUM(HT_OpMode);
		FPRINT_NUM(HT_MpduDensity);
		FPRINT_STR(HT_EXTCHA);
		FPRINT_NUM(HT_BW);
		FPRINT_NUM(HT_AutoBA);
		FPRINT_NUM(HT_BADecline);
		FPRINT_NUM(HT_AMSDU);
		FPRINT_NUM(HT_BAWinSize);
		FPRINT_NUM(HT_GI);
		FPRINT_NUM(HT_STBC);
		FPRINT_STR(HT_MCS);
		FPRINT_NUM(HT_LDPC);
		FPRINT_NUM(HT_PROTECT);
		FPRINT_NUM(HT_TxStream);
		FPRINT_NUM(HT_RxStream);
		FPRINT_NUM(HT_DisallowTKIP);
		FPRINT_NUM(HT_BSSCoexistence);
#if defined (CONFIG_DOT11_VHT_AC)
		FPRINT_NUM(VHT_BW);
		FPRINT_NUM(VHT_Sec80_Channel);
		FPRINT_NUM(VHT_STBC);
		FPRINT_NUM(VHT_SGI);
		FPRINT_NUM(VHT_BW_SIGNAL);
		FPRINT_NUM(VHT_LDPC);
#if defined (CONFIG_G_BAND_256QAM_SUPPORT)
		FPRINT_NUM(G_BAND_256QAM);
#endif
#endif

		FPRINT_NUM(AccessPolicy0);
		FPRINT_STR(AccessControlList0);
		FPRINT_NUM(AccessPolicy1);
		FPRINT_STR(AccessControlList1);
		FPRINT_NUM(AccessPolicy2);
		FPRINT_STR(AccessControlList2);
		FPRINT_NUM(AccessPolicy3);
		FPRINT_STR(AccessControlList3);
		FPRINT_NUM(AccessPolicy4);
		FPRINT_STR(AccessControlList4);
		FPRINT_NUM(AccessPolicy5);
		FPRINT_STR(AccessControlList5);
		FPRINT_NUM(AccessPolicy6);
		FPRINT_STR(AccessControlList6);
		FPRINT_NUM(AccessPolicy7);
		FPRINT_STR(AccessControlList7);
		FPRINT_NUM(AccessPolicy8);
		FPRINT_STR(AccessControlList8);
		FPRINT_NUM(AccessPolicy9);
		FPRINT_STR(AccessControlList9);
		FPRINT_NUM(AccessPolicy10);
		FPRINT_STR(AccessControlList10);
		FPRINT_NUM(AccessPolicy11);
		FPRINT_STR(AccessControlList11);
		FPRINT_NUM(AccessPolicy12);
		FPRINT_STR(AccessControlList12);
		FPRINT_NUM(AccessPolicy13);
		FPRINT_STR(AccessControlList13);
		FPRINT_NUM(AccessPolicy14);
		FPRINT_STR(AccessControlList14);
		FPRINT_NUM(AccessPolicy15);
		FPRINT_STR(AccessControlList15);

		/* WDS Setting */
#if defined (CONFIG_WDS_SUPPORT)
		FPRINT_NUM(WdsEnable);
		FPRINT_STR(WdsPhyMode);
		FPRINT_STR(WdsEncrypType);
		FPRINT_STR(WdsList);
		FPRINT_STR(Wds0Key);
		FPRINT_STR(Wds1Key);
		FPRINT_STR(Wds2Key);
		FPRINT_STR(Wds3Key);
#endif

		/* RADIUS */
		FPRINT_STR(RADIUS_Server);
		FPRINT_STR(RADIUS_Port);
		FPRINT_STR(RADIUS_Key1);
		FPRINT_STR(RADIUS_Key2);
		FPRINT_STR(RADIUS_Key3);
		FPRINT_STR(RADIUS_Key4);
		FPRINT_STR(RADIUS_Key5);
		FPRINT_STR(RADIUS_Key6);
		FPRINT_STR(RADIUS_Key7);
		FPRINT_STR(RADIUS_Key8);
		FPRINT_STR(RADIUS_Key9);
		FPRINT_STR(RADIUS_Key10);
		FPRINT_STR(RADIUS_Key11);
		FPRINT_STR(RADIUS_Key12);
		FPRINT_STR(RADIUS_Key13);
		FPRINT_STR(RADIUS_Key14);
		FPRINT_STR(RADIUS_Key15);
		FPRINT_STR(RADIUS_Key16);
		FPRINT_STR(RADIUS_Acct_Server);
		FPRINT_NUM(RADIUS_Acct_Port);
		FPRINT_STR(RADIUS_Acct_Key);
		FPRINT_NUM(session_timeout_interval);
		FPRINT_NUM(idle_timeout_interval);
		FPRINT_STR(own_ip_addr);
		FPRINT_STR(Ethifname);
		FPRINT_STR(EAPifname);
		FPRINT_STR(PreAuthifname);

		/* DFS Setting */
		FPRINT_NUM(IEEE80211H);
#if defined (CONFIG_MT_DFS_SUPPORT)
		FPRINT_STR(RDRegion);
		FPRINT_NUM(DfsEnable);
		FPRINT_NUM(DfsCalibration);
		FPRINT_NUM(DfsFalseAlarmPrevent);
		FPRINT_NUM(DfsZeroWait);
		FPRINT_NUM(DfsZeroWaitCacTime);
		FPRINT_NUM(DfsDedicatedZeroWait);
		FPRINT_NUM(DfsTPDutyRatio);
#endif

		/* VOW Setting */
#if defined (CONFIG_RED_SUPPORT)
		FPRINT_STR(RED_Enable);
#endif /*CONFIG_RED_SUPPORT*/
		FPRINT_STR(CP_SUPPORT);
#if defined (CONFIG_VOW_SUPPORT)
		FPRINT_NUM(BW_Enable);
		FPRINT_NUM(BW_Root);
		FPRINT_STR(BW_Priority);
		FPRINT_STR(BW_Guarantee_Rate);
		FPRINT_STR(BW_Maximum_Rate);

		/* for MT7615 and later chips */
		FPRINT_STR(VOW_BW_Ctrl);
		FPRINT_STR(VOW_Airtime_Fairness_En);
		FPRINT_STR(VOW_RX_En);
		FPRINT_STR(VOW_Refill_Period);
		FPRINT_STR(VOW_Sta_VO_DWRR_Quantum);
		FPRINT_STR(VOW_Sta_VI_DWRR_Quantum);
		FPRINT_STR(VOW_Sta_BE_DWRR_Quantum);
		FPRINT_STR(VOW_Sta_BK_DWRR_Quantum);
		FPRINT_STR(VOW_WMM_Search_Rule_Band0);
		FPRINT_STR(VOW_WMM_Search_Rule_Band1);
		FPRINT_STR(VOW_Sta_DWRR_Max_Wait_Time);
		FPRINT_STR(VOW_Group_DWRR_Max_Wait_Time);

		FPRINT_STR(VOW_Group_Min_Rate);
		FPRINT_STR(VOW_Group_Max_Rate);
		FPRINT_STR(VOW_Group_Min_Ratio);
		FPRINT_STR(VOW_Group_Max_Ratio);
		FPRINT_STR(VOW_Airtime_Ctrl_En);
		FPRINT_STR(VOW_Rate_Ctrl_En);
		FPRINT_STR(VOW_Group_Min_Rate_Bucket_Size);
		FPRINT_STR(VOW_Group_Max_Rate_Bucket_Size);
		FPRINT_STR(VOW_Group_Min_Airtime_Bucket_Size);
		FPRINT_STR(VOW_Group_Max_Airtime_Bucket_Size);
		FPRINT_STR(VOW_Group_Backlog);
		FPRINT_STR(VOW_Group_Max_Wait_Time);
		FPRINT_STR(VOW_Group_DWRR_Quantum);
		
		FPRINT_STR(VOW_WATF_Enable);
		FPRINT_STR(VOW_WATF_Q_LV0);
		FPRINT_STR(VOW_WATF_Q_LV1);
		FPRINT_STR(VOW_WATF_Q_LV2);
		FPRINT_STR(VOW_WATF_Q_LV3); 
		FPRINT_STR(VOW_WATF_MAC_LV0);
		FPRINT_STR(VOW_WATF_MAC_LV1);
		FPRINT_STR(VOW_WATF_MAC_LV2);
		FPRINT_STR(VOW_WATF_MAC_LV3);

		FPRINT_STR(VOW_STA_FRR_QUANTUM); /* for Fast round robin */
#endif /* (CONFIG_VOW_SUPPORT) */

#if defined (CONFIG_LINUX_NET_TXQ_SUPPORT)
		FPRINT_STR(NET_TXQ_LEN);	/* configure queue-discipline queue length */
#endif /* (CONFIG_LINUX_NET_TXQ_SUPPORT) */

		/* BF */
		FPRINT_NUM(ITxBfEn);
		FPRINT_NUM(ETxBfEnCond);
		FPRINT_NUM(BandNoBf);

		/* Other Feature */
		FPRINT_STR(WHNAT);
#if defined (CONFIG_DBDC_MODE)
		FPRINT_NUM(DBDC_MODE);
#endif
		FPRINT_NUM(GreenAP);
		FPRINT_NUM(PcieAspm);
		//Radio On/Off
		if (atoi(nvram_bufget(mode, "RadioOff")) == 1)
			fprintf(fp, "RadioOn=0\n");
		else
			fprintf(fp, "RadioOn=1\n");			
#if defined (CONFIG_ICAP_SUPPORT)
		FPRINT_NUM(IcapMode);
#endif
		FPRINT_NUM(IgmpSnEnable);
		FPRINT_NUM(ThermalRecal);
		FPRINT_NUM(PowerUpenable);
		FPRINT_STR(PowerUpCckOfdm);
		FPRINT_STR(PowerUpHT20);
		FPRINT_STR(PowerUpHT40);
		FPRINT_STR(PowerUpVHT20);
		FPRINT_STR(PowerUpVHT40);
		FPRINT_STR(PowerUpVHT80);
		FPRINT_STR(PowerUpVHT160);
		FPRINT_NUM(SKUenable);
		FPRINT_NUM(PERCENTAGEenable);
		FPRINT_NUM(BFBACKOFFenable);
		FPRINT_NUM(CalCacheApply);
#if defined (CONFIG_EASY_SETUP_SUPPORT)
		FPRINT_STR(FtSupport);
#else
		FPRINT_NUM(FtSupport);
#endif
		FPRINT_STR(RRMEnable);
		FPRINT_STR(EDCCAEnable);
		FPRINT_NUM(E2pAccessMode);


		FPRINT_NUM(AutoProvisionEn);
		FPRINT_NUM(FreqDelta);
		FPRINT_STR(ChannelGrp);
		FPRINT_STR(FixedTxMode);
		FPRINT_STR(EthConvertMode);
		FPRINT_NUM(LinkTestSupport);
		FPRINT_NUM(CarrierDetect);
		FPRINT_STR(PreAntSwitch);
		FPRINT_NUM(PhyRateLimit);
		FPRINT_NUM(DebugFlags);
		FPRINT_NUM(MUTxRxEnable);
		FPRINT_NUM(FineAGC);
		FPRINT_NUM(StreamMode);
		FPRINT_STR(StreamModeMac0);
		FPRINT_STR(StreamModeMac1);
		FPRINT_STR(StreamModeMac2);
		FPRINT_STR(StreamModeMac3);

		FPRINT_NUM(StationKeepAlive);
#if defined (CONFIG_MAP_SUPPORT)
		FPRINT_STR(MAP_Enabled);
		FPRINT_STR(MAP_Turnkey);
		FPRINT_STR(MAP_Ext);
#endif
#if defined (CONFIG_EASY_SETUP_SUPPORT)
		FPRINT_STR(EzEnable);
		FPRINT_STR(EzConfStatus);
		FPRINT_STR(EzGroupID);
		FPRINT_STR(EzGenGroupID);
		FPRINT_STR(EzOpenGroupID);
		FPRINT_STR(EzPushBW);
		FPRINT_STR(EzDefaultSsid);
		FPRINT_STR(EzDefaultPmk);
		FPRINT_STR(EzDefaultPmkValid);
		FPRINT_STR(EzDefaultSettings);
		FPRINT_STR(ManConf);
		FPRINT_STR(FtMdId1);
		FPRINT_STR(FtMdId2);
		FPRINT_STR(MacAddress);
		FPRINT_STR(MacAddress1);
		FPRINT_STR(RegroupSupport);
#endif
#if defined (CONFIG_MWDS)
		FPRINT_STR(ApMWDS);
		FPRINT_STR(ApCliMWDS);
#endif
		FPRINT_STR(ForceRoamSupport);

		FPRINT_NUM(MeshAutoLink);
		FPRINT_STR(MeshAuthMode);
		FPRINT_STR(MeshEncrypType);
		FPRINT_NUM(MeshDefaultkey);
		FPRINT_STR(MeshWEPKEY);
		FPRINT_STR(MeshWPAKEY);
		FPRINT_STR(MeshId);

/*
		//WscConfStatus is replaced by WscConfMode and WscConfStatus
		if (atoi(nvram_bufget(mode, "WscConfigured")) == 0)
			fprintf(fp, "WscConfStatus=%d\n", 1);
		else
			fprintf(fp, "WscConfStatus=%d\n", 2);
*/
		if (strcmp(nvram_bufget(mode, "WscVendorPinCode"), "") != 0)
			FPRINT_STR(WscVendorPinCode);
		FPRINT_NUM(WCNTest);
#if defined CONFIG_UNIQUE_WPS
		FPRINT_STR(WSC_UUID_Str1);
		FPRINT_STR(WSC_UUID_E1);
#endif

		FPRINT_NUM(WiFiTest);
		FPRINT_NUM(TGnWifiTest);

		//AP Client parameters
#if defined (CONFIG_EASY_SETUP_SUPPORT)
		FPRINT_STR(ApCliEzEnable);
		FPRINT_STR(ApCliEzConfStatus);
		FPRINT_STR(ApCliEzGroupID);
		FPRINT_STR(ApCliEzGenGroupID);
		FPRINT_STR(ApCliEzOpenGroupID);
		FPRINT_STR(ApCliEzRssiThreshold);
		FPRINT_STR(ApCliHideSSID);
#endif		
		FPRINT_STR(ApCliEnable);
		FPRINT_STR(ApCliSsid);
		FPRINT_STR(ApCliBssid);
		FPRINT_STR(ApCliAuthMode);
		FPRINT_STR(ApCliEncrypType);
		FPRINT_STR(ApCliWPAPSK);
		FPRINT_STR(ApCliDefaultKeyID);
		FPRINT_STR(ApCliKey1Type);
		FPRINT_STR(ApCliKey1Str);
		FPRINT_STR(ApCliKey2Type);
		FPRINT_STR(ApCliKey2Str);
		FPRINT_STR(ApCliKey3Type);
		FPRINT_STR(ApCliKey3Str);
		FPRINT_STR(ApCliKey4Type);
		FPRINT_STR(ApCliKey4Str);
		FPRINT_STR(MACRepeaterEn);
		FPRINT_STR(MACRepeaterOuiMode);
#if defined (CONFIG_DBDC_MODE)
#if defined (CONFIG_CHIP_MT7615E)
		FPRINT_STR(ApCliWirelessMode);
		FPRINT_STR(ApCliWPAPSK1);
		FPRINT_STR(ApCliKey1Str1);
		FPRINT_STR(ApCliKey2Str1);
		FPRINT_STR(ApCliKey3Str1);
		FPRINT_STR(ApCliKey4Str1);
#endif
#endif

#if defined (CONFIG_BACKGROUND_SCAN_SUPPORT)
		FPRINT_STR(BgndScanSkipCh);
#endif /*CONFIG_BACKGROUND_SCAN_SUPPORT*/
		/*
		 * There are no SSID/WPAPSK/Key1Str/Key2Str/Key3Str/Key4Str anymore since driver1.5 , but 
		 * STA WPS still need these entries to show the WPS result(That is the only way i know to get WPAPSK key) and
		 * so we create empty entries here.   --YY
		 *
		 * Move them to related block. -- LD
		 */
		//fprintf(fp, "SSID=\nWPAPSK=\nKey1Str=\nKey2Str=\nKey3Str=\nKey4Str=\n");
		FPRINT_NUM(BandSteering);
		FPRINT_STR(BndStrgBssIdx);

		FPRINT_NUM(RadioLinkSelection);
#if defined (CONFIG_ROAMING_ENHANCE_SUPPORT)
		FPRINT_NUM(RoamingEnhance);
#endif /* defined (CONFIG_ROAMING_ENHANCE_SUPPORT) */
		FPRINT_NUM(EtherTrafficBand);
		FPRINT_STR(BTApCliAutoBWSupport);
	}

	nvram_close(mode);
	fclose(fp);
	return 0;
}

int renew_nvram(int mode, char *fname)
{
	FILE *fp;
#define BUFSZ 1024
	char buf[BUFSZ], *p;
	char wan_mac[32];
	int found = 0, need_commit = 0;

	if (NULL == (fp = fopen(fname, "ro"))) {
		perror("fopen");
		return -1;
	}

	//find "Default" first
	while (NULL != fgets(buf, BUFSZ, fp)) {
		if (buf[0] == '\n' || buf[0] == '#')
			continue;
		if (!strncmp(buf, "Default\n", 8)) {
			found = 1;
			break;
		}
	}
	if (!found) {
		printf("file format error!\n");
		fclose(fp);
		return -1;
	}

	nvram_init(mode);
	while (NULL != fgets(buf, BUFSZ, fp)) {
		if (buf[0] == '\n' || buf[0] == '#')
			continue;
		if (NULL == (p = strchr(buf, '='))) {
			if (need_commit)
				nvram_commit(mode);
			printf("%s file format error!\n", fname);
			fclose(fp);
			return -1;
		}
		buf[strlen(buf) - 1] = '\0'; //remove carriage return
		*p++ = '\0'; //seperate the string
		//printf("bufset %d '%s'='%s'\n", mode, buf, p);
		nvram_bufset(mode, buf, p);
		need_commit = 1;
	}

	//Get wan port mac address, please refer to eeprom format doc
	//0x30000=user configure, 0x32000=rt2860 parameters, 0x40000=RF parameter
	flash_read_mac(buf);
	sprintf(wan_mac,"%0X:%0X:%0X:%0X:%0X:%0X",buf[0],buf[1],buf[2],buf[3],buf[4],buf[5]);
	nvram_bufset(DEV1_NVRAM, "WAN_MAC_ADDR", wan_mac);

	need_commit = 1;

	if (need_commit)
		nvram_commit(mode);

	nvram_close(mode);
	fclose(fp);
	return 0;
}

int nvram_show(int mode)
{
	nvram_init(mode);
	nvram_buflist(mode);
	nvram_close(mode);
#if 0
	char *buffer, *p;
	int rc;
	int crc;
	unsigned int len = 0x4000;

	nvram_init(mode);
	len = getNvramBlockSize(mode);

	if ((mode = getNvramIndex(fz)) == -1) {
		printf("%s: Error: \"%s\" flash zone not existed\n", argv[0], fz);
		return get_usage(argv[0]);
	}

	buffer = malloc(len);
	if (buffer == NULL) {
		fprintf(stderr, "nvram_show: Can not allocate memory!\n");
		return -1;
	}
	if (mode == CONFIG2_NVRAM)
		flash_read("Config2", buffer, getNvramOffset(mode), len);
	else
		flash_read("Config", buffer, getNvramOffset(mode), len);
	memcpy(&crc, buffer, 4);

	fprintf(stderr, "crc = %x\n", crc);
	p = buffer + 4;
	while (*p != '\0') {
		printf("%s\n", p);
		p += strlen(p) + 1;
	}

	free(buffer);
#endif
	return 0;
}

void usage(char *cmd)
{
/* Open usage for new nvram naming */
//#ifndef CONFIG_CC_OPTIMIZE_FOR_SIZE
	printf("Usage:\n");
	printf("  %s <command> [<platform>] [<file>]\n\n", cmd);
	printf("command:\n");
	printf("  dev1_nvram_show   - display 1st device values in nvram\n");
	printf("  dev2_nvram_show   - display 2nd device values in nvram\n");
	printf("  dev3_nvram_show   - display 3rd device values in nvram\n");
#ifdef CONFIG_DUAL_IMAGE
	printf("  uboot_nvram_show - display uboot parameter values\n");
#endif
#if defined CONFIG_EXTEND_NVRAM
	printf("  config2_nvram_show   - display configuration in 2nd nvram\n");
#endif
	printf("  show    - display values in nvram for <platform>\n");
	printf("  gen     - generate config file from nvram for <platform>\n");
	printf("  renew   - replace nvram values for <platform> with <file>\n");
	printf("  clear	  - clear all entries in nvram for <platform>\n");
	printf("platform:\n");
	printf("  dev1    - 1st device\n");
	printf("  dev2    - 2nd device\n");
	printf("  dev3    - 3rd device\n");
#ifdef CONFIG_DUAL_IMAGE
	printf("  uboot    - uboot parameter\n");
#endif
#if defined CONFIG_EXTEND_NVRAM
	printf("  config2    - 2nd nvram\n");
#endif
	printf("file:\n");
	printf("          - file name for renew command\n");
//#endif
	exit(0);
}

int main(int argc, char *argv[])
{
	char *cmd;

	//call nvram_get or nvram_set
	if ((cmd = strrchr(argv[0], '/')) != NULL)
		cmd++;
	else
		cmd = argv[0];

	if (!strncmp(cmd, "nvram_get", 10))
		return ra_nv_get(argc, argv);
	else if (!strncmp(cmd, "nvram_set", 10))
		return ra_nv_set(argc, argv);

	if (argc < 2)
		usage(argv[0]);

	if (argc == 2) {
		if (!strncmp(argv[1], "dev1_nvram_show", 16) ||
		    !strncmp(argv[1], "rt2860_nvram_show", 18))
			nvram_show(DEV1_NVRAM);
		else if (!strncmp(argv[1], "dev2_nvram_show", 16) ||
		         !strncmp(argv[1], "rtdev_nvram_show", 17))
			nvram_show(DEV2_NVRAM);
		else if (!strncmp(argv[1], "dev3_nvram_show", 16) ||
		         !strncmp(argv[1], "wifi3_nvram_show", 17))
			nvram_show(DEV3_NVRAM);
#ifdef CONFIG_DUAL_IMAGE
		else if (!strncmp(argv[1], "uboot_nvram_show", 17))
			nvram_show(UBOOT_NVRAM);
#endif
#if 1 //def CONFIG_RT2860V2_STA_WPA_SUPPLICANT
		else if (!strncmp(argv[1], "cert_nvram_show", 16))
			nvram_show(CERT_NVRAM);
#endif

#ifdef WAPI_SUPPORT
		else if (!strncmp(argv[1], "wapi_nvram_show", 16))
			nvram_show(WAPI_NVRAM);
#endif
#if defined CONFIG_EXTEND_NVRAM
		else if (!strncmp(argv[1], "config2_nvram_show", 19))
			nvram_show(CONFIG2_NVRAM);
		else if (!strncmp(argv[1], "tr069cert_nvram_show", 21))
			nvram_show(TR069CERT_NVRAM);
#endif
		else
			usage(argv[0]);
	} else if (argc == 3) {

		/* TODO: <cmd> gen 2860ap */
		if (!strncasecmp(argv[1], "gen", 4) ||
		    !strncasecmp(argv[1], "make_wireless_config", 21)) {
			int i; 
			unsigned char done = 0;
			for (i = 0; strlen(gen_cmd_map[i].cmd) > 0; i++){
				//printf("gen_cmd_map[%d].cmd=%s, nv_zone=%d, dbdc_idx=%d|\n", i, gen_cmd_map[i].cmd, gen_cmd_map[i].nv_zone, gen_cmd_map[i].dbdc_idx);
				if (!strncmp(argv[2], gen_cmd_map[i].cmd, strlen(argv[2]))) {
					gen_config(gen_cmd_map[i].nv_zone, gen_cmd_map[i].dbdc_idx, NULL);
					done = 1;
					break;
				}
			}
#ifdef CONFIG_DUAL_IMAGE
			if (!strncasecmp(argv[2], "uboot", 6))
				printf("No support of gen command of uboot parameter.\n"); done = 1;
#endif
#ifdef CONFIG_RT2860V2_STA_WPA_SUPPLICANT
			if (!strncmp(argv[2], "cert", 5))
				gen_cert(CERT_NVRAM); done = 1;
#endif
#ifdef WAPI_SUPPORT
			if (!strncmp(argv[2], "wapi", 5))
				gen_cert(WAPI_NVRAM); done = 1;
#endif
#if defined CONFIG_EXTEND_NVRAM
			if (!strncmp(argv[2], "tr069_ca_cert", 14))
				gen_cert_tr069("tr069_ca"); done = 1;
			if (!strncmp(argv[2], "tr069_cc_cert", 14))
				gen_cert_tr069("tr069_cc"); done = 1;
#endif
			if (!strncmp(argv[2], "DBDC_NVRAM_B0_5G", 17)){
#if defined (RTDEV_DBDC_MODE)
				gen_config(DEV2_NVRAM, DEV2_B0_5G, NULL);
#else
				gen_config(DEV1_NVRAM, DEV1_B0_5G, NULL);
#endif
				done = 1;
			}
			if (!strncmp(argv[2], "WIFI3_B1_5G", 12)){
				gen_config(DEV3_NVRAM, DEV3_B1_5G, NULL);
				done = 1;
			}
			if(!done)
				usage(argv[0]);
		} else if (!strncasecmp(argv[1], "show", 5)) {
			if (!strncmp(argv[2], "dev1", 5) ||
			    !strncmp(argv[2], "2860", 5) ||
			    !strncasecmp(argv[2], "rt2860", 7)) //b-compatible
				nvram_show(DEV1_NVRAM);
			else if (!strncasecmp(argv[2], "dev2", 5) ||
			         !strncasecmp(argv[2], "rtdev", 6))
				nvram_show(DEV2_NVRAM);
			else if (!strncasecmp(argv[2], "dev3", 5) ||
			         !strncasecmp(argv[2], "wifi3", 6))
				nvram_show(DEV3_NVRAM);
#ifdef CONFIG_DUAL_IMAGE
			else if (!strncasecmp(argv[2], "uboot", 6))
				nvram_show(UBOOT_NVRAM);
#endif
#ifdef CONFIG_RT2860V2_STA_WPA_SUPPLICANT
			else if (!strncasecmp(argv[2], "cert", 5))
				nvram_show(CERT_NVRAM);
#endif
#ifdef WAPI_SUPPORT
			else if (!strncasecmp(argv[2], "wapi", 5))
				nvram_show(WAPI_NVRAM);
#endif
#if defined CONFIG_EXTEND_NVRAM
			else if (!strncasecmp(argv[2], "config2", 8))
				nvram_show(CONFIG2_NVRAM);
			else if (!strncasecmp(argv[2], "tr069cert", 10))
				nvram_show(TR069CERT_NVRAM);
#endif
			else
				usage(argv[0]);
		} else if(!strncasecmp(argv[1], "clear", 6)) {
			if (!strncmp(argv[2], "dev1", 5) ||
			    !strncmp(argv[2], "2860", 5) || 
			    !strncasecmp(argv[2], "rt2860", 7)) //b-compatible
				nvram_clear(DEV1_NVRAM);
			else if (!strncasecmp(argv[2], "dev2", 5) ||
			         !strncasecmp(argv[2], "rtdev", 6))
				nvram_clear(DEV2_NVRAM);
			else if (!strncasecmp(argv[2], "dev3", 5) ||
			         !strncasecmp(argv[2], "wifi3", 6))
				nvram_clear(DEV3_NVRAM);
#ifdef CONFIG_DUAL_IMAGE
			else if (!strncasecmp(argv[2], "uboot", 6))
				nvram_clear(UBOOT_NVRAM);
#endif
#ifdef CONFIG_RT2860V2_STA_WPA_SUPPLICANT
			else if (!strncasecmp(argv[2], "cert", 5))
				nvram_clear(CERT_NVRAM);
#endif
#ifdef WAPI_SUPPORT
			else if (!strncasecmp(argv[2], "wapi", 5))
				nvram_clear(WAPI_NVRAM);
#endif
#if defined CONFIG_EXTEND_NVRAM
			else if (!strncasecmp(argv[2], "config2", 8))
				nvram_clear(CONFIG2_NVRAM);
			else if (!strncasecmp(argv[2], "tr069cert", 10))
				nvram_clear(TR069CERT_NVRAM);
#endif
			else
				usage(argv[0]);
		} else
			usage(argv[0]);
	} else if (argc == 4) {
		if (!strncasecmp(argv[1], "renew", 6)) {
			if (!strncmp(argv[2], "dev1", 5) ||
			    !strncmp(argv[2], "2860", 5) ||
			    !strncasecmp(argv[2], "rt2860", 7)) //b-compatible
				renew_nvram(DEV1_NVRAM, argv[3]);
			else if (!strncasecmp(argv[2], "dev2", 5) ||
			         !strncasecmp(argv[2], "rtdev", 6))
				renew_nvram(DEV2_NVRAM, argv[3]);
			else if (!strncasecmp(argv[2], "dev3", 5) ||
			         !strncasecmp(argv[2], "wifi3", 6))
				renew_nvram(DEV3_NVRAM, argv[3]);
#ifdef CONFIG_DUAL_IMAGE
			else if (!strncasecmp(argv[2], "uboot", 6))
				printf("No support of renew command of uboot parameter.\n");
#endif
#if defined CONFIG_EXTEND_NVRAM
			else if (!strncasecmp(argv[2], "config2", 8))
				renew_nvram(CONFIG2_NVRAM, argv[3]);
#endif
		} else if (!strncasecmp(argv[1], "gen", 4)){
			int i;
			unsigned char done = 0;
			for (i = 0; strlen(gen_cmd_map[i].cmd) > 0; i++){
				if (!strncmp(argv[2], gen_cmd_map[i].cmd, strlen(argv[2]))) {
					gen_config(gen_cmd_map[i].nv_zone, gen_cmd_map[i].dbdc_idx, argv[3]);
					done = 1;
					break;
				}
			}
			if(!done)
				usage(argv[0]);
		} else
			usage(argv[0]);
	} else
		usage(argv[0]);
	return 0;
}

