#ifndef HAVE_UTILS_H
#define HAVE_UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>

#include "nvram.h"
#include "oid.h"

#define LOGFILE	"/dev/console"
#define DBG_MSG(fmt, arg...)	do {	FILE *log_fp = fopen(LOGFILE, "w+"); \
						if(log_fp == NULL) break;\
						fprintf(log_fp, "%s:%s:%d:" fmt "\n", __FILE__, __func__, __LINE__, ##arg); \
						fclose(log_fp); \
					} while(0)

#if defined(RT2860_NEW_MBSS_SUPPORT) || defined(RTDEV_NEW_MBSS_SUPPORT) || defined(RT2860_16BSSID_SUPPORT) || defined(RTDEV_16BSSID_SUPPORT)
#define MBSSID_MAX_NUM 16
#else
#define MBSSID_MAX_NUM 8
#endif

#if defined (WSC_SUPPORT)
void getCurrentWscProfile(char *interface, WSC_CONFIGURED_VALUE *data, int len);
int getWscStatus(char *interface);
int getWscProfile(char *interface, WSC_PROFILE *wsc_profile);
#endif

char *racat(char *s, int i);
int get_nth_value(int index, const char *value, char delimit, char *result, int len);
int get_nth_number(int index, const char *value, char delimit, int base);
char *set_nth_value(int index, char *old_values, const char *new_value);
char *set_nth_value_default(int index, char *old_values, char *new_value, const char *def_value);
void set_nth_value_flash(int nvram, int index, char *flash_key, const char *value);
void set_nth_value_default_flash(int nvram, int index, char *flash_key, char *value, const char *def_value);
int OidQueryInformation(unsigned long OidQueryCode, int socket_id, char *DeviceName, void *ptr, unsigned long PtrLength);
int OidSetInformation(unsigned long OidQueryCode, int socket_id, char *DeviceName, void *ptr, unsigned long PtrLength);
int port_secured(char *ifname);
#endif /* HAVE_UTILS_H */
