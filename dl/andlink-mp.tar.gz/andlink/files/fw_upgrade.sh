#!/bin/sh

echo "Usage: $0 fileMode fileType fileUrl downMode"
echo "       -fileMode: down(default) up"
echo "       -fileType: FIRM(default) APP LOG CFG"
echo "       -downMode: 1(default:reboot now) 0-reboot later"

DOWNLOAD_DIR="/tmp/andlink_download"

fileMode="$1"    #down(default) up
fileType="$2"    #FIRM(default) APP LOG CFG
fileUrl="$3"
downMode="$4"    #0-reboot later 1-reboot now

Upgrade_Firmware()
{
	if [ "$fileType" = "FIRM" ]; then
		dwfile=`ls $DOWNLOAD_DIR`

		if [ "$dwfile" != "" ]; then
			dwfile="$DOWNLOAD_DIR/$dwfile"
			/sbin/sysupgrade $dwfile
			local fault_code="$?"
			if [ "$fault_code" != "0" ];then	
				rm -rf $DOWNLOAD_DIR 2> /dev/null
				echo "Upgrade fail!!"
			else
				echo "Upgrade Successfully!!"
			fi
		else
			echo "Image file does't exist!!"
			return
		fi
	fi
}

fw_upgrade()
{
	if [ "$fileMode" = "down" -o  "$fileMode" = "" ]; then
		rm -rf $DOWNLOAD_DIR 2> /dev/null
		mkdir -p $DOWNLOAD_DIR
		wget -P $DOWNLOAD_DIR "$fileUrl"
		fault_code="$?"
		if [ "$fault_code" != "0" ];then
			rm -rf $DOWNLOAD_DIR 2> /dev/null
			return
		fi

		case $fileType in
		APP)
			echo "fileType: APP"
			;;
		CFG)
			echo "fileType: CFG"
			;;
		LOG)
			echo "fileType: LOG"
			;;
		*)
			echo "Default: FIRM"
			Upgrade_Firmware 
			;;
		esac
	else
		echo "upload the file"
	fi

	if [ "$downMode" != "1" -o "$downMode" != "" ];then
		sync
		reboot
	else
		return
	fi
}


fw_upgrade

