
void 
msg_event(int prio, const char *desc, void *tag1, ...)
{
  ;
}

void
main_loop_wakeup()
{
  ;
}
