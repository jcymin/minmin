
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 1 "cfg-grammar.y"


#include "syslog-ng.h"
#include "cfg.h"
#include "sgroup.h"
#include "dgroup.h"
#include "center.h"
#include "filter.h"
#include "templates.h"
#include "logreader.h"
#include "logparser.h"
#include "logrewrite.h"

#if ENABLE_SSL /* BEGIN MARK: tls */
#include "tlscontext.h"
#endif         /* END MARK */

#include "affile.h"
#include "afinter.h"
#include "afsocket.h"
#include "afinet.h"
#include "afunix.h"
#include "afstreams.h"
#include "afuser.h"
#include "afprog.h"
#if ENABLE_SQL
#include "afsql.h"
#endif

#include "messages.h"

#include "syslog-names.h"

#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* FIXME: the lexer allocates strings with strdup instead of g_strdup,
 * therefore there are unnecessary g_strdup/free pairs in the grammar. These
 * should be removed. */

void yyerror(char *msg);
int yylex();

LogDriver *last_driver;
LogReaderOptions *last_reader_options;
LogWriterOptions *last_writer_options;
LogTemplate *last_template;
SocketOptions *last_sock_options;
LogParser *last_parser;
FilterRE *last_re_filter;
LogRewrite *last_rewrite;
gint last_addr_family = AF_INET;
gchar *last_include_file;

#if ENABLE_SSL
TLSContext *last_tls_context;
#endif


#if ! ENABLE_IPV6
#undef AF_INET6
#define AF_INET6 0; g_assert_not_reached()

#endif

static struct _LogTemplate *
cfg_check_inline_template(GlobalConfig *cfg, const gchar *template_or_name)
{
  struct _LogTemplate *template = cfg_lookup_template(configuration, template_or_name);
  if (template == NULL)
    {
      template = log_template_new(NULL, template_or_name); 
      template->def_inline = TRUE;
    }
  return template;
}

static gboolean
cfg_check_template(LogTemplate *template)
{
  GError *error = NULL;
  if (!log_template_compile(template, &error))
    {
      msg_error("Error compiling template",
                evt_tag_str("template", template->template),
                evt_tag_str("error", error->message),
                NULL);
      g_clear_error(&error);
      return FALSE;
    }
  return TRUE;
}




/* Line 189 of yacc.c  */
#line 172 "cfg-grammar.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     KW_SOURCE = 258,
     KW_FILTER = 259,
     KW_PARSER = 260,
     KW_DESTINATION = 261,
     KW_LOG = 262,
     KW_OPTIONS = 263,
     KW_INCLUDE = 264,
     KW_INTERNAL = 265,
     KW_FILE = 266,
     KW_PIPE = 267,
     KW_UNIX_STREAM = 268,
     KW_UNIX_DGRAM = 269,
     KW_TCP = 270,
     KW_UDP = 271,
     KW_TCP6 = 272,
     KW_UDP6 = 273,
     KW_USERTTY = 274,
     KW_DOOR = 275,
     KW_SUN_STREAMS = 276,
     KW_PROGRAM = 277,
     KW_SQL = 278,
     KW_TYPE = 279,
     KW_COLUMNS = 280,
     KW_INDEXES = 281,
     KW_VALUES = 282,
     KW_PASSWORD = 283,
     KW_DATABASE = 284,
     KW_USERNAME = 285,
     KW_TABLE = 286,
     KW_ENCODING = 287,
     KW_DELIMITERS = 288,
     KW_QUOTES = 289,
     KW_QUOTE_PAIRS = 290,
     KW_NULL = 291,
     KW_SYSLOG = 292,
     KW_TRANSPORT = 293,
     KW_FSYNC = 294,
     KW_MARK_FREQ = 295,
     KW_STATS_FREQ = 296,
     KW_STATS_LEVEL = 297,
     KW_FLUSH_LINES = 298,
     KW_SUPPRESS = 299,
     KW_FLUSH_TIMEOUT = 300,
     KW_LOG_MSG_SIZE = 301,
     KW_FILE_TEMPLATE = 302,
     KW_PROTO_TEMPLATE = 303,
     KW_CHAIN_HOSTNAMES = 304,
     KW_NORMALIZE_HOSTNAMES = 305,
     KW_KEEP_HOSTNAME = 306,
     KW_CHECK_HOSTNAME = 307,
     KW_BAD_HOSTNAME = 308,
     KW_KEEP_TIMESTAMP = 309,
     KW_USE_DNS = 310,
     KW_USE_FQDN = 311,
     KW_DNS_CACHE = 312,
     KW_DNS_CACHE_SIZE = 313,
     KW_DNS_CACHE_EXPIRE = 314,
     KW_DNS_CACHE_EXPIRE_FAILED = 315,
     KW_DNS_CACHE_HOSTS = 316,
     KW_PERSIST_ONLY = 317,
     KW_TZ_CONVERT = 318,
     KW_TS_FORMAT = 319,
     KW_FRAC_DIGITS = 320,
     KW_LOG_FIFO_SIZE = 321,
     KW_LOG_DISK_FIFO_SIZE = 322,
     KW_LOG_FETCH_LIMIT = 323,
     KW_LOG_IW_SIZE = 324,
     KW_LOG_PREFIX = 325,
     KW_PROGRAM_OVERRIDE = 326,
     KW_HOST_OVERRIDE = 327,
     KW_THROTTLE = 328,
     KW_TLS = 329,
     KW_PEER_VERIFY = 330,
     KW_KEY_FILE = 331,
     KW_CERT_FILE = 332,
     KW_CA_DIR = 333,
     KW_CRL_DIR = 334,
     KW_TRUSTED_KEYS = 335,
     KW_TRUSTED_DN = 336,
     KW_FLAGS = 337,
     KW_PAD_SIZE = 338,
     KW_TIME_ZONE = 339,
     KW_RECV_TIME_ZONE = 340,
     KW_SEND_TIME_ZONE = 341,
     KW_LOCAL_TIME_ZONE = 342,
     KW_TIME_REOPEN = 343,
     KW_TIME_REAP = 344,
     KW_TIME_SLEEP = 345,
     KW_TMPL_ESCAPE = 346,
     KW_OPTIONAL = 347,
     KW_CREATE_DIRS = 348,
     KW_OWNER = 349,
     KW_GROUP = 350,
     KW_PERM = 351,
     KW_DIR_OWNER = 352,
     KW_DIR_GROUP = 353,
     KW_DIR_PERM = 354,
     KW_TEMPLATE = 355,
     KW_TEMPLATE_ESCAPE = 356,
     KW_FOLLOW_FREQ = 357,
     KW_OVERWRITE_IF_OLDER = 358,
     KW_DEFAULT_FACILITY = 359,
     KW_DEFAULT_LEVEL = 360,
     KW_KEEP_ALIVE = 361,
     KW_MAX_CONNECTIONS = 362,
     KW_LOCALIP = 363,
     KW_IP = 364,
     KW_LOCALPORT = 365,
     KW_PORT = 366,
     KW_DESTPORT = 367,
     KW_IP_TTL = 368,
     KW_SO_BROADCAST = 369,
     KW_IP_TOS = 370,
     KW_SO_SNDBUF = 371,
     KW_SO_RCVBUF = 372,
     KW_SO_KEEPALIVE = 373,
     KW_SPOOF_SOURCE = 374,
     KW_USE_TIME_RECVD = 375,
     KW_FACILITY = 376,
     KW_LEVEL = 377,
     KW_HOST = 378,
     KW_MATCH = 379,
     KW_MESSAGE = 380,
     KW_NETMASK = 381,
     KW_CSV_PARSER = 382,
     KW_VALUE = 383,
     KW_DB_PARSER = 384,
     KW_REWRITE = 385,
     KW_SET = 386,
     KW_SUBST = 387,
     KW_YES = 388,
     KW_NO = 389,
     KW_GC_IDLE_THRESHOLD = 390,
     KW_GC_BUSY_THRESHOLD = 391,
     KW_COMPRESS = 392,
     KW_MAC = 393,
     KW_AUTH = 394,
     KW_ENCRYPT = 395,
     KW_IFDEF = 396,
     KW_ENDIF = 397,
     LL_DOTDOT = 398,
     LL_IDENTIFIER = 399,
     LL_NUMBER = 400,
     LL_FLOAT = 401,
     LL_STRING = 402,
     KW_OR = 403,
     KW_AND = 404,
     KW_NOT = 405
   };
#endif
/* Tokens.  */
#define KW_SOURCE 258
#define KW_FILTER 259
#define KW_PARSER 260
#define KW_DESTINATION 261
#define KW_LOG 262
#define KW_OPTIONS 263
#define KW_INCLUDE 264
#define KW_INTERNAL 265
#define KW_FILE 266
#define KW_PIPE 267
#define KW_UNIX_STREAM 268
#define KW_UNIX_DGRAM 269
#define KW_TCP 270
#define KW_UDP 271
#define KW_TCP6 272
#define KW_UDP6 273
#define KW_USERTTY 274
#define KW_DOOR 275
#define KW_SUN_STREAMS 276
#define KW_PROGRAM 277
#define KW_SQL 278
#define KW_TYPE 279
#define KW_COLUMNS 280
#define KW_INDEXES 281
#define KW_VALUES 282
#define KW_PASSWORD 283
#define KW_DATABASE 284
#define KW_USERNAME 285
#define KW_TABLE 286
#define KW_ENCODING 287
#define KW_DELIMITERS 288
#define KW_QUOTES 289
#define KW_QUOTE_PAIRS 290
#define KW_NULL 291
#define KW_SYSLOG 292
#define KW_TRANSPORT 293
#define KW_FSYNC 294
#define KW_MARK_FREQ 295
#define KW_STATS_FREQ 296
#define KW_STATS_LEVEL 297
#define KW_FLUSH_LINES 298
#define KW_SUPPRESS 299
#define KW_FLUSH_TIMEOUT 300
#define KW_LOG_MSG_SIZE 301
#define KW_FILE_TEMPLATE 302
#define KW_PROTO_TEMPLATE 303
#define KW_CHAIN_HOSTNAMES 304
#define KW_NORMALIZE_HOSTNAMES 305
#define KW_KEEP_HOSTNAME 306
#define KW_CHECK_HOSTNAME 307
#define KW_BAD_HOSTNAME 308
#define KW_KEEP_TIMESTAMP 309
#define KW_USE_DNS 310
#define KW_USE_FQDN 311
#define KW_DNS_CACHE 312
#define KW_DNS_CACHE_SIZE 313
#define KW_DNS_CACHE_EXPIRE 314
#define KW_DNS_CACHE_EXPIRE_FAILED 315
#define KW_DNS_CACHE_HOSTS 316
#define KW_PERSIST_ONLY 317
#define KW_TZ_CONVERT 318
#define KW_TS_FORMAT 319
#define KW_FRAC_DIGITS 320
#define KW_LOG_FIFO_SIZE 321
#define KW_LOG_DISK_FIFO_SIZE 322
#define KW_LOG_FETCH_LIMIT 323
#define KW_LOG_IW_SIZE 324
#define KW_LOG_PREFIX 325
#define KW_PROGRAM_OVERRIDE 326
#define KW_HOST_OVERRIDE 327
#define KW_THROTTLE 328
#define KW_TLS 329
#define KW_PEER_VERIFY 330
#define KW_KEY_FILE 331
#define KW_CERT_FILE 332
#define KW_CA_DIR 333
#define KW_CRL_DIR 334
#define KW_TRUSTED_KEYS 335
#define KW_TRUSTED_DN 336
#define KW_FLAGS 337
#define KW_PAD_SIZE 338
#define KW_TIME_ZONE 339
#define KW_RECV_TIME_ZONE 340
#define KW_SEND_TIME_ZONE 341
#define KW_LOCAL_TIME_ZONE 342
#define KW_TIME_REOPEN 343
#define KW_TIME_REAP 344
#define KW_TIME_SLEEP 345
#define KW_TMPL_ESCAPE 346
#define KW_OPTIONAL 347
#define KW_CREATE_DIRS 348
#define KW_OWNER 349
#define KW_GROUP 350
#define KW_PERM 351
#define KW_DIR_OWNER 352
#define KW_DIR_GROUP 353
#define KW_DIR_PERM 354
#define KW_TEMPLATE 355
#define KW_TEMPLATE_ESCAPE 356
#define KW_FOLLOW_FREQ 357
#define KW_OVERWRITE_IF_OLDER 358
#define KW_DEFAULT_FACILITY 359
#define KW_DEFAULT_LEVEL 360
#define KW_KEEP_ALIVE 361
#define KW_MAX_CONNECTIONS 362
#define KW_LOCALIP 363
#define KW_IP 364
#define KW_LOCALPORT 365
#define KW_PORT 366
#define KW_DESTPORT 367
#define KW_IP_TTL 368
#define KW_SO_BROADCAST 369
#define KW_IP_TOS 370
#define KW_SO_SNDBUF 371
#define KW_SO_RCVBUF 372
#define KW_SO_KEEPALIVE 373
#define KW_SPOOF_SOURCE 374
#define KW_USE_TIME_RECVD 375
#define KW_FACILITY 376
#define KW_LEVEL 377
#define KW_HOST 378
#define KW_MATCH 379
#define KW_MESSAGE 380
#define KW_NETMASK 381
#define KW_CSV_PARSER 382
#define KW_VALUE 383
#define KW_DB_PARSER 384
#define KW_REWRITE 385
#define KW_SET 386
#define KW_SUBST 387
#define KW_YES 388
#define KW_NO 389
#define KW_GC_IDLE_THRESHOLD 390
#define KW_GC_BUSY_THRESHOLD 391
#define KW_COMPRESS 392
#define KW_MAC 393
#define KW_AUTH 394
#define KW_ENCRYPT 395
#define KW_IFDEF 396
#define KW_ENDIF 397
#define LL_DOTDOT 398
#define LL_IDENTIFIER 399
#define LL_NUMBER 400
#define LL_FLOAT 401
#define LL_STRING 402
#define KW_OR 403
#define KW_AND 404
#define KW_NOT 405




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 99 "cfg-grammar.y"

        gint token;
	gint64 num;
	double fnum;
	char *cptr;
	void *ptr;
	FilterExprNode *node;



/* Line 214 of yacc.c  */
#line 519 "cfg-grammar.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 264 of yacc.c  */
#line 531 "cfg-grammar.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  58
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1721

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  156
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  171
/* YYNRULES -- Number of rules.  */
#define YYNRULES  456
/* YYNRULES -- Number of states.  */
#define YYNSTATES  1141

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   405

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     154,   155,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,   151,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   152,     2,   153,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     6,    11,    12,    15,    18,    21,
      24,    27,    30,    33,    36,    39,    44,    50,    56,    61,
      66,    72,    74,    78,    79,    84,    89,    94,    99,   104,
     107,   108,   116,   122,   123,   126,   127,   131,   132,   138,
     142,   143,   148,   153,   158,   163,   168,   173,   175,   180,
     185,   189,   190,   192,   194,   196,   198,   200,   202,   206,
     211,   216,   217,   221,   222,   226,   231,   233,   238,   243,
     244,   250,   251,   257,   258,   264,   265,   271,   272,   276,
     277,   281,   284,   285,   290,   295,   300,   305,   307,   309,
     311,   312,   315,   318,   319,   321,   326,   331,   336,   341,
     343,   345,   346,   349,   352,   353,   355,   356,   362,   364,
     369,   374,   375,   381,   382,   385,   388,   389,   391,   396,
     401,   406,   411,   412,   418,   420,   425,   426,   430,   432,
     437,   439,   440,   444,   447,   448,   450,   455,   457,   460,
     461,   466,   471,   476,   481,   486,   491,   496,   501,   506,
     511,   516,   521,   526,   531,   536,   541,   546,   551,   556,
     561,   566,   571,   574,   575,   579,   580,   582,   584,   586,
     588,   590,   592,   594,   599,   600,   604,   607,   608,   610,
     615,   620,   625,   630,   635,   640,   645,   650,   655,   660,
     665,   670,   671,   675,   678,   679,   681,   686,   691,   696,
     701,   706,   707,   713,   714,   720,   721,   727,   728,   734,
     735,   739,   740,   744,   747,   748,   750,   752,   754,   755,
     759,   762,   763,   768,   773,   778,   783,   785,   787,   789,
     791,   796,   797,   801,   804,   805,   807,   808,   814,   819,
     824,   825,   829,   832,   833,   835,   840,   845,   850,   855,
     860,   861,   867,   872,   877,   878,   882,   887,   888,   891,
     894,   895,   897,   902,   907,   912,   917,   922,   927,   932,
     937,   942,   947,   952,   957,   962,   967,   972,   977,   979,
     982,   983,   988,   993,   998,  1003,  1008,  1013,  1018,  1023,
    1028,  1033,  1038,  1041,  1042,  1046,  1047,  1052,  1057,  1062,
    1067,  1072,  1077,  1082,  1087,  1092,  1097,  1102,  1107,  1112,
    1117,  1122,  1127,  1132,  1137,  1142,  1147,  1152,  1157,  1162,
    1167,  1172,  1177,  1182,  1187,  1192,  1197,  1202,  1207,  1212,
    1217,  1222,  1227,  1232,  1237,  1242,  1247,  1252,  1257,  1260,
    1261,  1263,  1268,  1273,  1278,  1283,  1288,  1293,  1298,  1300,
    1302,  1305,  1309,  1313,  1317,  1322,  1327,  1332,  1337,  1342,
    1343,  1350,  1351,  1358,  1359,  1366,  1367,  1374,  1375,  1382,
    1385,  1386,  1388,  1393,  1396,  1397,  1402,  1407,  1410,  1411,
    1414,  1416,  1419,  1421,  1425,  1427,  1428,  1434,  1435,  1441,
    1444,  1445,  1450,  1452,  1457,  1462,  1465,  1466,  1468,  1473,
    1478,  1483,  1488,  1493,  1496,  1497,  1499,  1502,  1503,  1504,
    1513,  1514,  1522,  1525,  1526,  1531,  1536,  1541,  1543,  1545,
    1547,  1549,  1551,  1553,  1555,  1557,  1559,  1561,  1563,  1565,
    1567,  1569,  1571,  1573,  1575,  1577,  1579,  1581,  1583,  1585,
    1587,  1589,  1591,  1593,  1595,  1597,  1599,  1601,  1603,  1605,
    1607,  1609,  1611,  1614,  1615,  1617,  1619
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     157,     0,    -1,   158,    -1,    -1,   160,   151,   159,   158,
      -1,    -1,     3,   161,    -1,     6,   165,    -1,     7,   166,
      -1,     4,   162,    -1,     5,   163,    -1,   130,   164,    -1,
     100,   175,    -1,     8,   174,    -1,     9,   167,    -1,   320,
     152,   181,   153,    -1,   320,   152,   286,   151,   153,    -1,
     320,   152,   301,   151,   153,    -1,   320,   152,   311,   153,
      -1,   320,   152,   230,   153,    -1,   152,   168,   170,   172,
     153,    -1,   320,    -1,   169,   151,   168,    -1,    -1,     3,
     154,   320,   155,    -1,     4,   154,   320,   155,    -1,     5,
     154,   320,   155,    -1,   130,   154,   320,   155,    -1,     6,
     154,   320,   155,    -1,   171,   170,    -1,    -1,     7,   152,
     168,   170,   172,   153,   151,    -1,    82,   154,   173,   155,
     151,    -1,    -1,   320,   173,    -1,    -1,   152,   282,   153,
      -1,    -1,   320,   176,   152,   177,   153,    -1,   178,   151,
     177,    -1,    -1,   100,   154,   320,   155,    -1,   101,   154,
     318,   155,    -1,   116,   154,   145,   155,    -1,   117,   154,
     145,   155,    -1,   114,   154,   318,   155,    -1,   118,   154,
     318,   155,    -1,   179,    -1,   113,   154,   145,   155,    -1,
     115,   154,   145,   155,    -1,   182,   151,   181,    -1,    -1,
     183,    -1,   184,    -1,   190,    -1,   212,    -1,   222,    -1,
     219,    -1,    10,   154,   155,    -1,    11,   154,   185,   155,
      -1,    12,   154,   187,   155,    -1,    -1,   320,   186,   227,
      -1,    -1,   320,   188,   189,    -1,    92,   154,   318,   155,
      -1,   227,    -1,    14,   154,   195,   155,    -1,    13,   154,
     197,   155,    -1,    -1,    16,   191,   154,   201,   155,    -1,
      -1,    15,   192,   154,   206,   155,    -1,    -1,    18,   193,
     154,   201,   155,    -1,    -1,    17,   194,   154,   206,   155,
      -1,    -1,   320,   196,   199,    -1,    -1,   320,   198,   199,
      -1,   200,   199,    -1,    -1,    94,   154,   322,   155,    -1,
      95,   154,   322,   155,    -1,    96,   154,   145,   155,    -1,
      92,   154,   318,   155,    -1,   211,    -1,   228,    -1,   179,
      -1,    -1,   202,   203,    -1,   204,   203,    -1,    -1,   205,
      -1,   108,   154,   320,   155,    -1,   109,   154,   320,   155,
      -1,   110,   154,   322,   155,    -1,   111,   154,   322,   155,
      -1,   228,    -1,   180,    -1,    -1,   207,   208,    -1,   209,
     208,    -1,    -1,   205,    -1,    -1,    74,   210,   154,   284,
     155,    -1,   211,    -1,   106,   154,   318,   155,    -1,   107,
     154,   145,   155,    -1,    -1,    37,   213,   154,   214,   155,
      -1,    -1,   215,   216,    -1,   217,   216,    -1,    -1,   205,
      -1,    38,   154,   320,   155,    -1,    38,   154,    15,   155,
      -1,    38,   154,    16,   155,    -1,    38,   154,    74,   155,
      -1,    -1,    74,   218,   154,   284,   155,    -1,   211,    -1,
      22,   154,   220,   155,    -1,    -1,   320,   221,   227,    -1,
     141,    -1,    21,   154,   223,   155,    -1,   142,    -1,    -1,
     320,   224,   225,    -1,   226,   225,    -1,    -1,   141,    -1,
      20,   154,   320,   155,    -1,   142,    -1,   228,   227,    -1,
      -1,    69,   154,   145,   155,    -1,    49,   154,   318,   155,
      -1,    50,   154,   318,   155,    -1,    51,   154,   318,   155,
      -1,    56,   154,   318,   155,    -1,    55,   154,   319,   155,
      -1,    57,   154,   318,   155,    -1,    71,   154,   320,   155,
      -1,    72,   154,   320,   155,    -1,    70,   154,   320,   155,
      -1,    84,   154,   320,   155,    -1,    52,   154,   318,   155,
      -1,    82,   154,   229,   155,    -1,    46,   154,   145,   155,
      -1,    68,   154,   145,   155,    -1,    83,   154,   145,   155,
      -1,   102,   154,   146,   155,    -1,   102,   154,   145,   155,
      -1,    54,   154,   318,   155,    -1,    32,   154,   320,   155,
      -1,   105,   154,   325,   155,    -1,   104,   154,   326,   155,
      -1,   320,   229,    -1,    -1,   231,   151,   230,    -1,    -1,
     232,    -1,   237,    -1,   242,    -1,   270,    -1,   271,    -1,
     264,    -1,   274,    -1,    11,   154,   233,   155,    -1,    -1,
     320,   234,   235,    -1,   236,   235,    -1,    -1,   280,    -1,
      92,   154,   318,   155,    -1,    94,   154,   322,   155,    -1,
      95,   154,   322,   155,    -1,    96,   154,   145,   155,    -1,
      97,   154,   322,   155,    -1,    98,   154,   322,   155,    -1,
      99,   154,   145,   155,    -1,    93,   154,   318,   155,    -1,
     103,   154,   145,   155,    -1,    39,   154,   318,   155,    -1,
      87,   154,   320,   155,    -1,    12,   154,   238,   155,    -1,
      -1,   320,   239,   240,    -1,   241,   240,    -1,    -1,   280,
      -1,    94,   154,   322,   155,    -1,    95,   154,   322,   155,
      -1,    96,   154,   145,   155,    -1,    14,   154,   247,   155,
      -1,    13,   154,   249,   155,    -1,    -1,    16,   243,   154,
     253,   155,    -1,    -1,    15,   244,   154,   258,   155,    -1,
      -1,    18,   245,   154,   253,   155,    -1,    -1,    17,   246,
     154,   258,   155,    -1,    -1,   320,   248,   251,    -1,    -1,
     320,   250,   251,    -1,   251,   252,    -1,    -1,   280,    -1,
     263,    -1,   179,    -1,    -1,   320,   254,   255,    -1,   255,
     257,    -1,    -1,   108,   154,   320,   155,    -1,   110,   154,
     322,   155,    -1,   111,   154,   322,   155,    -1,   112,   154,
     322,   155,    -1,   180,    -1,   280,    -1,   263,    -1,   256,
      -1,   119,   154,   318,   155,    -1,    -1,   320,   259,   260,
      -1,   260,   261,    -1,    -1,   256,    -1,    -1,    74,   262,
     154,   284,   155,    -1,   106,   154,   318,   155,    -1,    37,
     154,   265,   155,    -1,    -1,   320,   266,   267,    -1,   267,
     268,    -1,    -1,   256,    -1,    38,   154,   320,   155,    -1,
      38,   154,    15,   155,    -1,    38,   154,    16,   155,    -1,
      38,   154,    74,   155,    -1,   119,   154,   318,   155,    -1,
      -1,    74,   269,   154,   284,   155,    -1,    19,   154,   320,
     155,    -1,    22,   154,   272,   155,    -1,    -1,   320,   273,
     279,    -1,    23,   154,   275,   155,    -1,    -1,   276,   277,
      -1,   278,   277,    -1,    -1,   141,    -1,    24,   154,   320,
     155,    -1,   123,   154,   320,   155,    -1,   111,   154,   322,
     155,    -1,    30,   154,   320,   155,    -1,    28,   154,   320,
     155,    -1,    29,   154,   320,   155,    -1,    31,   154,   320,
     155,    -1,    25,   154,   323,   155,    -1,    26,   154,   323,
     155,    -1,    27,   154,   323,   155,    -1,    66,   154,   145,
     155,    -1,    67,   154,   145,   155,    -1,    65,   154,   145,
     155,    -1,    84,   154,   320,   155,    -1,    87,   154,   320,
     155,    -1,    36,   154,   320,   155,    -1,   142,    -1,   280,
     279,    -1,    -1,    82,   154,   281,   155,    -1,    66,   154,
     145,   155,    -1,    43,   154,   145,   155,    -1,    45,   154,
     145,   155,    -1,    44,   154,   145,   155,    -1,   100,   154,
     320,   155,    -1,   101,   154,   318,   155,    -1,    84,   154,
     320,   155,    -1,    64,   154,   320,   155,    -1,    65,   154,
     145,   155,    -1,    73,   154,   145,   155,    -1,   320,   281,
      -1,    -1,   283,   151,   282,    -1,    -1,    40,   154,   145,
     155,    -1,    41,   154,   145,   155,    -1,    42,   154,   145,
     155,    -1,    43,   154,   145,   155,    -1,    45,   154,   145,
     155,    -1,    49,   154,   318,   155,    -1,    50,   154,   318,
     155,    -1,    51,   154,   318,   155,    -1,    52,   154,   318,
     155,    -1,    53,   154,   320,   155,    -1,   120,   154,   318,
     155,    -1,    56,   154,   318,   155,    -1,    55,   154,   319,
     155,    -1,    88,   154,   145,   155,    -1,    89,   154,   145,
     155,    -1,    90,   154,   145,   155,    -1,    66,   154,   145,
     155,    -1,    69,   154,   145,   155,    -1,    68,   154,   145,
     155,    -1,    46,   154,   145,   155,    -1,    54,   154,   318,
     155,    -1,    64,   154,   320,   155,    -1,    65,   154,   145,
     155,    -1,   136,   154,   145,   155,    -1,   135,   154,   145,
     155,    -1,    93,   154,   318,   155,    -1,    94,   154,   322,
     155,    -1,    95,   154,   322,   155,    -1,    96,   154,   145,
     155,    -1,    97,   154,   322,   155,    -1,    98,   154,   322,
     155,    -1,    99,   154,   145,   155,    -1,    57,   154,   318,
     155,    -1,    58,   154,   145,   155,    -1,    59,   154,   145,
     155,    -1,    60,   154,   145,   155,    -1,    61,   154,   320,
     155,    -1,    47,   154,   320,   155,    -1,    48,   154,   320,
     155,    -1,    85,   154,   320,   155,    -1,    86,   154,   320,
     155,    -1,    87,   154,   320,   155,    -1,   285,   284,    -1,
      -1,   141,    -1,    75,   154,   320,   155,    -1,    76,   154,
     320,   155,    -1,    77,   154,   320,   155,    -1,    78,   154,
     320,   155,    -1,    79,   154,   320,   155,    -1,    80,   154,
     323,   155,    -1,    81,   154,   323,   155,    -1,   142,    -1,
     287,    -1,   150,   286,    -1,   286,   148,   286,    -1,   286,
     149,   286,    -1,   154,   286,   155,    -1,   121,   154,   298,
     155,    -1,   121,   154,   145,   155,    -1,   122,   154,   299,
     155,    -1,     4,   154,   320,   155,    -1,   126,   154,   320,
     155,    -1,    -1,    22,   154,   320,   288,   295,   155,    -1,
      -1,   123,   154,   320,   289,   295,   155,    -1,    -1,   124,
     154,   320,   290,   293,   155,    -1,    -1,   125,   154,   320,
     291,   295,   155,    -1,    -1,     3,   154,   320,   292,   295,
     155,    -1,   294,   293,    -1,    -1,   296,    -1,   128,   154,
     320,   155,    -1,   296,   295,    -1,    -1,    24,   154,   320,
     155,    -1,    82,   154,   297,   155,    -1,   320,   297,    -1,
      -1,   326,   298,    -1,   326,    -1,   300,   299,    -1,   300,
      -1,   325,   143,   325,    -1,   325,    -1,    -1,   127,   154,
     302,   308,   155,    -1,    -1,   129,   154,   303,   304,   155,
      -1,   305,   304,    -1,    -1,    11,   154,   320,   155,    -1,
     307,    -1,    25,   154,   323,   155,    -1,   100,   154,   320,
     155,    -1,   309,   308,    -1,    -1,   306,    -1,    82,   154,
     310,   155,    -1,    33,   154,   320,   155,    -1,    34,   154,
     320,   155,    -1,    35,   154,   320,   155,    -1,    36,   154,
     320,   155,    -1,   320,   310,    -1,    -1,   312,    -1,   313,
     312,    -1,    -1,    -1,   132,   154,   320,   320,   314,   316,
     155,   151,    -1,    -1,   131,   154,   320,   315,   316,   155,
     151,    -1,   317,   316,    -1,    -1,   128,   154,   320,   155,
      -1,    24,   154,   320,   155,    -1,    82,   154,   297,   155,
      -1,   133,    -1,   134,    -1,   145,    -1,   318,    -1,    62,
      -1,   144,    -1,   147,    -1,   321,    -1,     5,    -1,   130,
      -1,     9,    -1,    25,    -1,    33,    -1,    34,    -1,    35,
      -1,    36,    -1,   127,    -1,   129,    -1,    32,    -1,   131,
      -1,   132,    -1,   128,    -1,    71,    -1,    72,    -1,    38,
      -1,    80,    -1,    81,    -1,   125,    -1,    24,    -1,    23,
      -1,   104,    -1,   105,    -1,   320,    -1,   145,    -1,   324,
      -1,   320,   324,    -1,    -1,   320,    -1,   320,    -1,    37,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   317,   317,   322,   321,   336,   340,   341,   342,   343,
     344,   345,   346,   347,   348,   352,   356,   360,   363,   366,
     370,   374,   377,   378,   382,   383,   384,   385,   386,   390,
     391,   395,   399,   400,   405,   406,   411,   416,   415,   424,
     425,   429,   430,   434,   435,   436,   437,   441,   442,   443,
     447,   448,   452,   453,   454,   455,   456,   457,   461,   465,
     466,   471,   470,   481,   480,   490,   491,   495,   496,   497,
     497,   498,   498,   499,   499,   500,   500,   505,   504,   518,
     517,   531,   532,   536,   537,   538,   539,   540,   541,   542,
     547,   547,   558,   559,   563,   567,   568,   569,   570,   571,
     572,   577,   577,   588,   589,   593,   596,   595,   608,   612,
     613,   617,   617,   622,   622,   633,   634,   638,   639,   640,
     641,   642,   644,   643,   655,   659,   664,   663,   673,   676,
     677,   684,   683,   694,   695,   699,   702,   703,   709,   710,
     714,   715,   716,   717,   718,   719,   720,   721,   722,   723,
     724,   725,   726,   727,   728,   729,   730,   731,   732,   733,
     734,   740,   749,   750,   755,   756,   760,   761,   762,   763,
     764,   765,   767,   772,   777,   776,   787,   788,   792,   793,
     794,   795,   796,   797,   798,   799,   800,   801,   802,   803,
     807,   812,   811,   822,   823,   827,   828,   829,   830,   834,
     835,   836,   836,   837,   837,   838,   838,   839,   839,   844,
     843,   855,   854,   865,   866,   870,   871,   872,   877,   876,
     889,   890,   895,   896,   897,   898,   899,   900,   901,   905,
     906,   911,   910,   923,   924,   928,   930,   929,   944,   949,
     953,   952,   964,   965,   969,   970,   971,   972,   973,   974,
     976,   975,   991,   995,  1000,   999,  1011,  1016,  1016,  1025,
    1026,  1030,  1033,  1034,  1035,  1036,  1037,  1038,  1039,  1040,
    1041,  1042,  1043,  1044,  1045,  1046,  1047,  1048,  1050,  1058,
    1059,  1063,  1064,  1065,  1066,  1067,  1068,  1076,  1077,  1078,
    1079,  1080,  1084,  1085,  1090,  1091,  1095,  1096,  1097,  1098,
    1099,  1100,  1101,  1102,  1103,  1104,  1105,  1106,  1107,  1108,
    1109,  1110,  1119,  1120,  1121,  1122,  1123,  1124,  1125,  1126,
    1127,  1128,  1129,  1130,  1131,  1132,  1133,  1134,  1135,  1136,
    1137,  1138,  1140,  1141,  1142,  1143,  1144,  1145,  1150,  1151,
    1155,  1159,  1164,  1169,  1174,  1179,  1184,  1188,  1192,  1200,
    1201,  1202,  1203,  1204,  1208,  1209,  1210,  1211,  1212,  1214,
    1213,  1226,  1225,  1238,  1237,  1261,  1260,  1272,  1271,  1286,
    1287,  1291,  1292,  1296,  1297,  1301,  1306,  1310,  1311,  1316,
    1317,  1321,  1322,  1326,  1330,  1339,  1338,  1345,  1344,  1353,
    1354,  1359,  1363,  1364,  1368,  1381,  1382,  1386,  1387,  1388,
    1389,  1390,  1391,  1395,  1396,  1400,  1404,  1405,  1410,  1409,
    1422,  1421,  1430,  1431,  1435,  1436,  1447,  1451,  1452,  1453,
    1457,  1458,  1462,  1463,  1464,  1469,  1470,  1471,  1472,  1473,
    1474,  1475,  1476,  1477,  1478,  1479,  1480,  1481,  1482,  1483,
    1484,  1485,  1486,  1487,  1488,  1489,  1490,  1491,  1492,  1496,
    1497,  1501,  1505,  1506,  1510,  1527,  1541
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "KW_SOURCE", "KW_FILTER", "KW_PARSER",
  "KW_DESTINATION", "KW_LOG", "KW_OPTIONS", "KW_INCLUDE", "KW_INTERNAL",
  "KW_FILE", "KW_PIPE", "KW_UNIX_STREAM", "KW_UNIX_DGRAM", "KW_TCP",
  "KW_UDP", "KW_TCP6", "KW_UDP6", "KW_USERTTY", "KW_DOOR",
  "KW_SUN_STREAMS", "KW_PROGRAM", "KW_SQL", "KW_TYPE", "KW_COLUMNS",
  "KW_INDEXES", "KW_VALUES", "KW_PASSWORD", "KW_DATABASE", "KW_USERNAME",
  "KW_TABLE", "KW_ENCODING", "KW_DELIMITERS", "KW_QUOTES",
  "KW_QUOTE_PAIRS", "KW_NULL", "KW_SYSLOG", "KW_TRANSPORT", "KW_FSYNC",
  "KW_MARK_FREQ", "KW_STATS_FREQ", "KW_STATS_LEVEL", "KW_FLUSH_LINES",
  "KW_SUPPRESS", "KW_FLUSH_TIMEOUT", "KW_LOG_MSG_SIZE", "KW_FILE_TEMPLATE",
  "KW_PROTO_TEMPLATE", "KW_CHAIN_HOSTNAMES", "KW_NORMALIZE_HOSTNAMES",
  "KW_KEEP_HOSTNAME", "KW_CHECK_HOSTNAME", "KW_BAD_HOSTNAME",
  "KW_KEEP_TIMESTAMP", "KW_USE_DNS", "KW_USE_FQDN", "KW_DNS_CACHE",
  "KW_DNS_CACHE_SIZE", "KW_DNS_CACHE_EXPIRE", "KW_DNS_CACHE_EXPIRE_FAILED",
  "KW_DNS_CACHE_HOSTS", "KW_PERSIST_ONLY", "KW_TZ_CONVERT", "KW_TS_FORMAT",
  "KW_FRAC_DIGITS", "KW_LOG_FIFO_SIZE", "KW_LOG_DISK_FIFO_SIZE",
  "KW_LOG_FETCH_LIMIT", "KW_LOG_IW_SIZE", "KW_LOG_PREFIX",
  "KW_PROGRAM_OVERRIDE", "KW_HOST_OVERRIDE", "KW_THROTTLE", "KW_TLS",
  "KW_PEER_VERIFY", "KW_KEY_FILE", "KW_CERT_FILE", "KW_CA_DIR",
  "KW_CRL_DIR", "KW_TRUSTED_KEYS", "KW_TRUSTED_DN", "KW_FLAGS",
  "KW_PAD_SIZE", "KW_TIME_ZONE", "KW_RECV_TIME_ZONE", "KW_SEND_TIME_ZONE",
  "KW_LOCAL_TIME_ZONE", "KW_TIME_REOPEN", "KW_TIME_REAP", "KW_TIME_SLEEP",
  "KW_TMPL_ESCAPE", "KW_OPTIONAL", "KW_CREATE_DIRS", "KW_OWNER",
  "KW_GROUP", "KW_PERM", "KW_DIR_OWNER", "KW_DIR_GROUP", "KW_DIR_PERM",
  "KW_TEMPLATE", "KW_TEMPLATE_ESCAPE", "KW_FOLLOW_FREQ",
  "KW_OVERWRITE_IF_OLDER", "KW_DEFAULT_FACILITY", "KW_DEFAULT_LEVEL",
  "KW_KEEP_ALIVE", "KW_MAX_CONNECTIONS", "KW_LOCALIP", "KW_IP",
  "KW_LOCALPORT", "KW_PORT", "KW_DESTPORT", "KW_IP_TTL", "KW_SO_BROADCAST",
  "KW_IP_TOS", "KW_SO_SNDBUF", "KW_SO_RCVBUF", "KW_SO_KEEPALIVE",
  "KW_SPOOF_SOURCE", "KW_USE_TIME_RECVD", "KW_FACILITY", "KW_LEVEL",
  "KW_HOST", "KW_MATCH", "KW_MESSAGE", "KW_NETMASK", "KW_CSV_PARSER",
  "KW_VALUE", "KW_DB_PARSER", "KW_REWRITE", "KW_SET", "KW_SUBST", "KW_YES",
  "KW_NO", "KW_GC_IDLE_THRESHOLD", "KW_GC_BUSY_THRESHOLD", "KW_COMPRESS",
  "KW_MAC", "KW_AUTH", "KW_ENCRYPT", "KW_IFDEF", "KW_ENDIF", "LL_DOTDOT",
  "LL_IDENTIFIER", "LL_NUMBER", "LL_FLOAT", "LL_STRING", "KW_OR", "KW_AND",
  "KW_NOT", "';'", "'{'", "'}'", "'('", "')'", "$accept", "start", "stmts",
  "$@1", "stmt", "source_stmt", "filter_stmt", "parser_stmt",
  "rewrite_stmt", "dest_stmt", "log_stmt", "include_stmt", "log_items",
  "log_item", "log_forks", "log_fork", "log_flags", "log_flags_items",
  "options_stmt", "template_stmt", "$@2", "template_items",
  "template_item", "socket_option", "inet_socket_option", "source_items",
  "source_item", "source_afinter", "source_affile", "source_affile_params",
  "$@3", "source_afpipe_params", "$@4", "source_afpipe_options",
  "source_afsocket", "$@5", "$@6", "$@7", "$@8",
  "source_afunix_dgram_params", "$@9", "source_afunix_stream_params",
  "$@10", "source_afunix_options", "source_afunix_option",
  "source_afinet_udp_params", "$@11", "source_afinet_udp_options",
  "source_afinet_udp_option", "source_afinet_option",
  "source_afinet_tcp_params", "$@12", "source_afinet_tcp_options",
  "source_afinet_tcp_option", "$@13", "source_afsocket_stream_params",
  "source_afsyslog", "$@14", "source_afsyslog_params", "$@15",
  "source_afsyslog_options", "source_afsyslog_option", "$@16",
  "source_afprogram", "source_afprogram_params", "$@17",
  "source_afstreams", "source_afstreams_params", "$@18",
  "source_afstreams_options", "source_afstreams_option",
  "source_reader_options", "source_reader_option",
  "source_reader_option_flags", "dest_items", "dest_item", "dest_affile",
  "dest_affile_params", "$@19", "dest_affile_options",
  "dest_affile_option", "dest_afpipe", "dest_afpipe_params", "$@20",
  "dest_afpipe_options", "dest_afpipe_option", "dest_afsocket", "$@21",
  "$@22", "$@23", "$@24", "dest_afunix_dgram_params", "$@25",
  "dest_afunix_stream_params", "$@26", "dest_afunix_options",
  "dest_afunix_option", "dest_afinet_udp_params", "$@27",
  "dest_afinet_udp_options", "dest_afinet_option",
  "dest_afinet_udp_option", "dest_afinet_tcp_params", "$@28",
  "dest_afinet_tcp_options", "dest_afinet_tcp_option", "$@29",
  "dest_afsocket_option", "dest_afsyslog", "dest_afsyslog_params", "$@30",
  "dest_afsyslog_options", "dest_afsyslog_option", "$@31", "dest_afuser",
  "dest_afprogram", "dest_afprogram_params", "$@32", "dest_afsql",
  "dest_afsql_params", "$@33", "dest_afsql_options", "dest_afsql_option",
  "dest_writer_options", "dest_writer_option", "dest_writer_options_flags",
  "options_items", "options_item", "tls_options", "tls_option",
  "filter_expr", "filter_simple_expr", "$@34", "$@35", "$@36", "$@37",
  "$@38", "filter_match_opts", "filter_match_opt", "filter_re_opts",
  "filter_re_opt", "regexp_option_flags", "filter_fac_list",
  "filter_level_list", "filter_level", "parser_expr", "$@39", "$@40",
  "parser_db_opts", "parser_db_opt", "parser_column_opt", "parser_opt",
  "parser_csv_opts", "parser_csv_opt", "parser_csv_flags",
  "rewrite_expr_list", "rewrite_expr_list_build", "rewrite_expr", "$@41",
  "$@42", "rewrite_expr_opts", "rewrite_expr_opt", "yesno", "dnsmode",
  "string", "reserved_words_as_strings", "string_or_number", "string_list",
  "string_list_build", "level_string", "facility_string", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,    59,   123,   125,    40,    41
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   156,   157,   159,   158,   158,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   161,   162,   163,   164,   165,
     166,   167,   168,   168,   169,   169,   169,   169,   169,   170,
     170,   171,   172,   172,   173,   173,   174,   176,   175,   177,
     177,   178,   178,   179,   179,   179,   179,   180,   180,   180,
     181,   181,   182,   182,   182,   182,   182,   182,   183,   184,
     184,   186,   185,   188,   187,   189,   189,   190,   190,   191,
     190,   192,   190,   193,   190,   194,   190,   196,   195,   198,
     197,   199,   199,   200,   200,   200,   200,   200,   200,   200,
     202,   201,   203,   203,   204,   205,   205,   205,   205,   205,
     205,   207,   206,   208,   208,   209,   210,   209,   209,   211,
     211,   213,   212,   215,   214,   216,   216,   217,   217,   217,
     217,   217,   218,   217,   217,   219,   221,   220,   222,   222,
     222,   224,   223,   225,   225,   226,   226,   226,   227,   227,
     228,   228,   228,   228,   228,   228,   228,   228,   228,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   228,   228,
     228,   228,   229,   229,   230,   230,   231,   231,   231,   231,
     231,   231,   231,   232,   234,   233,   235,   235,   236,   236,
     236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
     237,   239,   238,   240,   240,   241,   241,   241,   241,   242,
     242,   243,   242,   244,   242,   245,   242,   246,   242,   248,
     247,   250,   249,   251,   251,   252,   252,   252,   254,   253,
     255,   255,   256,   256,   256,   256,   256,   256,   256,   257,
     257,   259,   258,   260,   260,   261,   262,   261,   263,   264,
     266,   265,   267,   267,   268,   268,   268,   268,   268,   268,
     269,   268,   270,   271,   273,   272,   274,   276,   275,   277,
     277,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   279,
     279,   280,   280,   280,   280,   280,   280,   280,   280,   280,
     280,   280,   281,   281,   282,   282,   283,   283,   283,   283,
     283,   283,   283,   283,   283,   283,   283,   283,   283,   283,
     283,   283,   283,   283,   283,   283,   283,   283,   283,   283,
     283,   283,   283,   283,   283,   283,   283,   283,   283,   283,
     283,   283,   283,   283,   283,   283,   283,   283,   284,   284,
     285,   285,   285,   285,   285,   285,   285,   285,   285,   286,
     286,   286,   286,   286,   287,   287,   287,   287,   287,   288,
     287,   289,   287,   290,   287,   291,   287,   292,   287,   293,
     293,   294,   294,   295,   295,   296,   296,   297,   297,   298,
     298,   299,   299,   300,   300,   302,   301,   303,   301,   304,
     304,   305,   306,   306,   307,   308,   308,   309,   309,   309,
     309,   309,   309,   310,   310,   311,   312,   312,   314,   313,
     315,   313,   316,   316,   317,   317,   317,   318,   318,   318,
     319,   319,   320,   320,   320,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   321,   321,   321,   321,   322,
     322,   323,   324,   324,   325,   326,   326
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     0,     4,     0,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     4,     5,     5,     4,     4,
       5,     1,     3,     0,     4,     4,     4,     4,     4,     2,
       0,     7,     5,     0,     2,     0,     3,     0,     5,     3,
       0,     4,     4,     4,     4,     4,     4,     1,     4,     4,
       3,     0,     1,     1,     1,     1,     1,     1,     3,     4,
       4,     0,     3,     0,     3,     4,     1,     4,     4,     0,
       5,     0,     5,     0,     5,     0,     5,     0,     3,     0,
       3,     2,     0,     4,     4,     4,     4,     1,     1,     1,
       0,     2,     2,     0,     1,     4,     4,     4,     4,     1,
       1,     0,     2,     2,     0,     1,     0,     5,     1,     4,
       4,     0,     5,     0,     2,     2,     0,     1,     4,     4,
       4,     4,     0,     5,     1,     4,     0,     3,     1,     4,
       1,     0,     3,     2,     0,     1,     4,     1,     2,     0,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     2,     0,     3,     0,     1,     1,     1,     1,
       1,     1,     1,     4,     0,     3,     2,     0,     1,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     0,     3,     2,     0,     1,     4,     4,     4,     4,
       4,     0,     5,     0,     5,     0,     5,     0,     5,     0,
       3,     0,     3,     2,     0,     1,     1,     1,     0,     3,
       2,     0,     4,     4,     4,     4,     1,     1,     1,     1,
       4,     0,     3,     2,     0,     1,     0,     5,     4,     4,
       0,     3,     2,     0,     1,     4,     4,     4,     4,     4,
       0,     5,     4,     4,     0,     3,     4,     0,     2,     2,
       0,     1,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     1,     2,
       0,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     2,     0,     3,     0,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     2,     0,
       1,     4,     4,     4,     4,     4,     4,     4,     1,     1,
       2,     3,     3,     3,     4,     4,     4,     4,     4,     0,
       6,     0,     6,     0,     6,     0,     6,     0,     6,     2,
       0,     1,     4,     2,     0,     4,     4,     2,     0,     2,
       1,     2,     1,     3,     1,     0,     5,     0,     5,     2,
       0,     4,     1,     4,     4,     2,     0,     1,     4,     4,
       4,     4,     4,     2,     0,     1,     2,     0,     0,     8,
       0,     7,     2,     0,     4,     4,     4,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     0,     1,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       5,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     2,     0,   425,   427,   446,   445,   428,   435,   429,
     430,   431,   432,   441,   439,   440,   442,   443,   447,   448,
     444,   433,   438,   434,   426,   436,   437,   422,   423,     6,
       0,   424,     9,     0,    10,     0,     7,     0,    23,     8,
     295,    13,    14,    21,    12,    37,    11,     0,     1,     3,
      51,     0,     0,   165,     0,     0,     0,     0,     0,    30,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   407,     5,     0,     0,
       0,     0,     0,    71,    69,    75,    73,     0,     0,   111,
     128,   130,     0,     0,    52,    53,    54,    55,    57,    56,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   349,     0,     0,     0,     0,     0,     0,     0,
     203,   201,   207,   205,     0,     0,     0,     0,     0,     0,
     166,   167,   168,   171,   169,   170,   172,     0,     0,     0,
       0,     0,     0,    33,    30,    23,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    36,   295,
      40,     0,     0,     0,   405,   407,     4,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    15,
      51,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     350,     0,     0,     0,     0,   385,   387,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   257,     0,
      19,   165,     0,     0,     0,     0,     0,    23,     0,     0,
      29,    22,     0,     0,     0,     0,     0,     0,     0,     0,
     417,   418,   419,     0,     0,     0,     0,     0,     0,   421,
     420,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     450,   449,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   294,     0,     0,     0,     0,     0,     0,    18,   406,
      58,     0,    61,     0,    63,     0,    79,     0,    77,   101,
      90,   101,    90,     0,   131,     0,   126,   113,    50,   367,
       0,   359,   456,     0,     0,   455,   380,     0,   382,   454,
     384,   361,   363,   365,     0,   353,   351,   352,    16,   396,
     390,    17,     0,   174,     0,   191,     0,   211,     0,   209,
       0,     0,     0,     0,     0,     0,   254,     0,   260,     0,
     240,   164,    24,    25,    26,    28,    27,    30,    35,    20,
     296,   297,   298,   299,   300,   315,   333,   334,   301,   302,
     303,   304,   305,   316,   308,   307,   328,   329,   330,   331,
     332,   317,   318,   312,   314,   313,   335,   336,   337,   309,
     310,   311,   321,   322,   323,   324,   325,   326,   327,   306,
     320,   319,     0,     0,    38,    40,   410,     0,    59,   139,
      60,   139,    68,    82,    67,    82,     0,   104,     0,    93,
       0,     0,   129,   134,   125,   139,     0,   116,   374,   357,
     374,   355,   354,   379,   356,   381,     0,   374,   370,   374,
     358,     0,     0,     0,     0,     0,     0,     0,   397,   392,
       0,   396,     0,     0,   390,   173,   177,   190,   194,   200,
     214,   199,   214,     0,   231,     0,   218,     0,     0,   252,
     253,   280,   256,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   261,
     278,   258,   260,   239,   243,    33,     0,    35,     0,     0,
      39,   413,   408,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    62,   139,     0,    64,    66,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    89,
      80,    82,    87,    88,    78,    72,   106,     0,     0,     0,
       0,     0,     0,    47,   100,   105,   102,   104,   108,    99,
      70,    91,    93,    94,    76,    74,     0,   135,   137,   132,
     134,   127,   112,     0,   122,   117,   124,   114,   116,     0,
       0,     0,   374,     0,   383,     0,     0,     0,   370,   371,
       0,   453,     0,     0,     0,     0,   404,     0,   386,   395,
       0,   388,   389,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   175,   177,   178,     0,     0,
       0,   192,   194,   195,   212,   210,   204,   234,   202,   221,
     208,   206,   255,   280,     0,   453,   453,   453,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     259,   241,     0,     0,    34,    41,    42,     0,     0,     0,
       0,   413,   413,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   163,     0,
       0,     0,     0,     0,   138,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    81,     0,     0,     0,
       0,     0,     0,     0,   103,    92,     0,   133,     0,     0,
     115,     0,   378,   368,   373,   360,   362,     0,   364,   369,
     366,   453,     0,   451,     0,     0,     0,     0,     0,   404,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     293,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   176,     0,     0,     0,   193,     0,
     217,   213,   216,   215,   232,   219,   279,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   250,     0,     0,     0,     0,     0,
     226,   244,   228,   242,   227,     0,    32,     0,   378,     0,
       0,   412,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   163,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   339,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   339,
       0,     0,   378,     0,   452,   393,   399,   400,   401,   402,
     398,   403,   394,   391,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   293,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   236,   235,   233,     0,   229,   220,   262,   269,   270,
     271,   266,   267,   265,   268,   277,   274,   272,   273,   275,
     276,   264,   263,     0,     0,     0,     0,     0,     0,     0,
      31,     0,     0,     0,   411,     0,   159,   153,   141,   142,
     143,   151,   158,   145,   144,   146,   154,   140,   149,   147,
     148,   152,   162,   155,   150,   157,   156,   161,   160,    65,
      86,    83,    84,    85,   109,   110,    45,    43,    44,    46,
       0,     0,     0,     0,     0,     0,     0,   340,   348,     0,
     339,    95,    96,    97,    98,    48,    49,   136,   119,   120,
     121,   118,     0,   375,   376,   377,   372,   188,   283,   285,
     284,   289,   290,   282,   291,   281,   292,   288,   189,   179,
     186,   180,   181,   182,   183,   184,   185,   286,   287,   187,
     196,   197,   198,     0,     0,     0,     0,     0,     0,     0,
     339,     0,     0,     0,     0,     0,   415,   416,   414,   409,
       0,     0,     0,     0,     0,   453,   453,   107,   338,   123,
     238,   339,     0,   246,   247,   248,   245,     0,   222,   223,
     224,   225,   249,     0,     0,     0,     0,     0,     0,     0,
       0,   230,   251,   341,   342,   343,   344,   345,   346,   347,
     237
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    10,    11,   117,    12,    39,    42,    44,    56,    46,
      49,    52,    69,    70,   183,   184,   289,   556,    51,    54,
     115,   344,   345,   613,   614,   132,   133,   134,   135,   351,
     469,   353,   471,   587,   136,   243,   242,   245,   244,   357,
     475,   355,   473,   600,   601,   478,   479,   621,   622,   615,
     476,   477,   616,   617,   767,   602,   137,   248,   486,   487,
     637,   638,   779,   138,   365,   485,   139,   363,   483,   629,
     630,   584,   619,   888,   168,   169,   170,   392,   516,   685,
     686,   171,   394,   518,   691,   692,   172,   273,   272,   275,
     274,   398,   522,   396,   520,   694,   831,   525,   699,   835,
     861,   966,   523,   697,   834,   963,  1084,   862,   173,   409,
     554,   721,   863,   984,   174,   175,   405,   531,   176,   407,
     408,   551,   552,   702,   864,   942,   113,   114,  1039,  1040,
     151,   152,   490,   497,   498,   499,   488,   647,   648,   641,
     642,   921,   374,   377,   378,   155,   389,   390,   513,   514,
     508,   509,   510,   511,   798,   233,   234,   235,   732,   561,
     730,   731,   310,   311,   331,    41,   332,   792,   793,   380,
     376
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -908
static const yytype_int16 yypact[] =
{
      51,  1050,  1050,  1050,  1050,  -100,   -90,  1050,  1050,  1050,
      72,  -908,   -68,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
     -67,  -908,  -908,   -63,  -908,   -61,  -908,   -59,    73,  -908,
    1158,  -908,  -908,  -908,  -908,  -908,  -908,   -55,  -908,  -908,
      53,    39,   -76,   587,   -42,   -40,   -25,   -22,   -20,   109,
     -21,   -19,   -18,   -17,   -16,   -15,   -14,   -11,    -8,    -7,
      -4,    -2,     2,     5,    14,    16,    17,    18,    20,    21,
      28,    32,    36,    42,    45,    46,    48,    54,    61,    62,
      63,    65,    66,    75,    76,    77,    78,    82,    87,    88,
      89,    90,    94,    96,   108,   113,   -36,    51,   106,   112,
     117,   118,   119,  -908,  -908,  -908,  -908,   120,   123,  -908,
    -908,  -908,   126,   129,  -908,  -908,  -908,  -908,  -908,  -908,
     128,   131,   140,   141,   143,   144,   145,   147,   148,    39,
      39,   -38,  -908,   149,   150,   132,   151,   155,   156,   163,
    -908,  -908,  -908,  -908,   164,   165,   167,   168,   175,   179,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  1050,  1050,  1050,
    1050,  1050,   183,   249,   109,    73,   191,   192,   195,   198,
     199,   202,  1050,  1050,   -53,   -53,   -53,   -53,  1050,   -53,
     -30,   -53,   -53,   203,   204,   206,  1050,  1050,   210,   211,
     213,   214,  1050,  1050,  1050,   215,   216,   219,   -53,   892,
     892,   221,   892,   892,   222,   -53,   225,   228,  -908,  1158,
       1,   188,   234,   236,  -908,   -36,  -908,   235,  1050,  1050,
    1050,  1050,   237,   238,   239,   240,  1050,  1050,   243,  -908,
      53,  1050,  1050,  1050,   809,  1050,  1050,  1050,  1050,  1050,
    -908,   -49,    39,    39,   245,  -908,  -908,   250,  1050,  1050,
    1050,  1050,   251,   257,   258,   259,  1050,  1050,  -908,  1050,
    -908,   587,   260,   269,   270,   271,   275,    73,   277,   261,
    -908,  -908,   278,   279,   282,   284,   285,   286,   287,   288,
    -908,  -908,  -908,   289,   294,   295,   296,   297,   301,  -908,
    -908,   305,   307,   310,   312,   313,   315,   316,   317,   322,
     323,   326,   327,   330,   331,   335,   336,   338,   346,   348,
    -908,  -908,   349,   350,   351,   352,   353,   354,   357,   358,
     359,  -908,   292,   361,   364,   253,  1050,  1050,  -908,  -908,
    -908,   375,  -908,   376,  -908,   377,  -908,   378,  -908,  -908,
    -908,  -908,  -908,   382,  -908,   384,  -908,  -908,  -908,  -908,
     385,  -908,  -908,   386,   387,  -908,  1009,   388,  1050,  -908,
     403,  -908,  -908,  -908,   392,  -908,   208,  -908,  -908,    84,
     421,  -908,   393,  -908,   394,  -908,   395,  -908,   396,  -908,
    1050,  1050,  1050,  1050,   397,   398,  -908,   399,   197,   400,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,   109,  1050,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  1050,   -53,  -908,     1,  -908,  1050,  -908,  1584,
    -908,  1540,  -908,  1390,  -908,  1390,   402,  1310,   408,  1466,
     411,   412,  -908,     3,  -908,  1584,   415,  1230,    23,  -908,
      23,  -908,  -908,  -908,  -908,  -908,  1050,    23,    25,    23,
    -908,   365,   417,   418,   422,   423,   426,   427,  -908,  -908,
     420,    84,   428,   429,   421,  -908,  1618,  -908,   363,  -908,
    -908,  -908,  -908,   435,  -908,   442,  -908,   452,   457,  -908,
    -908,   792,  -908,   459,   460,   461,   462,   463,   465,   466,
     467,   468,   469,   472,   473,   474,   475,   476,   479,  -908,
    -908,  -908,   197,  -908,  -908,   249,   483,  1050,   484,   485,
    -908,    26,  -908,   489,   490,   492,   493,   494,   495,   503,
     504,   506,   507,   508,   509,   510,   511,   512,   513,   514,
     515,   516,   517,   518,  -908,  1584,   519,  -908,  -908,   520,
     521,   522,   523,   524,   525,   526,   527,   528,   529,  -908,
    -908,  1390,  -908,  -908,  -908,  -908,  -908,   530,   531,   532,
     533,   534,   535,  -908,  -908,  -908,  -908,  1310,  -908,  -908,
    -908,  -908,  1466,  -908,  -908,  -908,   536,  -908,  -908,  -908,
       3,  -908,  -908,   537,  -908,  -908,  -908,  -908,  1230,   538,
     539,   540,    23,   541,  -908,   542,   547,   557,    25,  -908,
     558,  1050,  1050,  1050,  1050,  1050,  1050,  1050,  -908,  -908,
    1050,  -908,  -908,   548,   560,   563,   568,   569,   570,   571,
     572,   573,   575,   576,   577,   579,   580,   581,   582,   584,
     586,   588,   589,   594,   596,  -908,  1618,  -908,   599,   600,
     603,  -908,   363,  -908,   655,   655,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,   792,  1050,  1050,  1050,  1050,  1050,  1050,
    1050,  1050,  1050,   549,   613,   614,  1050,  1050,   892,  1050,
    -908,   410,   607,   590,  -908,  -908,  -908,   608,   609,   610,
     611,    26,    26,  1050,   620,   -53,   -53,   -53,   -53,   -53,
     -30,   -53,   -53,   625,   629,  1050,  1050,  1050,  1050,   631,
    1050,   -24,  1009,  1050,  -908,   -53,   -53,   892,   892,   633,
     -53,   634,   -53,   637,   639,   -53,  -908,   635,  1050,  1050,
     892,   892,   640,   642,  -908,  -908,  1050,  -908,   291,   638,
    -908,  1050,  1050,  -908,  -908,  -908,  -908,  1050,  -908,  -908,
    -908,  1050,   636,  -908,   641,   644,   645,   646,   651,  1050,
     652,   653,   -53,   643,   648,   649,  1050,   650,   668,   670,
    1050,  1050,  1050,   -53,   -53,   892,   892,   671,   892,   892,
     672,  1050,   -53,   674,  -908,   892,   892,   676,  -908,   669,
    -908,  -908,  -908,  -908,  1051,   268,  -908,   667,   673,   675,
     683,   684,   685,   693,   694,   695,   696,   697,   698,   699,
     700,   704,   705,   677,  -908,   707,   708,   709,   710,   715,
    -908,  -908,  -908,  -908,  -908,   678,  -908,  1050,  1050,  1050,
     719,  -908,   716,   717,   718,   720,   722,   723,   724,   727,
     728,   729,   730,   731,   732,   736,   739,   740,   741,  1050,
     743,   744,   745,   747,   748,   749,   750,   751,   752,   754,
     755,   756,   757,   763,   764,   765,   767,   212,   768,   774,
     776,   777,   778,   780,   788,   789,   790,   791,   793,   212,
     794,   795,  1050,   796,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,   797,   800,   802,   803,   804,   805,
     806,   807,   810,  1050,   811,   812,   813,   814,   815,   816,
     819,   820,   821,   822,   823,   824,   825,   826,   828,   830,
     -53,  -908,  -908,  -908,   832,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,   464,   833,  1050,   892,   892,   892,   -53,
    -908,   834,   835,   836,  -908,   837,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
     838,   839,   840,   841,   844,   845,   846,  -908,  -908,   847,
     212,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,   848,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,   849,   851,   -53,   852,   853,   854,   855,
     212,   856,   857,   858,   860,   861,  -908,  -908,  -908,  -908,
    1050,  1050,  1050,  1050,  1050,  1050,  1050,  -908,  -908,  -908,
    -908,   212,   870,  -908,  -908,  -908,  -908,   871,  -908,  -908,
    -908,  -908,  -908,   872,   873,   874,   875,   876,   880,   883,
     885,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -908,  -908,   501,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -156,  -908,  -170,  -908,   242,   267,  -908,  -908,
    -908,   360,  -908,  -460,  -686,   798,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -459,  -908,   585,  -908,   205,  -908,  -453,
     688,  -908,   209,  -908,  -908,  -450,  -908,  -908,  -908,  -908,
     368,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,   371,
    -908,  -398,  -387,   161,   770,  -908,  -908,  -908,  -908,   366,
    -908,  -908,  -908,  -908,   362,  -908,  -908,  -908,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,   543,  -908,   654,  -908,  -908,
    -711,  -908,   656,  -908,  -908,  -908,  -908,  -569,  -908,  -908,
    -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,  -908,
    -908,   545,  -908,   367,  -485,   110,   827,  -908,  -907,  -908,
    -105,  -908,  -908,  -908,  -908,  -908,  -908,   413,  -908,  -469,
    -493,  -828,   686,   682,  -908,  -908,  -908,  -908,   550,  -908,
    -908,  -908,   552,  -908,   272,  -908,   831,  -908,  -908,  -908,
    -604,  -908,  -177,   328,    -1,  -908,  -184,  -696,   276,  -492,
     320
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint16 yytable[] =
{
      40,    43,    45,    47,   644,   649,    53,    55,    57,   838,
     839,   840,  1052,   599,   290,   599,   604,   303,   304,   305,
     306,   643,   308,   626,   312,   313,   623,   618,   645,   291,
     650,   687,   309,   693,   635,   860,   333,   636,   335,   336,
     992,   329,   140,   141,   260,   261,   703,   639,   338,   639,
     727,   153,    48,   154,     1,     2,     3,     4,     5,     6,
       7,   142,    50,   118,   119,   120,   121,   122,   123,   124,
     125,   126,    58,   588,   127,   128,    64,    65,    66,    67,
     300,   301,   585,    59,   585,    60,   603,   631,   603,    61,
     129,    62,   302,    63,  1055,   231,   232,   116,   585,   262,
     263,   342,   343,   300,   301,   640,   385,   640,   728,   501,
     262,   263,   177,   264,   178,   302,   182,   502,   503,   504,
     505,   892,   893,   962,   965,   832,   832,   871,   872,   179,
     185,   417,   180,  1108,   181,   186,   187,   188,   189,   190,
     191,   599,   766,   192,   627,   628,   193,   194,   860,   860,
     195,     8,   196,   646,   729,   649,   197,   386,   387,   198,
     143,   144,   145,   146,   147,   148,   506,   618,   199,   623,
     200,   201,   202,   784,   203,   204,   282,   283,   284,   285,
     286,     9,   205,  1117,   507,   635,   206,   754,   636,   149,
     207,   298,   299,   150,   130,   131,   208,   307,   585,   209,
     210,   687,   211,    68,  1130,   317,   318,   693,   212,   833,
     833,   323,   324,   325,   603,   213,   214,   215,   703,   216,
     217,   533,   534,   535,   536,   537,   538,   539,   540,   218,
     219,   220,   221,   541,   830,   830,   222,   352,   354,   356,
     358,   223,   224,   225,   226,   364,   366,   555,   227,   228,
     369,   370,   371,   375,   379,   381,   382,   383,   384,   229,
     237,   895,   542,   543,   544,   230,   238,   393,   395,   397,
     399,   239,   240,   241,   246,   404,   406,   247,   410,   249,
     250,   545,   251,   267,   546,   252,   559,  1030,  1031,  1032,
    1033,  1034,  1035,  1036,   253,   254,    13,   255,   256,   257,
      14,   258,   259,   265,   266,   268,   915,   916,   547,   269,
     270,   664,   665,   666,    15,    16,    17,   271,   276,   277,
     548,   278,   279,    18,    19,    20,    21,    22,   280,    23,
     281,   288,   667,   668,   669,   287,   292,   293,   549,   550,
     294,   670,   346,   295,   296,   466,   467,   297,   314,   315,
     671,   316,   672,  1037,  1038,   319,   320,   263,   321,   322,
     326,   327,    24,    25,   328,   917,   334,   337,   682,   683,
     339,    26,    27,   340,   829,   375,   855,   379,   856,   857,
     858,   611,   595,   612,   596,   597,   598,   964,   347,   348,
     350,   359,   360,   361,   362,    28,    29,   367,   388,   524,
     526,   524,   526,   391,   465,   400,   664,   665,   666,  1128,
    1129,   401,   402,   403,   419,   412,    30,   557,    31,    32,
      33,    34,    35,    36,   413,   414,   415,   667,   668,   669,
     416,   418,   512,   420,   421,    37,   670,   422,    38,   423,
     424,   425,   426,   427,   428,   671,   462,   672,   853,   429,
     430,   431,   432,   664,   665,   666,   433,   688,   689,   690,
     434,   558,   435,   682,   683,   436,   562,   437,   438,    13,
     439,   440,   441,    14,   667,   668,   669,   442,   443,  1086,
    1087,   444,   445,   670,   854,   446,   447,    15,    16,    17,
     448,   449,   671,   450,   672,   379,    18,    19,    20,    21,
      22,   451,    23,   452,   453,   454,   455,   456,   457,   458,
     682,   683,   459,   460,   461,   463,   829,   464,   855,   651,
     856,   857,   858,   611,   595,   612,   596,   597,   598,   859,
     468,   470,   472,   474,   851,    24,    25,   482,  1088,   484,
     489,   491,   492,   494,    26,    27,   496,   500,   515,   517,
     519,   521,   529,   530,   532,   553,   557,   605,   875,   876,
     877,   878,   879,   620,   881,   882,   624,   625,    28,    29,
     632,   652,   653,   898,   899,   658,   654,   655,   896,   897,
     656,   657,   660,   901,   661,   903,   910,   911,   906,    30,
     696,    31,    32,    33,    34,    35,    36,   698,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   700,    37,   165,
     166,    38,   701,   704,   705,   706,   707,   708,   236,   709,
     710,   711,   712,   713,   167,   934,   714,   715,   716,   717,
     718,   948,   949,   719,   951,   952,   946,   947,   723,   725,
     726,   957,   958,   733,   734,   955,   735,   736,   737,   738,
     791,   794,   795,   796,   797,   799,   800,   739,   740,   801,
     741,   742,   743,   744,   745,   746,   747,   748,   749,   750,
     751,   752,   753,   755,   756,   757,   758,   759,   760,   761,
     762,   763,   764,   765,   768,   769,   770,   771,   772,   773,
     776,   778,   781,   782,   846,   783,   785,   786,   664,   665,
     666,   787,   802,   837,   791,   791,   791,   841,   842,   843,
     844,   845,   788,   790,   803,   849,   850,   804,   852,   667,
     668,   669,   805,   806,   807,   808,   809,   810,   670,   811,
     812,   813,   873,   814,   815,   816,   817,   671,   818,   672,
     819,   866,   820,   821,   885,   886,   887,   889,   822,   891,
     823,   375,   379,   825,   826,   682,   683,   827,   847,   848,
     865,   829,   867,   868,   869,   874,   870,   908,   909,   595,
     883,   596,   597,   598,   884,   914,   890,   918,   900,   902,
     920,   922,   904,  1083,   905,   912,   923,   913,   935,   907,
     791,   925,   919,   936,   937,   939,   926,   722,   799,   927,
     928,   929,  1092,  1093,  1094,   938,   930,   932,   933,   943,
     944,   945,  1095,   940,    13,   941,   950,   953,    14,   956,
     954,   959,   967,   960,   724,   560,   774,   775,   968,   990,
     969,   983,    15,    16,    17,   664,   665,   666,   970,   971,
     972,    18,    19,    20,    21,    22,   372,    23,   973,   974,
     975,   976,   977,   978,   979,   980,   667,   668,   669,   981,
     982,   985,   986,   987,   988,   670,   991,   922,   993,   989,
     994,   995,   996,   997,   671,   998,   672,   999,  1000,  1001,
      24,    25,  1002,  1003,  1004,  1005,  1006,  1007,   889,    26,
      27,  1008,   682,   683,  1009,  1010,  1011,    13,  1013,  1014,
    1015,    14,  1016,  1017,  1018,  1019,  1020,  1021,  1112,  1022,
    1023,  1024,  1025,    28,    29,    15,    16,    17,  1026,  1027,
    1028,   922,  1029,  1041,    18,    19,    20,    21,    22,  1042,
      23,  1043,  1044,  1045,    30,  1046,    31,    32,    33,    34,
      35,    36,   943,  1047,  1048,  1049,  1050,   481,  1051,  1053,
    1054,  1056,  1057,    37,   373,  1058,    38,  1059,  1060,  1061,
    1062,  1063,  1064,    24,    25,  1065,  1067,  1068,  1069,  1070,
    1071,  1072,    26,    27,  1073,  1074,  1075,  1076,  1077,  1078,
    1079,  1080,  1089,  1081,  1091,  1082,  1085,  1090,  1099,  1096,
    1097,  1098,  1100,  1101,  1102,  1103,    28,    29,  1104,  1105,
    1106,   777,  1107,  1109,  1110,  1111,   780,  1113,  1114,  1115,
    1116,  1118,  1119,  1120,    13,  1121,  1122,    30,    14,    31,
      32,    33,    34,    35,    36,  1131,  1132,  1133,  1134,  1135,
    1136,  1137,    15,    16,    17,  1138,    37,   330,  1139,    38,
    1140,    18,    19,    20,    21,    22,   372,    23,   368,   480,
    1012,   411,   824,  1066,   828,    13,   341,   528,   527,    14,
     495,   789,   493,   659,   662,   695,   349,   924,   880,     0,
     836,   931,   894,    15,    16,    17,     0,     0,     0,     0,
      24,    25,    18,    19,    20,    21,    22,     0,    23,    26,
      27,     0,     0,     0,   664,   665,   666,   720,     0,  1123,
    1124,  1125,  1126,  1127,   791,   791,     0,     0,     0,     0,
       0,     0,     0,    28,    29,   667,   668,   669,     0,     0,
       0,    24,    25,     0,   670,   961,     0,     0,     0,     0,
      26,    27,     0,   671,    30,   672,    31,    32,    33,    34,
      35,    36,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   682,   683,    37,    28,    29,    38,   829,     0,   855,
       0,   856,   857,   858,   611,   595,   612,   596,   597,   598,
       0,     0,     0,     0,     0,    30,     0,    31,    32,    33,
      34,    35,    36,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    37,     0,     0,    38,    71,    72,
      73,    74,     0,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
       0,     0,    92,    93,    94,     0,    95,    96,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    97,    98,    99,   100,   101,   102,     0,
       0,   103,   104,   105,   106,   107,   108,   109,     0,     0,
       0,     0,   563,     0,     0,     0,     0,     0,   633,     0,
       0,     0,     0,     0,     0,     0,   564,     0,   110,   565,
     566,   567,   568,     0,   569,   570,   571,   572,     0,     0,
       0,     0,     0,   111,   112,     0,     0,     0,   573,   574,
     575,   576,   577,     0,   634,     0,     0,     0,     0,     0,
       0,     0,   578,   579,   580,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   581,     0,   582,   583,   593,   594,   607,   608,
     609,   610,   563,   611,   595,   612,   596,   597,   598,     0,
       0,     0,     0,     0,     0,     0,   564,     0,     0,   565,
     566,   567,   568,     0,   569,   570,   571,   572,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   573,   574,
     575,   576,   577,     0,   606,     0,     0,     0,     0,     0,
       0,     0,   578,   579,   580,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   581,     0,   582,   583,   593,   594,   607,   608,
     609,   610,   563,   611,   595,   612,   596,   597,   598,     0,
       0,     0,     0,     0,     0,     0,   564,     0,     0,   565,
     566,   567,   568,     0,   569,   570,   571,   572,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   573,   574,
     575,   576,   577,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   578,   579,   580,     0,     0,     0,     0,     0,
       0,     0,   589,     0,   590,   591,   592,     0,     0,     0,
       0,     0,   581,     0,   582,   583,   593,   594,   563,     0,
       0,     0,     0,     0,   595,     0,   596,   597,   598,     0,
       0,     0,   564,     0,     0,   565,   566,   567,   568,     0,
     569,   570,   571,   572,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   573,   574,   575,   576,   577,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   578,   579,
     580,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   581,     0,
     582,   583,   563,     0,   607,   608,   609,   610,     0,   611,
     595,   612,   596,   597,   598,     0,   564,     0,     0,   565,
     566,   567,   568,     0,   569,   570,   571,   572,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   573,   574,
     575,   576,   577,     0,     0,     0,   563,     0,     0,     0,
       0,     0,   578,   579,   580,     0,     0,     0,     0,     0,
     564,     0,   586,   565,   566,   567,   568,     0,   569,   570,
     571,   572,   581,     0,   582,   583,     0,     0,     0,     0,
       0,     0,   573,   574,   575,   576,   577,   663,     0,     0,
       0,   664,   665,   666,     0,     0,   578,   579,   580,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   667,   668,   669,     0,   581,     0,   582,   583,
       0,   670,     0,     0,     0,     0,     0,     0,     0,     0,
     671,     0,   672,     0,     0,   673,     0,     0,     0,     0,
     674,   675,   676,   677,   678,   679,   680,   681,   682,   683,
       0,   684
};

static const yytype_int16 yycheck[] =
{
       1,     2,     3,     4,   496,   498,     7,     8,     9,   705,
     706,   707,   919,   473,   184,   475,   475,   194,   195,   196,
     197,   490,   199,    20,   201,   202,   479,   477,   497,   185,
     499,   516,    62,   518,   487,   721,   220,   487,   222,   223,
     868,   218,     3,     4,   149,   150,   531,    24,   225,    24,
      24,   127,   152,   129,     3,     4,     5,     6,     7,     8,
       9,    22,   152,    10,    11,    12,    13,    14,    15,    16,
      17,    18,     0,   471,    21,    22,     3,     4,     5,     6,
     133,   134,   469,   151,   471,   152,   473,   485,   475,   152,
      37,   152,   145,   152,   922,   131,   132,   152,   485,   148,
     149,   100,   101,   133,   134,    82,   155,    82,    82,    25,
     148,   149,   154,   151,   154,   145,     7,    33,    34,    35,
      36,   145,   146,   834,   835,   694,   695,   731,   732,   154,
     151,   287,   154,  1040,   154,   154,   154,   154,   154,   154,
     154,   601,   601,   154,   141,   142,   154,   154,   834,   835,
     154,   100,   154,   128,   128,   648,   154,   262,   263,   154,
     121,   122,   123,   124,   125,   126,    82,   617,   154,   622,
     154,   154,   154,   642,   154,   154,   177,   178,   179,   180,
     181,   130,   154,  1090,   100,   638,   154,   585,   638,   150,
     154,   192,   193,   154,   141,   142,   154,   198,   585,   154,
     154,   686,   154,   130,  1111,   206,   207,   692,   154,   694,
     695,   212,   213,   214,   601,   154,   154,   154,   703,   154,
     154,    24,    25,    26,    27,    28,    29,    30,    31,   154,
     154,   154,   154,    36,   694,   695,   154,   238,   239,   240,
     241,   154,   154,   154,   154,   246,   247,   417,   154,   153,
     251,   252,   253,   254,   255,   256,   257,   258,   259,   151,
     154,   753,    65,    66,    67,   152,   154,   268,   269,   270,
     271,   154,   154,   154,   154,   276,   277,   154,   279,   153,
     151,    84,   154,   151,    87,   154,   463,    75,    76,    77,
      78,    79,    80,    81,   154,   154,     5,   154,   154,   154,
       9,   154,   154,   154,   154,   154,    15,    16,   111,   154,
     154,    43,    44,    45,    23,    24,    25,   154,   154,   154,
     123,   154,   154,    32,    33,    34,    35,    36,   153,    38,
     151,    82,    64,    65,    66,   152,   145,   145,   141,   142,
     145,    73,   154,   145,   145,   346,   347,   145,   145,   145,
      82,   145,    84,   141,   142,   145,   145,   149,   145,   145,
     145,   145,    71,    72,   145,    74,   145,   145,   100,   101,
     145,    80,    81,   145,   106,   376,   108,   378,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   154,   153,
     155,   154,   154,   154,   154,   104,   105,   154,   153,   400,
     401,   402,   403,   153,   151,   154,    43,    44,    45,  1105,
    1106,   154,   154,   154,   153,   155,   125,   418,   127,   128,
     129,   130,   131,   132,   155,   155,   155,    64,    65,    66,
     155,   154,    11,   155,   155,   144,    73,   155,   147,   155,
     155,   155,   155,   155,   155,    82,   154,    84,    38,   155,
     155,   155,   155,    43,    44,    45,   155,    94,    95,    96,
     155,   462,   155,   100,   101,   155,   467,   155,   155,     5,
     155,   155,   155,     9,    64,    65,    66,   155,   155,    15,
      16,   155,   155,    73,    74,   155,   155,    23,    24,    25,
     155,   155,    82,   155,    84,   496,    32,    33,    34,    35,
      36,   155,    38,   155,   155,   155,   155,   155,   155,   155,
     100,   101,   155,   155,   155,   154,   106,   153,   108,   154,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     155,   155,   155,   155,   718,    71,    72,   155,    74,   155,
     155,   155,   155,   155,    80,    81,   143,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   557,   155,   735,   736,
     737,   738,   739,   155,   741,   742,   155,   155,   104,   105,
     155,   154,   154,   757,   758,   155,   154,   154,   755,   756,
     154,   154,   154,   760,   155,   762,   770,   771,   765,   125,
     155,   127,   128,   129,   130,   131,   132,   155,    11,    12,
      13,    14,    15,    16,    17,    18,    19,   155,   144,    22,
      23,   147,   155,   154,   154,   154,   154,   154,   117,   154,
     154,   154,   154,   154,    37,   802,   154,   154,   154,   154,
     154,   815,   816,   154,   818,   819,   813,   814,   155,   155,
     155,   825,   826,   154,   154,   822,   154,   154,   154,   154,
     651,   652,   653,   654,   655,   656,   657,   154,   154,   660,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   145,   155,   155,   155,    43,    44,
      45,   154,   154,   704,   705,   706,   707,   708,   709,   710,
     711,   712,   155,   155,   154,   716,   717,   154,   719,    64,
      65,    66,   154,   154,   154,   154,   154,   154,    73,   154,
     154,   154,   733,   154,   154,   154,   154,    82,   154,    84,
     154,   151,   154,   154,   745,   746,   747,   748,   154,   750,
     154,   752,   753,   154,   154,   100,   101,   154,   145,   145,
     153,   106,   154,   154,   154,   145,   155,   768,   769,   114,
     145,   116,   117,   118,   145,   776,   145,   778,   145,   145,
     781,   782,   145,   960,   145,   145,   787,   145,   145,   154,
     791,   155,   154,   145,   145,   145,   155,   555,   799,   155,
     155,   155,   986,   987,   988,   806,   155,   155,   155,   810,
     811,   812,   989,   145,     5,   145,   145,   145,     9,   145,
     821,   145,   155,   154,   557,   465,   617,   622,   155,   151,
     155,   154,    23,    24,    25,    43,    44,    45,   155,   155,
     155,    32,    33,    34,    35,    36,    37,    38,   155,   155,
     155,   155,   155,   155,   155,   155,    64,    65,    66,   155,
     155,   154,   154,   154,   154,    73,   867,   868,   869,   154,
     151,   155,   155,   155,    82,   155,    84,   155,   155,   155,
      71,    72,   155,   155,   155,   155,   155,   155,   889,    80,
      81,   155,   100,   101,   155,   155,   155,     5,   155,   155,
     155,     9,   155,   155,   155,   155,   155,   155,  1085,   155,
     155,   155,   155,   104,   105,    23,    24,    25,   155,   155,
     155,   922,   155,   155,    32,    33,    34,    35,    36,   155,
      38,   155,   155,   155,   125,   155,   127,   128,   129,   130,
     131,   132,   943,   155,   155,   155,   155,   362,   155,   155,
     155,   155,   155,   144,   145,   155,   147,   155,   155,   155,
     155,   155,   155,    71,    72,   155,   155,   155,   155,   155,
     155,   155,    80,    81,   155,   155,   155,   155,   155,   155,
     155,   155,   983,   155,   985,   155,   154,   154,   151,   155,
     155,   155,   154,   154,   154,   154,   104,   105,   154,   154,
     154,   630,   155,   155,   155,   154,   638,   155,   155,   155,
     155,   155,   155,   155,     5,   155,   155,   125,     9,   127,
     128,   129,   130,   131,   132,   155,   155,   155,   155,   155,
     155,   155,    23,    24,    25,   155,   144,   145,   155,   147,
     155,    32,    33,    34,    35,    36,    37,    38,   250,   361,
     889,   281,   686,   943,   692,     5,   229,   403,   402,     9,
     378,   648,   376,   511,   514,   522,   235,   791,   740,    -1,
     703,   799,   752,    23,    24,    25,    -1,    -1,    -1,    -1,
      71,    72,    32,    33,    34,    35,    36,    -1,    38,    80,
      81,    -1,    -1,    -1,    43,    44,    45,   552,    -1,  1100,
    1101,  1102,  1103,  1104,  1105,  1106,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   104,   105,    64,    65,    66,    -1,    -1,
      -1,    71,    72,    -1,    73,    74,    -1,    -1,    -1,    -1,
      80,    81,    -1,    82,   125,    84,   127,   128,   129,   130,
     131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   100,   101,   144,   104,   105,   147,   106,    -1,   108,
      -1,   110,   111,   112,   113,   114,   115,   116,   117,   118,
      -1,    -1,    -1,    -1,    -1,   125,    -1,   127,   128,   129,
     130,   131,   132,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   144,    -1,    -1,   147,    40,    41,
      42,    43,    -1,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      -1,    -1,    64,    65,    66,    -1,    68,    69,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    85,    86,    87,    88,    89,    90,    -1,
      -1,    93,    94,    95,    96,    97,    98,    99,    -1,    -1,
      -1,    -1,    32,    -1,    -1,    -1,    -1,    -1,    38,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    46,    -1,   120,    49,
      50,    51,    52,    -1,    54,    55,    56,    57,    -1,    -1,
      -1,    -1,    -1,   135,   136,    -1,    -1,    -1,    68,    69,
      70,    71,    72,    -1,    74,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    82,    83,    84,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   102,    -1,   104,   105,   106,   107,   108,   109,
     110,   111,    32,   113,   114,   115,   116,   117,   118,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    46,    -1,    -1,    49,
      50,    51,    52,    -1,    54,    55,    56,    57,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    68,    69,
      70,    71,    72,    -1,    74,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    82,    83,    84,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   102,    -1,   104,   105,   106,   107,   108,   109,
     110,   111,    32,   113,   114,   115,   116,   117,   118,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    46,    -1,    -1,    49,
      50,    51,    52,    -1,    54,    55,    56,    57,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    68,    69,
      70,    71,    72,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    82,    83,    84,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    92,    -1,    94,    95,    96,    -1,    -1,    -1,
      -1,    -1,   102,    -1,   104,   105,   106,   107,    32,    -1,
      -1,    -1,    -1,    -1,   114,    -1,   116,   117,   118,    -1,
      -1,    -1,    46,    -1,    -1,    49,    50,    51,    52,    -1,
      54,    55,    56,    57,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    68,    69,    70,    71,    72,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    82,    83,
      84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   102,    -1,
     104,   105,    32,    -1,   108,   109,   110,   111,    -1,   113,
     114,   115,   116,   117,   118,    -1,    46,    -1,    -1,    49,
      50,    51,    52,    -1,    54,    55,    56,    57,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    68,    69,
      70,    71,    72,    -1,    -1,    -1,    32,    -1,    -1,    -1,
      -1,    -1,    82,    83,    84,    -1,    -1,    -1,    -1,    -1,
      46,    -1,    92,    49,    50,    51,    52,    -1,    54,    55,
      56,    57,   102,    -1,   104,   105,    -1,    -1,    -1,    -1,
      -1,    -1,    68,    69,    70,    71,    72,    39,    -1,    -1,
      -1,    43,    44,    45,    -1,    -1,    82,    83,    84,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    64,    65,    66,    -1,   102,    -1,   104,   105,
      -1,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      82,    -1,    84,    -1,    -1,    87,    -1,    -1,    -1,    -1,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
      -1,   103
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,   100,   130,
     157,   158,   160,     5,     9,    23,    24,    25,    32,    33,
      34,    35,    36,    38,    71,    72,    80,    81,   104,   105,
     125,   127,   128,   129,   130,   131,   132,   144,   147,   161,
     320,   321,   162,   320,   163,   320,   165,   320,   152,   166,
     152,   174,   167,   320,   175,   320,   164,   320,     0,   151,
     152,   152,   152,   152,     3,     4,     5,     6,   130,   168,
     169,    40,    41,    42,    43,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    64,    65,    66,    68,    69,    85,    86,    87,
      88,    89,    90,    93,    94,    95,    96,    97,    98,    99,
     120,   135,   136,   282,   283,   176,   152,   159,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    21,    22,    37,
     141,   142,   181,   182,   183,   184,   190,   212,   219,   222,
       3,     4,    22,   121,   122,   123,   124,   125,   126,   150,
     154,   286,   287,   127,   129,   301,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    22,    23,    37,   230,   231,
     232,   237,   242,   264,   270,   271,   274,   154,   154,   154,
     154,   154,     7,   170,   171,   151,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   153,   151,
     152,   131,   132,   311,   312,   313,   158,   154,   154,   154,
     154,   154,   192,   191,   194,   193,   154,   154,   213,   153,
     151,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     286,   286,   148,   149,   151,   154,   154,   151,   154,   154,
     154,   154,   244,   243,   246,   245,   154,   154,   154,   154,
     153,   151,   320,   320,   320,   320,   320,   152,    82,   172,
     170,   168,   145,   145,   145,   145,   145,   145,   320,   320,
     133,   134,   145,   318,   318,   318,   318,   320,   318,    62,
     318,   319,   318,   318,   145,   145,   145,   320,   320,   145,
     145,   145,   145,   320,   320,   320,   145,   145,   145,   318,
     145,   320,   322,   322,   145,   322,   322,   145,   318,   145,
     145,   282,   100,   101,   177,   178,   154,   154,   153,   312,
     155,   185,   320,   187,   320,   197,   320,   195,   320,   154,
     154,   154,   154,   223,   320,   220,   320,   154,   181,   320,
     320,   320,    37,   145,   298,   320,   326,   299,   300,   320,
     325,   320,   320,   320,   320,   155,   286,   286,   153,   302,
     303,   153,   233,   320,   238,   320,   249,   320,   247,   320,
     154,   154,   154,   154,   320,   272,   320,   275,   276,   265,
     320,   230,   155,   155,   155,   155,   155,   168,   154,   153,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   154,   154,   153,   151,   320,   320,   155,   186,
     155,   188,   155,   198,   155,   196,   206,   207,   201,   202,
     206,   201,   155,   224,   155,   221,   214,   215,   292,   155,
     288,   155,   155,   298,   155,   299,   143,   289,   290,   291,
     155,    25,    33,    34,    35,    36,    82,   100,   306,   307,
     308,   309,    11,   304,   305,   155,   234,   155,   239,   155,
     250,   155,   248,   258,   320,   253,   320,   258,   253,   155,
     155,   273,   155,    24,    25,    26,    27,    28,    29,    30,
      31,    36,    65,    66,    67,    84,    87,   111,   123,   141,
     142,   277,   278,   155,   266,   170,   173,   320,   320,   318,
     177,   315,   320,    32,    46,    49,    50,    51,    52,    54,
      55,    56,    57,    68,    69,    70,    71,    72,    82,    83,
      84,   102,   104,   105,   227,   228,    92,   189,   227,    92,
      94,    95,    96,   106,   107,   114,   116,   117,   118,   179,
     199,   200,   211,   228,   199,   155,    74,   108,   109,   110,
     111,   113,   115,   179,   180,   205,   208,   209,   211,   228,
     155,   203,   204,   205,   155,   155,    20,   141,   142,   225,
     226,   227,   155,    38,    74,   205,   211,   216,   217,    24,
      82,   295,   296,   295,   325,   295,   128,   293,   294,   296,
     295,   154,   154,   154,   154,   154,   154,   154,   155,   308,
     154,   155,   304,    39,    43,    44,    45,    64,    65,    66,
      73,    82,    84,    87,    92,    93,    94,    95,    96,    97,
      98,    99,   100,   101,   103,   235,   236,   280,    94,    95,
      96,   240,   241,   280,   251,   251,   155,   259,   155,   254,
     155,   155,   279,   280,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     277,   267,   172,   155,   173,   155,   155,    24,    82,   128,
     316,   317,   314,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   227,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   199,   210,   154,   154,
     154,   154,   154,   154,   208,   203,   154,   225,   154,   218,
     216,   154,   154,   155,   295,   155,   155,   154,   155,   293,
     155,   320,   323,   324,   320,   320,   320,   320,   310,   320,
     320,   320,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   235,   154,   154,   154,   240,   106,
     179,   252,   263,   280,   260,   255,   279,   320,   323,   323,
     323,   320,   320,   320,   320,   320,   145,   145,   145,   320,
     320,   322,   320,    38,    74,   108,   110,   111,   112,   119,
     180,   256,   263,   268,   280,   153,   151,   154,   154,   154,
     155,   316,   316,   320,   145,   318,   318,   318,   318,   318,
     319,   318,   318,   145,   145,   320,   320,   320,   229,   320,
     145,   320,   145,   146,   326,   325,   318,   318,   322,   322,
     145,   318,   145,   318,   145,   145,   318,   154,   320,   320,
     322,   322,   145,   145,   320,    15,    16,    74,   320,   154,
     320,   297,   320,   320,   324,   155,   155,   155,   155,   155,
     155,   310,   155,   155,   318,   145,   145,   145,   320,   145,
     145,   145,   281,   320,   320,   320,   318,   318,   322,   322,
     145,   322,   322,   145,   320,   318,   145,   322,   322,   145,
     154,    74,   256,   261,   119,   256,   257,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   154,   269,   154,   154,   154,   154,   154,
     151,   320,   297,   320,   151,   155,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   229,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
      75,    76,    77,    78,    79,    80,    81,   141,   142,   284,
     285,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   284,   155,   155,   297,   155,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   281,   155,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155,   155,   155,   318,   262,   154,    15,    16,    74,   320,
     154,   320,   322,   322,   322,   318,   155,   155,   155,   151,
     154,   154,   154,   154,   154,   154,   154,   155,   284,   155,
     155,   154,   318,   155,   155,   155,   155,   284,   155,   155,
     155,   155,   155,   320,   320,   320,   320,   320,   323,   323,
     284,   155,   155,   155,   155,   155,   155,   155,   155,   155,
     155
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:

/* Line 1455 of yacc.c  */
#line 322 "cfg-grammar.y"
    { 
            if (last_include_file && !cfg_lex_process_include(last_include_file)) 
              { 
                free(last_include_file);
                last_include_file = NULL;
                YYERROR; 
              } 
            if (last_include_file)
              {
                free(last_include_file);
                last_include_file = NULL;
              }
          }
    break;

  case 6:

/* Line 1455 of yacc.c  */
#line 340 "cfg-grammar.y"
    { cfg_add_source(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 7:

/* Line 1455 of yacc.c  */
#line 341 "cfg-grammar.y"
    { cfg_add_dest(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 8:

/* Line 1455 of yacc.c  */
#line 342 "cfg-grammar.y"
    { cfg_add_connection(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 9:

/* Line 1455 of yacc.c  */
#line 343 "cfg-grammar.y"
    { cfg_add_filter(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 10:

/* Line 1455 of yacc.c  */
#line 344 "cfg-grammar.y"
    { cfg_add_parser(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 11:

/* Line 1455 of yacc.c  */
#line 345 "cfg-grammar.y"
    { cfg_add_rewrite(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 12:

/* Line 1455 of yacc.c  */
#line 346 "cfg-grammar.y"
    { cfg_add_template(configuration, (yyvsp[(2) - (2)].ptr)); }
    break;

  case 13:

/* Line 1455 of yacc.c  */
#line 347 "cfg-grammar.y"
    {  }
    break;

  case 14:

/* Line 1455 of yacc.c  */
#line 348 "cfg-grammar.y"
    {  }
    break;

  case 15:

/* Line 1455 of yacc.c  */
#line 352 "cfg-grammar.y"
    { (yyval.ptr) = log_source_group_new((yyvsp[(1) - (4)].cptr), (yyvsp[(3) - (4)].ptr)); free((yyvsp[(1) - (4)].cptr)); }
    break;

  case 16:

/* Line 1455 of yacc.c  */
#line 356 "cfg-grammar.y"
    { (yyval.ptr) = log_filter_rule_new((yyvsp[(1) - (5)].cptr), (yyvsp[(3) - (5)].node)); free((yyvsp[(1) - (5)].cptr)); }
    break;

  case 17:

/* Line 1455 of yacc.c  */
#line 360 "cfg-grammar.y"
    { (yyval.ptr) = log_parser_rule_new((yyvsp[(1) - (5)].cptr), (yyvsp[(3) - (5)].ptr)); free((yyvsp[(1) - (5)].cptr)); }
    break;

  case 18:

/* Line 1455 of yacc.c  */
#line 363 "cfg-grammar.y"
    { (yyval.ptr) = log_rewrite_rule_new((yyvsp[(1) - (4)].cptr), (yyvsp[(3) - (4)].ptr)); free((yyvsp[(1) - (4)].cptr)); }
    break;

  case 19:

/* Line 1455 of yacc.c  */
#line 366 "cfg-grammar.y"
    { (yyval.ptr) = log_dest_group_new((yyvsp[(1) - (4)].cptr), (yyvsp[(3) - (4)].ptr)); free((yyvsp[(1) - (4)].cptr)); }
    break;

  case 20:

/* Line 1455 of yacc.c  */
#line 370 "cfg-grammar.y"
    { LogPipeItem *pi = log_pipe_item_append_tail((yyvsp[(2) - (5)].ptr), (yyvsp[(3) - (5)].ptr)); (yyval.ptr) = log_connection_new(pi, (yyvsp[(4) - (5)].num)); }
    break;

  case 21:

/* Line 1455 of yacc.c  */
#line 374 "cfg-grammar.y"
    { last_include_file = (yyvsp[(1) - (1)].cptr); }
    break;

  case 22:

/* Line 1455 of yacc.c  */
#line 377 "cfg-grammar.y"
    { log_pipe_item_append((yyvsp[(1) - (3)].ptr), (yyvsp[(3) - (3)].ptr)); (yyval.ptr) = (yyvsp[(1) - (3)].ptr); }
    break;

  case 23:

/* Line 1455 of yacc.c  */
#line 378 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 24:

/* Line 1455 of yacc.c  */
#line 382 "cfg-grammar.y"
    { (yyval.ptr) = log_pipe_item_new(EP_SOURCE, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 25:

/* Line 1455 of yacc.c  */
#line 383 "cfg-grammar.y"
    { (yyval.ptr) = log_pipe_item_new(EP_FILTER, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 26:

/* Line 1455 of yacc.c  */
#line 384 "cfg-grammar.y"
    { (yyval.ptr) = log_pipe_item_new(EP_PARSER, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 27:

/* Line 1455 of yacc.c  */
#line 385 "cfg-grammar.y"
    { (yyval.ptr) = log_pipe_item_new(EP_REWRITE, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 28:

/* Line 1455 of yacc.c  */
#line 386 "cfg-grammar.y"
    { (yyval.ptr) = log_pipe_item_new(EP_DESTINATION, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 29:

/* Line 1455 of yacc.c  */
#line 390 "cfg-grammar.y"
    { log_pipe_item_append((yyvsp[(1) - (2)].ptr), (yyvsp[(2) - (2)].ptr)); (yyval.ptr) = (yyvsp[(1) - (2)].ptr); }
    break;

  case 30:

/* Line 1455 of yacc.c  */
#line 391 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 31:

/* Line 1455 of yacc.c  */
#line 395 "cfg-grammar.y"
    { LogPipeItem *pi = log_pipe_item_append_tail((yyvsp[(3) - (7)].ptr), (yyvsp[(4) - (7)].ptr)); (yyval.ptr) = log_pipe_item_new_ref(EP_PIPE, log_connection_new(pi, (yyvsp[(5) - (7)].num))); }
    break;

  case 32:

/* Line 1455 of yacc.c  */
#line 399 "cfg-grammar.y"
    { (yyval.num) = (yyvsp[(3) - (5)].num); }
    break;

  case 33:

/* Line 1455 of yacc.c  */
#line 400 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 34:

/* Line 1455 of yacc.c  */
#line 405 "cfg-grammar.y"
    { (yyval.num) = log_connection_lookup_flag((yyvsp[(1) - (2)].cptr)) | (yyvsp[(2) - (2)].num); free((yyvsp[(1) - (2)].cptr)); }
    break;

  case 35:

/* Line 1455 of yacc.c  */
#line 406 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 36:

/* Line 1455 of yacc.c  */
#line 411 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 37:

/* Line 1455 of yacc.c  */
#line 416 "cfg-grammar.y"
    {
	    last_template = log_template_new((yyvsp[(1) - (1)].cptr), NULL);
	    free((yyvsp[(1) - (1)].cptr));
	  }
    break;

  case 38:

/* Line 1455 of yacc.c  */
#line 420 "cfg-grammar.y"
    { (yyval.ptr) = last_template;  }
    break;

  case 41:

/* Line 1455 of yacc.c  */
#line 429 "cfg-grammar.y"
    { last_template->template = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); if (!cfg_check_template(last_template)) { YYERROR; } }
    break;

  case 42:

/* Line 1455 of yacc.c  */
#line 430 "cfg-grammar.y"
    { log_template_set_escape(last_template, (yyvsp[(3) - (4)].num)); }
    break;

  case 43:

/* Line 1455 of yacc.c  */
#line 434 "cfg-grammar.y"
    { last_sock_options->sndbuf = (yyvsp[(3) - (4)].num); }
    break;

  case 44:

/* Line 1455 of yacc.c  */
#line 435 "cfg-grammar.y"
    { last_sock_options->rcvbuf = (yyvsp[(3) - (4)].num); }
    break;

  case 45:

/* Line 1455 of yacc.c  */
#line 436 "cfg-grammar.y"
    { last_sock_options->broadcast = (yyvsp[(3) - (4)].num); }
    break;

  case 46:

/* Line 1455 of yacc.c  */
#line 437 "cfg-grammar.y"
    { last_sock_options->keepalive = (yyvsp[(3) - (4)].num); }
    break;

  case 48:

/* Line 1455 of yacc.c  */
#line 442 "cfg-grammar.y"
    { ((InetSocketOptions *) last_sock_options)->ttl = (yyvsp[(3) - (4)].num); }
    break;

  case 49:

/* Line 1455 of yacc.c  */
#line 443 "cfg-grammar.y"
    { ((InetSocketOptions *) last_sock_options)->tos = (yyvsp[(3) - (4)].num); }
    break;

  case 50:

/* Line 1455 of yacc.c  */
#line 447 "cfg-grammar.y"
    { if ((yyvsp[(1) - (3)].ptr)) {log_drv_append((yyvsp[(1) - (3)].ptr), (yyvsp[(3) - (3)].ptr)); log_drv_unref((yyvsp[(3) - (3)].ptr)); (yyval.ptr) = (yyvsp[(1) - (3)].ptr); } else { YYERROR; } }
    break;

  case 51:

/* Line 1455 of yacc.c  */
#line 448 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 52:

/* Line 1455 of yacc.c  */
#line 452 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 53:

/* Line 1455 of yacc.c  */
#line 453 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 54:

/* Line 1455 of yacc.c  */
#line 454 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 55:

/* Line 1455 of yacc.c  */
#line 455 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 56:

/* Line 1455 of yacc.c  */
#line 456 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 57:

/* Line 1455 of yacc.c  */
#line 457 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 58:

/* Line 1455 of yacc.c  */
#line 461 "cfg-grammar.y"
    { (yyval.ptr) = afinter_sd_new(); }
    break;

  case 59:

/* Line 1455 of yacc.c  */
#line 465 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 60:

/* Line 1455 of yacc.c  */
#line 466 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 61:

/* Line 1455 of yacc.c  */
#line 471 "cfg-grammar.y"
    {
	    last_driver = affile_sd_new((yyvsp[(1) - (1)].cptr), 0); 
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_reader_options = &((AFFileSourceDriver *) last_driver)->reader_options;
	  }
    break;

  case 62:

/* Line 1455 of yacc.c  */
#line 476 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 63:

/* Line 1455 of yacc.c  */
#line 481 "cfg-grammar.y"
    {
	    last_driver = affile_sd_new((yyvsp[(1) - (1)].cptr), AFFILE_PIPE); 
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_reader_options = &((AFFileSourceDriver *) last_driver)->reader_options;
	  }
    break;

  case 64:

/* Line 1455 of yacc.c  */
#line 486 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 65:

/* Line 1455 of yacc.c  */
#line 490 "cfg-grammar.y"
    { last_driver->optional = (yyvsp[(3) - (4)].num); }
    break;

  case 66:

/* Line 1455 of yacc.c  */
#line 491 "cfg-grammar.y"
    {}
    break;

  case 67:

/* Line 1455 of yacc.c  */
#line 495 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 68:

/* Line 1455 of yacc.c  */
#line 496 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 69:

/* Line 1455 of yacc.c  */
#line 497 "cfg-grammar.y"
    { last_addr_family = AF_INET; }
    break;

  case 70:

/* Line 1455 of yacc.c  */
#line 497 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 71:

/* Line 1455 of yacc.c  */
#line 498 "cfg-grammar.y"
    { last_addr_family = AF_INET; }
    break;

  case 72:

/* Line 1455 of yacc.c  */
#line 498 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 73:

/* Line 1455 of yacc.c  */
#line 499 "cfg-grammar.y"
    { last_addr_family = AF_INET6; }
    break;

  case 74:

/* Line 1455 of yacc.c  */
#line 499 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 75:

/* Line 1455 of yacc.c  */
#line 500 "cfg-grammar.y"
    { last_addr_family = AF_INET6; }
    break;

  case 76:

/* Line 1455 of yacc.c  */
#line 500 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 77:

/* Line 1455 of yacc.c  */
#line 505 "cfg-grammar.y"
    { 
	    last_driver = afunix_sd_new(
		(yyvsp[(1) - (1)].cptr),
		AFSOCKET_DGRAM | AFSOCKET_LOCAL); 
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_reader_options = &((AFSocketSourceDriver *) last_driver)->reader_options;
	    last_sock_options = &((AFUnixSourceDriver *) last_driver)->sock_options;
	  }
    break;

  case 78:

/* Line 1455 of yacc.c  */
#line 513 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 79:

/* Line 1455 of yacc.c  */
#line 518 "cfg-grammar.y"
    { 
	    last_driver = afunix_sd_new(
		(yyvsp[(1) - (1)].cptr),
		AFSOCKET_STREAM | AFSOCKET_KEEP_ALIVE | AFSOCKET_LOCAL);
	    free((yyvsp[(1) - (1)].cptr));
	    last_reader_options = &((AFSocketSourceDriver *) last_driver)->reader_options;
	    last_sock_options = &((AFUnixSourceDriver *) last_driver)->sock_options;
	  }
    break;

  case 80:

/* Line 1455 of yacc.c  */
#line 526 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 83:

/* Line 1455 of yacc.c  */
#line 536 "cfg-grammar.y"
    { afunix_sd_set_uid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 84:

/* Line 1455 of yacc.c  */
#line 537 "cfg-grammar.y"
    { afunix_sd_set_gid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 85:

/* Line 1455 of yacc.c  */
#line 538 "cfg-grammar.y"
    { afunix_sd_set_perm(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 86:

/* Line 1455 of yacc.c  */
#line 539 "cfg-grammar.y"
    { last_driver->optional = (yyvsp[(3) - (4)].num); }
    break;

  case 87:

/* Line 1455 of yacc.c  */
#line 540 "cfg-grammar.y"
    {}
    break;

  case 88:

/* Line 1455 of yacc.c  */
#line 541 "cfg-grammar.y"
    {}
    break;

  case 89:

/* Line 1455 of yacc.c  */
#line 542 "cfg-grammar.y"
    {}
    break;

  case 90:

/* Line 1455 of yacc.c  */
#line 547 "cfg-grammar.y"
    { 
	    last_driver = afinet_sd_new(last_addr_family,
			NULL, 514,
			AFSOCKET_DGRAM);
	    last_reader_options = &((AFSocketSourceDriver *) last_driver)->reader_options;
	    last_sock_options = &((AFInetSourceDriver *) last_driver)->sock_options.super;
	  }
    break;

  case 91:

/* Line 1455 of yacc.c  */
#line 554 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 95:

/* Line 1455 of yacc.c  */
#line 567 "cfg-grammar.y"
    { afinet_sd_set_localip(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 96:

/* Line 1455 of yacc.c  */
#line 568 "cfg-grammar.y"
    { afinet_sd_set_localip(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 97:

/* Line 1455 of yacc.c  */
#line 569 "cfg-grammar.y"
    { afinet_sd_set_localport(last_driver, (yyvsp[(3) - (4)].cptr), afinet_sd_get_proto_name(last_driver)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 98:

/* Line 1455 of yacc.c  */
#line 570 "cfg-grammar.y"
    { afinet_sd_set_localport(last_driver, (yyvsp[(3) - (4)].cptr), afinet_sd_get_proto_name(last_driver)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 101:

/* Line 1455 of yacc.c  */
#line 577 "cfg-grammar.y"
    { 
	    last_driver = afinet_sd_new(last_addr_family,
			NULL, 514,
			AFSOCKET_STREAM);
	    last_reader_options = &((AFSocketSourceDriver *) last_driver)->reader_options;
	    last_sock_options = &((AFInetSourceDriver *) last_driver)->sock_options.super;
	  }
    break;

  case 102:

/* Line 1455 of yacc.c  */
#line 584 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 106:

/* Line 1455 of yacc.c  */
#line 596 "cfg-grammar.y"
    {
#if ENABLE_SSL
	    last_tls_context = tls_context_new(TM_SERVER);
#endif
	  }
    break;

  case 107:

/* Line 1455 of yacc.c  */
#line 602 "cfg-grammar.y"
    { 
#if ENABLE_SSL
	    afsocket_sd_set_tls_context(last_driver, last_tls_context); 
#endif
          }
    break;

  case 108:

/* Line 1455 of yacc.c  */
#line 608 "cfg-grammar.y"
    {}
    break;

  case 109:

/* Line 1455 of yacc.c  */
#line 612 "cfg-grammar.y"
    { afsocket_sd_set_keep_alive(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 110:

/* Line 1455 of yacc.c  */
#line 613 "cfg-grammar.y"
    { afsocket_sd_set_max_connections(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 111:

/* Line 1455 of yacc.c  */
#line 617 "cfg-grammar.y"
    { last_addr_family = AF_INET; }
    break;

  case 112:

/* Line 1455 of yacc.c  */
#line 617 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 113:

/* Line 1455 of yacc.c  */
#line 622 "cfg-grammar.y"
    { 
	    last_driver = afinet_sd_new(last_addr_family,
			NULL, 601,
			AFSOCKET_STREAM | AFSOCKET_SYSLOG_PROTOCOL);
	    last_reader_options = &((AFSocketSourceDriver *) last_driver)->reader_options;
	    last_sock_options = &((AFInetSourceDriver *) last_driver)->sock_options.super;
	  }
    break;

  case 114:

/* Line 1455 of yacc.c  */
#line 629 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 118:

/* Line 1455 of yacc.c  */
#line 639 "cfg-grammar.y"
    { afinet_sd_set_transport(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 119:

/* Line 1455 of yacc.c  */
#line 640 "cfg-grammar.y"
    { afinet_sd_set_transport(last_driver, "tcp"); }
    break;

  case 120:

/* Line 1455 of yacc.c  */
#line 641 "cfg-grammar.y"
    { afinet_sd_set_transport(last_driver, "udp"); }
    break;

  case 121:

/* Line 1455 of yacc.c  */
#line 642 "cfg-grammar.y"
    { afinet_sd_set_transport(last_driver, "tls"); }
    break;

  case 122:

/* Line 1455 of yacc.c  */
#line 644 "cfg-grammar.y"
    {
#if ENABLE_SSL
	    last_tls_context = tls_context_new(TM_SERVER);
#endif
	  }
    break;

  case 123:

/* Line 1455 of yacc.c  */
#line 650 "cfg-grammar.y"
    { 
#if ENABLE_SSL
	    afsocket_sd_set_tls_context(last_driver, last_tls_context); 
#endif
          }
    break;

  case 124:

/* Line 1455 of yacc.c  */
#line 655 "cfg-grammar.y"
    {}
    break;

  case 125:

/* Line 1455 of yacc.c  */
#line 659 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 126:

/* Line 1455 of yacc.c  */
#line 664 "cfg-grammar.y"
    { 
	    last_driver = afprogram_sd_new((yyvsp[(1) - (1)].cptr)); 
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_reader_options = &((AFProgramSourceDriver *) last_driver)->reader_options;
	  }
    break;

  case 127:

/* Line 1455 of yacc.c  */
#line 669 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 128:

/* Line 1455 of yacc.c  */
#line 673 "cfg-grammar.y"
    {
#if ENABLE_SUN_STREAMS
}
    break;

  case 129:

/* Line 1455 of yacc.c  */
#line 676 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 130:

/* Line 1455 of yacc.c  */
#line 677 "cfg-grammar.y"
    {
#endif
}
    break;

  case 131:

/* Line 1455 of yacc.c  */
#line 684 "cfg-grammar.y"
    { 
#if ENABLE_SUN_STREAMS
	    last_driver = afstreams_sd_new((yyvsp[(1) - (1)].cptr)); 
	    free((yyvsp[(1) - (1)].cptr)); 
#endif
	  }
    break;

  case 132:

/* Line 1455 of yacc.c  */
#line 690 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 135:

/* Line 1455 of yacc.c  */
#line 699 "cfg-grammar.y"
    {
#if ENABLE_SUN_STREAMS
}
    break;

  case 136:

/* Line 1455 of yacc.c  */
#line 702 "cfg-grammar.y"
    { afstreams_sd_set_sundoor(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 137:

/* Line 1455 of yacc.c  */
#line 703 "cfg-grammar.y"
    {
#endif
}
    break;

  case 140:

/* Line 1455 of yacc.c  */
#line 714 "cfg-grammar.y"
    { last_reader_options->super.init_window_size = (yyvsp[(3) - (4)].num); }
    break;

  case 141:

/* Line 1455 of yacc.c  */
#line 715 "cfg-grammar.y"
    { last_reader_options->super.chain_hostnames = (yyvsp[(3) - (4)].num); }
    break;

  case 142:

/* Line 1455 of yacc.c  */
#line 716 "cfg-grammar.y"
    { last_reader_options->super.normalize_hostnames = (yyvsp[(3) - (4)].num); }
    break;

  case 143:

/* Line 1455 of yacc.c  */
#line 717 "cfg-grammar.y"
    { last_reader_options->super.keep_hostname = (yyvsp[(3) - (4)].num); }
    break;

  case 144:

/* Line 1455 of yacc.c  */
#line 718 "cfg-grammar.y"
    { last_reader_options->super.use_fqdn = (yyvsp[(3) - (4)].num); }
    break;

  case 145:

/* Line 1455 of yacc.c  */
#line 719 "cfg-grammar.y"
    { last_reader_options->super.use_dns = (yyvsp[(3) - (4)].num); }
    break;

  case 146:

/* Line 1455 of yacc.c  */
#line 720 "cfg-grammar.y"
    { last_reader_options->super.use_dns_cache = (yyvsp[(3) - (4)].num); }
    break;

  case 147:

/* Line 1455 of yacc.c  */
#line 721 "cfg-grammar.y"
    { last_reader_options->super.program_override = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 148:

/* Line 1455 of yacc.c  */
#line 722 "cfg-grammar.y"
    { last_reader_options->super.host_override = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 149:

/* Line 1455 of yacc.c  */
#line 723 "cfg-grammar.y"
    { gchar *p = strrchr((yyvsp[(3) - (4)].cptr), ':'); if (p) *p = 0; last_reader_options->super.program_override = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 150:

/* Line 1455 of yacc.c  */
#line 724 "cfg-grammar.y"
    { last_reader_options->recv_time_zone = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 151:

/* Line 1455 of yacc.c  */
#line 725 "cfg-grammar.y"
    { last_reader_options->check_hostname = (yyvsp[(3) - (4)].num); }
    break;

  case 152:

/* Line 1455 of yacc.c  */
#line 726 "cfg-grammar.y"
    { last_reader_options->options = (yyvsp[(3) - (4)].num); }
    break;

  case 153:

/* Line 1455 of yacc.c  */
#line 727 "cfg-grammar.y"
    { last_reader_options->msg_size = (yyvsp[(3) - (4)].num); }
    break;

  case 154:

/* Line 1455 of yacc.c  */
#line 728 "cfg-grammar.y"
    { last_reader_options->fetch_limit = (yyvsp[(3) - (4)].num); }
    break;

  case 155:

/* Line 1455 of yacc.c  */
#line 729 "cfg-grammar.y"
    { last_reader_options->padding = (yyvsp[(3) - (4)].num); }
    break;

  case 156:

/* Line 1455 of yacc.c  */
#line 730 "cfg-grammar.y"
    { last_reader_options->follow_freq = (long) ((yyvsp[(3) - (4)].fnum) * 1000); }
    break;

  case 157:

/* Line 1455 of yacc.c  */
#line 731 "cfg-grammar.y"
    { last_reader_options->follow_freq = ((yyvsp[(3) - (4)].num) * 1000); }
    break;

  case 158:

/* Line 1455 of yacc.c  */
#line 732 "cfg-grammar.y"
    { last_reader_options->super.keep_timestamp = (yyvsp[(3) - (4)].num); }
    break;

  case 159:

/* Line 1455 of yacc.c  */
#line 733 "cfg-grammar.y"
    { last_reader_options->text_encoding = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 160:

/* Line 1455 of yacc.c  */
#line 735 "cfg-grammar.y"
    {
	    if (last_reader_options->default_pri == 0xFFFF)
	      last_reader_options->default_pri = LOG_USER;
	    last_reader_options->default_pri = (last_reader_options->default_pri & ~7) | (yyvsp[(3) - (4)].num);
          }
    break;

  case 161:

/* Line 1455 of yacc.c  */
#line 741 "cfg-grammar.y"
    {
	    if (last_reader_options->default_pri == 0xFFFF)
	      last_reader_options->default_pri = LOG_NOTICE;
	    last_reader_options->default_pri = (last_reader_options->default_pri & 7) | (yyvsp[(3) - (4)].num);
          }
    break;

  case 162:

/* Line 1455 of yacc.c  */
#line 749 "cfg-grammar.y"
    { (yyval.num) = log_reader_options_lookup_flag((yyvsp[(1) - (2)].cptr)) | (yyvsp[(2) - (2)].num); free((yyvsp[(1) - (2)].cptr)); }
    break;

  case 163:

/* Line 1455 of yacc.c  */
#line 750 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 164:

/* Line 1455 of yacc.c  */
#line 755 "cfg-grammar.y"
    { log_drv_append((yyvsp[(1) - (3)].ptr), (yyvsp[(3) - (3)].ptr)); log_drv_unref((yyvsp[(3) - (3)].ptr)); (yyval.ptr) = (yyvsp[(1) - (3)].ptr); }
    break;

  case 165:

/* Line 1455 of yacc.c  */
#line 756 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 166:

/* Line 1455 of yacc.c  */
#line 760 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 167:

/* Line 1455 of yacc.c  */
#line 761 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 168:

/* Line 1455 of yacc.c  */
#line 762 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 169:

/* Line 1455 of yacc.c  */
#line 763 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 170:

/* Line 1455 of yacc.c  */
#line 764 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 171:

/* Line 1455 of yacc.c  */
#line 765 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 172:

/* Line 1455 of yacc.c  */
#line 767 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (1)].ptr); }
    break;

  case 173:

/* Line 1455 of yacc.c  */
#line 772 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 174:

/* Line 1455 of yacc.c  */
#line 777 "cfg-grammar.y"
    { 
	    last_driver = affile_dd_new((yyvsp[(1) - (1)].cptr), 0); 
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_writer_options = &((AFFileDestDriver *) last_driver)->writer_options;
	  }
    break;

  case 175:

/* Line 1455 of yacc.c  */
#line 783 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 179:

/* Line 1455 of yacc.c  */
#line 793 "cfg-grammar.y"
    { last_driver->optional = (yyvsp[(3) - (4)].num); }
    break;

  case 180:

/* Line 1455 of yacc.c  */
#line 794 "cfg-grammar.y"
    { affile_dd_set_file_uid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 181:

/* Line 1455 of yacc.c  */
#line 795 "cfg-grammar.y"
    { affile_dd_set_file_gid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 182:

/* Line 1455 of yacc.c  */
#line 796 "cfg-grammar.y"
    { affile_dd_set_file_perm(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 183:

/* Line 1455 of yacc.c  */
#line 797 "cfg-grammar.y"
    { affile_dd_set_dir_uid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 184:

/* Line 1455 of yacc.c  */
#line 798 "cfg-grammar.y"
    { affile_dd_set_dir_gid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 185:

/* Line 1455 of yacc.c  */
#line 799 "cfg-grammar.y"
    { affile_dd_set_dir_perm(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 186:

/* Line 1455 of yacc.c  */
#line 800 "cfg-grammar.y"
    { affile_dd_set_create_dirs(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 187:

/* Line 1455 of yacc.c  */
#line 801 "cfg-grammar.y"
    { affile_dd_set_overwrite_if_older(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 188:

/* Line 1455 of yacc.c  */
#line 802 "cfg-grammar.y"
    { affile_dd_set_fsync(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 189:

/* Line 1455 of yacc.c  */
#line 803 "cfg-grammar.y"
    { affile_dd_set_local_time_zone(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 190:

/* Line 1455 of yacc.c  */
#line 807 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 191:

/* Line 1455 of yacc.c  */
#line 812 "cfg-grammar.y"
    { 
	    last_driver = affile_dd_new((yyvsp[(1) - (1)].cptr), AFFILE_PIPE);
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_writer_options = &((AFFileDestDriver *) last_driver)->writer_options;
	    last_writer_options->flush_lines = 0;
	  }
    break;

  case 192:

/* Line 1455 of yacc.c  */
#line 818 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 196:

/* Line 1455 of yacc.c  */
#line 828 "cfg-grammar.y"
    { affile_dd_set_file_uid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 197:

/* Line 1455 of yacc.c  */
#line 829 "cfg-grammar.y"
    { affile_dd_set_file_gid(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 198:

/* Line 1455 of yacc.c  */
#line 830 "cfg-grammar.y"
    { affile_dd_set_file_perm(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 199:

/* Line 1455 of yacc.c  */
#line 834 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 200:

/* Line 1455 of yacc.c  */
#line 835 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 201:

/* Line 1455 of yacc.c  */
#line 836 "cfg-grammar.y"
    { last_addr_family = AF_INET; }
    break;

  case 202:

/* Line 1455 of yacc.c  */
#line 836 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 203:

/* Line 1455 of yacc.c  */
#line 837 "cfg-grammar.y"
    { last_addr_family = AF_INET; }
    break;

  case 204:

/* Line 1455 of yacc.c  */
#line 837 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 205:

/* Line 1455 of yacc.c  */
#line 838 "cfg-grammar.y"
    { last_addr_family = AF_INET6; }
    break;

  case 206:

/* Line 1455 of yacc.c  */
#line 838 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 207:

/* Line 1455 of yacc.c  */
#line 839 "cfg-grammar.y"
    { last_addr_family = AF_INET6; }
    break;

  case 208:

/* Line 1455 of yacc.c  */
#line 839 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(4) - (5)].ptr); }
    break;

  case 209:

/* Line 1455 of yacc.c  */
#line 844 "cfg-grammar.y"
    { 
	    last_driver = afunix_dd_new((yyvsp[(1) - (1)].cptr), AFSOCKET_DGRAM);
	    free((yyvsp[(1) - (1)].cptr));
	    last_writer_options = &((AFSocketDestDriver *) last_driver)->writer_options;
	    last_sock_options = &((AFUnixDestDriver *) last_driver)->sock_options;
	  }
    break;

  case 210:

/* Line 1455 of yacc.c  */
#line 850 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 211:

/* Line 1455 of yacc.c  */
#line 855 "cfg-grammar.y"
    { 
	    last_driver = afunix_dd_new((yyvsp[(1) - (1)].cptr), AFSOCKET_STREAM);
	    free((yyvsp[(1) - (1)].cptr));
	    last_writer_options = &((AFSocketDestDriver *) last_driver)->writer_options;
	    last_sock_options = &((AFUnixDestDriver *) last_driver)->sock_options;
	  }
    break;

  case 212:

/* Line 1455 of yacc.c  */
#line 861 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 218:

/* Line 1455 of yacc.c  */
#line 877 "cfg-grammar.y"
    { 
	    last_driver = afinet_dd_new(last_addr_family,
			(yyvsp[(1) - (1)].cptr), 514,
			AFSOCKET_DGRAM);
	    free((yyvsp[(1) - (1)].cptr));
	    last_writer_options = &((AFSocketDestDriver *) last_driver)->writer_options;
	    last_sock_options = &((AFInetDestDriver *) last_driver)->sock_options.super;
	  }
    break;

  case 219:

/* Line 1455 of yacc.c  */
#line 885 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 222:

/* Line 1455 of yacc.c  */
#line 895 "cfg-grammar.y"
    { afinet_dd_set_localip(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 223:

/* Line 1455 of yacc.c  */
#line 896 "cfg-grammar.y"
    { afinet_dd_set_localport(last_driver, (yyvsp[(3) - (4)].cptr), afinet_dd_get_proto_name(last_driver)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 224:

/* Line 1455 of yacc.c  */
#line 897 "cfg-grammar.y"
    { afinet_dd_set_destport(last_driver, (yyvsp[(3) - (4)].cptr), afinet_dd_get_proto_name(last_driver)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 225:

/* Line 1455 of yacc.c  */
#line 898 "cfg-grammar.y"
    { afinet_dd_set_destport(last_driver, (yyvsp[(3) - (4)].cptr), afinet_dd_get_proto_name(last_driver)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 230:

/* Line 1455 of yacc.c  */
#line 906 "cfg-grammar.y"
    { afinet_dd_set_spoof_source(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 231:

/* Line 1455 of yacc.c  */
#line 911 "cfg-grammar.y"
    { 
	    last_driver = afinet_dd_new(last_addr_family,
			(yyvsp[(1) - (1)].cptr), 514,
			AFSOCKET_STREAM); 
	    free((yyvsp[(1) - (1)].cptr));
	    last_writer_options = &((AFSocketDestDriver *) last_driver)->writer_options;
	    last_sock_options = &((AFInetDestDriver *) last_driver)->sock_options.super;
	  }
    break;

  case 232:

/* Line 1455 of yacc.c  */
#line 919 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 236:

/* Line 1455 of yacc.c  */
#line 930 "cfg-grammar.y"
    {
#if ENABLE_SSL
	    last_tls_context = tls_context_new(TM_CLIENT);
#endif
	  }
    break;

  case 237:

/* Line 1455 of yacc.c  */
#line 936 "cfg-grammar.y"
    { 
#if ENABLE_SSL
	    afsocket_dd_set_tls_context(last_driver, last_tls_context); 
#endif
          }
    break;

  case 238:

/* Line 1455 of yacc.c  */
#line 944 "cfg-grammar.y"
    { afsocket_dd_set_keep_alive(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 239:

/* Line 1455 of yacc.c  */
#line 949 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 240:

/* Line 1455 of yacc.c  */
#line 953 "cfg-grammar.y"
    {
            last_driver = afinet_dd_new(last_addr_family, (yyvsp[(1) - (1)].cptr), 601, AFSOCKET_STREAM | AFSOCKET_SYSLOG_PROTOCOL);
	    last_writer_options = &((AFSocketDestDriver *) last_driver)->writer_options;
	    last_sock_options = &((AFInetDestDriver *) last_driver)->sock_options.super;
	    free((yyvsp[(1) - (1)].cptr));
	  }
    break;

  case 241:

/* Line 1455 of yacc.c  */
#line 959 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 245:

/* Line 1455 of yacc.c  */
#line 970 "cfg-grammar.y"
    { afinet_dd_set_transport(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 246:

/* Line 1455 of yacc.c  */
#line 971 "cfg-grammar.y"
    { afinet_dd_set_transport(last_driver, "tcp"); }
    break;

  case 247:

/* Line 1455 of yacc.c  */
#line 972 "cfg-grammar.y"
    { afinet_dd_set_transport(last_driver, "udp"); }
    break;

  case 248:

/* Line 1455 of yacc.c  */
#line 973 "cfg-grammar.y"
    { afinet_dd_set_transport(last_driver, "tls"); }
    break;

  case 249:

/* Line 1455 of yacc.c  */
#line 974 "cfg-grammar.y"
    { afinet_dd_set_spoof_source(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 250:

/* Line 1455 of yacc.c  */
#line 976 "cfg-grammar.y"
    {
#if ENABLE_SSL
	    last_tls_context = tls_context_new(TM_CLIENT);
#endif
	  }
    break;

  case 251:

/* Line 1455 of yacc.c  */
#line 982 "cfg-grammar.y"
    { 
#if ENABLE_SSL
	    afsocket_dd_set_tls_context(last_driver, last_tls_context); 
#endif
          }
    break;

  case 252:

/* Line 1455 of yacc.c  */
#line 991 "cfg-grammar.y"
    { (yyval.ptr) = afuser_dd_new((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 253:

/* Line 1455 of yacc.c  */
#line 995 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 254:

/* Line 1455 of yacc.c  */
#line 1000 "cfg-grammar.y"
    { 
	    last_driver = afprogram_dd_new((yyvsp[(1) - (1)].cptr)); 
	    free((yyvsp[(1) - (1)].cptr)); 
	    last_writer_options = &((AFProgramDestDriver *) last_driver)->writer_options;
	  }
    break;

  case 255:

/* Line 1455 of yacc.c  */
#line 1005 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 256:

/* Line 1455 of yacc.c  */
#line 1011 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(3) - (4)].ptr); }
    break;

  case 257:

/* Line 1455 of yacc.c  */
#line 1016 "cfg-grammar.y"
    {
            #if ENABLE_SQL	
            last_driver = afsql_dd_new();
            #endif /* ENABLE_SQL */
          }
    break;

  case 258:

/* Line 1455 of yacc.c  */
#line 1021 "cfg-grammar.y"
    { (yyval.ptr) = last_driver; }
    break;

  case 261:

/* Line 1455 of yacc.c  */
#line 1030 "cfg-grammar.y"
    { 
#if ENABLE_SQL 
}
    break;

  case 262:

/* Line 1455 of yacc.c  */
#line 1033 "cfg-grammar.y"
    { afsql_dd_set_type(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 263:

/* Line 1455 of yacc.c  */
#line 1034 "cfg-grammar.y"
    { afsql_dd_set_host(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 264:

/* Line 1455 of yacc.c  */
#line 1035 "cfg-grammar.y"
    { afsql_dd_set_port(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 265:

/* Line 1455 of yacc.c  */
#line 1036 "cfg-grammar.y"
    { afsql_dd_set_user(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 266:

/* Line 1455 of yacc.c  */
#line 1037 "cfg-grammar.y"
    { afsql_dd_set_password(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 267:

/* Line 1455 of yacc.c  */
#line 1038 "cfg-grammar.y"
    { afsql_dd_set_database(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 268:

/* Line 1455 of yacc.c  */
#line 1039 "cfg-grammar.y"
    { afsql_dd_set_table(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 269:

/* Line 1455 of yacc.c  */
#line 1040 "cfg-grammar.y"
    { afsql_dd_set_columns(last_driver, (yyvsp[(3) - (4)].ptr)); }
    break;

  case 270:

/* Line 1455 of yacc.c  */
#line 1041 "cfg-grammar.y"
    { afsql_dd_set_indexes(last_driver, (yyvsp[(3) - (4)].ptr)); }
    break;

  case 271:

/* Line 1455 of yacc.c  */
#line 1042 "cfg-grammar.y"
    { afsql_dd_set_values(last_driver, (yyvsp[(3) - (4)].ptr)); }
    break;

  case 272:

/* Line 1455 of yacc.c  */
#line 1043 "cfg-grammar.y"
    { afsql_dd_set_mem_fifo_size(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 273:

/* Line 1455 of yacc.c  */
#line 1044 "cfg-grammar.y"
    { afsql_dd_set_disk_fifo_size(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 274:

/* Line 1455 of yacc.c  */
#line 1045 "cfg-grammar.y"
    { afsql_dd_set_frac_digits(last_driver, (yyvsp[(3) - (4)].num)); }
    break;

  case 275:

/* Line 1455 of yacc.c  */
#line 1046 "cfg-grammar.y"
    { afsql_dd_set_send_time_zone(last_driver,(yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 276:

/* Line 1455 of yacc.c  */
#line 1047 "cfg-grammar.y"
    { afsql_dd_set_local_time_zone(last_driver,(yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 277:

/* Line 1455 of yacc.c  */
#line 1048 "cfg-grammar.y"
    { afsql_dd_set_null_value(last_driver, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 278:

/* Line 1455 of yacc.c  */
#line 1050 "cfg-grammar.y"
    { 
#endif /* ENABLE_SQL */ 
}
    break;

  case 281:

/* Line 1455 of yacc.c  */
#line 1063 "cfg-grammar.y"
    { last_writer_options->options = (yyvsp[(3) - (4)].num); }
    break;

  case 282:

/* Line 1455 of yacc.c  */
#line 1064 "cfg-grammar.y"
    { last_writer_options->mem_fifo_size = (yyvsp[(3) - (4)].num); }
    break;

  case 283:

/* Line 1455 of yacc.c  */
#line 1065 "cfg-grammar.y"
    { last_writer_options->flush_lines = (yyvsp[(3) - (4)].num); }
    break;

  case 284:

/* Line 1455 of yacc.c  */
#line 1066 "cfg-grammar.y"
    { last_writer_options->flush_timeout = (yyvsp[(3) - (4)].num); }
    break;

  case 285:

/* Line 1455 of yacc.c  */
#line 1067 "cfg-grammar.y"
    { last_writer_options->suppress = (yyvsp[(3) - (4)].num); }
    break;

  case 286:

/* Line 1455 of yacc.c  */
#line 1068 "cfg-grammar.y"
    { 
	                                          last_writer_options->template = cfg_check_inline_template(configuration, (yyvsp[(3) - (4)].cptr));
                                                  if (!cfg_check_template(last_writer_options->template))
	                                            {
	                                              YYERROR;
	                                            }
	                                          free((yyvsp[(3) - (4)].cptr));
	                                        }
    break;

  case 287:

/* Line 1455 of yacc.c  */
#line 1076 "cfg-grammar.y"
    { log_writer_options_set_template_escape(last_writer_options, (yyvsp[(3) - (4)].num)); }
    break;

  case 288:

/* Line 1455 of yacc.c  */
#line 1077 "cfg-grammar.y"
    { last_writer_options->send_time_zone = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 289:

/* Line 1455 of yacc.c  */
#line 1078 "cfg-grammar.y"
    { last_writer_options->ts_format = cfg_ts_format_value((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 290:

/* Line 1455 of yacc.c  */
#line 1079 "cfg-grammar.y"
    { last_writer_options->frac_digits = (yyvsp[(3) - (4)].num); }
    break;

  case 291:

/* Line 1455 of yacc.c  */
#line 1080 "cfg-grammar.y"
    { last_writer_options->throttle = (yyvsp[(3) - (4)].num); }
    break;

  case 292:

/* Line 1455 of yacc.c  */
#line 1084 "cfg-grammar.y"
    { (yyval.num) = log_writer_options_lookup_flag((yyvsp[(1) - (2)].cptr)) | (yyvsp[(2) - (2)].num); free((yyvsp[(1) - (2)].cptr)); }
    break;

  case 293:

/* Line 1455 of yacc.c  */
#line 1085 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 294:

/* Line 1455 of yacc.c  */
#line 1090 "cfg-grammar.y"
    { (yyval.ptr) = (yyvsp[(1) - (3)].ptr); }
    break;

  case 295:

/* Line 1455 of yacc.c  */
#line 1091 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 296:

/* Line 1455 of yacc.c  */
#line 1095 "cfg-grammar.y"
    { configuration->mark_freq = (yyvsp[(3) - (4)].num); }
    break;

  case 297:

/* Line 1455 of yacc.c  */
#line 1096 "cfg-grammar.y"
    { configuration->stats_freq = (yyvsp[(3) - (4)].num); }
    break;

  case 298:

/* Line 1455 of yacc.c  */
#line 1097 "cfg-grammar.y"
    { configuration->stats_level = (yyvsp[(3) - (4)].num); }
    break;

  case 299:

/* Line 1455 of yacc.c  */
#line 1098 "cfg-grammar.y"
    { configuration->flush_lines = (yyvsp[(3) - (4)].num); }
    break;

  case 300:

/* Line 1455 of yacc.c  */
#line 1099 "cfg-grammar.y"
    { configuration->flush_timeout = (yyvsp[(3) - (4)].num); }
    break;

  case 301:

/* Line 1455 of yacc.c  */
#line 1100 "cfg-grammar.y"
    { configuration->chain_hostnames = (yyvsp[(3) - (4)].num); }
    break;

  case 302:

/* Line 1455 of yacc.c  */
#line 1101 "cfg-grammar.y"
    { configuration->normalize_hostnames = (yyvsp[(3) - (4)].num); }
    break;

  case 303:

/* Line 1455 of yacc.c  */
#line 1102 "cfg-grammar.y"
    { configuration->keep_hostname = (yyvsp[(3) - (4)].num); }
    break;

  case 304:

/* Line 1455 of yacc.c  */
#line 1103 "cfg-grammar.y"
    { configuration->check_hostname = (yyvsp[(3) - (4)].num); }
    break;

  case 305:

/* Line 1455 of yacc.c  */
#line 1104 "cfg-grammar.y"
    { cfg_bad_hostname_set(configuration, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 306:

/* Line 1455 of yacc.c  */
#line 1105 "cfg-grammar.y"
    { configuration->use_time_recvd = (yyvsp[(3) - (4)].num); }
    break;

  case 307:

/* Line 1455 of yacc.c  */
#line 1106 "cfg-grammar.y"
    { configuration->use_fqdn = (yyvsp[(3) - (4)].num); }
    break;

  case 308:

/* Line 1455 of yacc.c  */
#line 1107 "cfg-grammar.y"
    { configuration->use_dns = (yyvsp[(3) - (4)].num); }
    break;

  case 309:

/* Line 1455 of yacc.c  */
#line 1108 "cfg-grammar.y"
    { configuration->time_reopen = (yyvsp[(3) - (4)].num); }
    break;

  case 310:

/* Line 1455 of yacc.c  */
#line 1109 "cfg-grammar.y"
    { configuration->time_reap = (yyvsp[(3) - (4)].num); }
    break;

  case 311:

/* Line 1455 of yacc.c  */
#line 1111 "cfg-grammar.y"
    { 
		  configuration->time_sleep = (yyvsp[(3) - (4)].num); 
		  if ((yyvsp[(3) - (4)].num) > 500) 
		    { 
		      msg_notice("The value specified for time_sleep is too large", evt_tag_int("time_sleep", (yyvsp[(3) - (4)].num)), NULL);
		      configuration->time_sleep = 500;
		    }
		}
    break;

  case 312:

/* Line 1455 of yacc.c  */
#line 1119 "cfg-grammar.y"
    { configuration->log_fifo_size = (yyvsp[(3) - (4)].num); }
    break;

  case 313:

/* Line 1455 of yacc.c  */
#line 1120 "cfg-grammar.y"
    { configuration->log_iw_size = (yyvsp[(3) - (4)].num); }
    break;

  case 314:

/* Line 1455 of yacc.c  */
#line 1121 "cfg-grammar.y"
    { configuration->log_fetch_limit = (yyvsp[(3) - (4)].num); }
    break;

  case 315:

/* Line 1455 of yacc.c  */
#line 1122 "cfg-grammar.y"
    { configuration->log_msg_size = (yyvsp[(3) - (4)].num); }
    break;

  case 316:

/* Line 1455 of yacc.c  */
#line 1123 "cfg-grammar.y"
    { configuration->keep_timestamp = (yyvsp[(3) - (4)].num); }
    break;

  case 317:

/* Line 1455 of yacc.c  */
#line 1124 "cfg-grammar.y"
    { configuration->ts_format = cfg_ts_format_value((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 318:

/* Line 1455 of yacc.c  */
#line 1125 "cfg-grammar.y"
    { configuration->frac_digits = (yyvsp[(3) - (4)].num); }
    break;

  case 319:

/* Line 1455 of yacc.c  */
#line 1126 "cfg-grammar.y"
    { /* ignored */; }
    break;

  case 320:

/* Line 1455 of yacc.c  */
#line 1127 "cfg-grammar.y"
    { /* ignored */; }
    break;

  case 321:

/* Line 1455 of yacc.c  */
#line 1128 "cfg-grammar.y"
    { configuration->create_dirs = (yyvsp[(3) - (4)].num); }
    break;

  case 322:

/* Line 1455 of yacc.c  */
#line 1129 "cfg-grammar.y"
    { cfg_file_owner_set(configuration, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 323:

/* Line 1455 of yacc.c  */
#line 1130 "cfg-grammar.y"
    { cfg_file_group_set(configuration, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 324:

/* Line 1455 of yacc.c  */
#line 1131 "cfg-grammar.y"
    { cfg_file_perm_set(configuration, (yyvsp[(3) - (4)].num)); }
    break;

  case 325:

/* Line 1455 of yacc.c  */
#line 1132 "cfg-grammar.y"
    { cfg_dir_owner_set(configuration, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 326:

/* Line 1455 of yacc.c  */
#line 1133 "cfg-grammar.y"
    { cfg_dir_group_set(configuration, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 327:

/* Line 1455 of yacc.c  */
#line 1134 "cfg-grammar.y"
    { cfg_dir_perm_set(configuration, (yyvsp[(3) - (4)].num)); }
    break;

  case 328:

/* Line 1455 of yacc.c  */
#line 1135 "cfg-grammar.y"
    { configuration->use_dns_cache = (yyvsp[(3) - (4)].num); }
    break;

  case 329:

/* Line 1455 of yacc.c  */
#line 1136 "cfg-grammar.y"
    { configuration->dns_cache_size = (yyvsp[(3) - (4)].num); }
    break;

  case 330:

/* Line 1455 of yacc.c  */
#line 1137 "cfg-grammar.y"
    { configuration->dns_cache_expire = (yyvsp[(3) - (4)].num); }
    break;

  case 331:

/* Line 1455 of yacc.c  */
#line 1139 "cfg-grammar.y"
    { configuration->dns_cache_expire_failed = (yyvsp[(3) - (4)].num); }
    break;

  case 332:

/* Line 1455 of yacc.c  */
#line 1140 "cfg-grammar.y"
    { configuration->dns_cache_hosts = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 333:

/* Line 1455 of yacc.c  */
#line 1141 "cfg-grammar.y"
    { configuration->file_template_name = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 334:

/* Line 1455 of yacc.c  */
#line 1142 "cfg-grammar.y"
    { configuration->proto_template_name = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 335:

/* Line 1455 of yacc.c  */
#line 1143 "cfg-grammar.y"
    { configuration->recv_time_zone = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 336:

/* Line 1455 of yacc.c  */
#line 1144 "cfg-grammar.y"
    { configuration->send_time_zone = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 337:

/* Line 1455 of yacc.c  */
#line 1145 "cfg-grammar.y"
    { configuration->local_time_zone = g_strdup((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 340:

/* Line 1455 of yacc.c  */
#line 1155 "cfg-grammar.y"
    { 
#if ENABLE_SSL
}
    break;

  case 341:

/* Line 1455 of yacc.c  */
#line 1160 "cfg-grammar.y"
    { 
	    last_tls_context->verify_mode = tls_lookup_verify_mode((yyvsp[(3) - (4)].cptr)); 
            free((yyvsp[(3) - (4)].cptr)); 
          }
    break;

  case 342:

/* Line 1455 of yacc.c  */
#line 1165 "cfg-grammar.y"
    { 
	    last_tls_context->key_file = g_strdup((yyvsp[(3) - (4)].cptr)); 
            free((yyvsp[(3) - (4)].cptr));
          }
    break;

  case 343:

/* Line 1455 of yacc.c  */
#line 1170 "cfg-grammar.y"
    { 
	    last_tls_context->cert_file = g_strdup((yyvsp[(3) - (4)].cptr)); 
            free((yyvsp[(3) - (4)].cptr));
          }
    break;

  case 344:

/* Line 1455 of yacc.c  */
#line 1175 "cfg-grammar.y"
    { 
	    last_tls_context->ca_dir = g_strdup((yyvsp[(3) - (4)].cptr)); 
            free((yyvsp[(3) - (4)].cptr));
          }
    break;

  case 345:

/* Line 1455 of yacc.c  */
#line 1180 "cfg-grammar.y"
    { 
	    last_tls_context->crl_dir = g_strdup((yyvsp[(3) - (4)].cptr)); 
            free((yyvsp[(3) - (4)].cptr));
          }
    break;

  case 346:

/* Line 1455 of yacc.c  */
#line 1185 "cfg-grammar.y"
    { 
            tls_session_set_trusted_fingerprints(last_tls_context, (yyvsp[(3) - (4)].ptr)); 
          }
    break;

  case 347:

/* Line 1455 of yacc.c  */
#line 1189 "cfg-grammar.y"
    { 
            tls_session_set_trusted_dn(last_tls_context, (yyvsp[(3) - (4)].ptr)); 
          }
    break;

  case 348:

/* Line 1455 of yacc.c  */
#line 1192 "cfg-grammar.y"
    {
#endif
}
    break;

  case 349:

/* Line 1455 of yacc.c  */
#line 1200 "cfg-grammar.y"
    { (yyval.node) = (yyvsp[(1) - (1)].node); if (!(yyvsp[(1) - (1)].node)) return 1; }
    break;

  case 350:

/* Line 1455 of yacc.c  */
#line 1201 "cfg-grammar.y"
    { (yyvsp[(2) - (2)].node)->comp = !((yyvsp[(2) - (2)].node)->comp); (yyval.node) = (yyvsp[(2) - (2)].node); }
    break;

  case 351:

/* Line 1455 of yacc.c  */
#line 1202 "cfg-grammar.y"
    { (yyval.node) = fop_or_new((yyvsp[(1) - (3)].node), (yyvsp[(3) - (3)].node)); }
    break;

  case 352:

/* Line 1455 of yacc.c  */
#line 1203 "cfg-grammar.y"
    { (yyval.node) = fop_and_new((yyvsp[(1) - (3)].node), (yyvsp[(3) - (3)].node)); }
    break;

  case 353:

/* Line 1455 of yacc.c  */
#line 1204 "cfg-grammar.y"
    { (yyval.node) = (yyvsp[(2) - (3)].node); }
    break;

  case 354:

/* Line 1455 of yacc.c  */
#line 1208 "cfg-grammar.y"
    { (yyval.node) = filter_facility_new((yyvsp[(3) - (4)].num));  }
    break;

  case 355:

/* Line 1455 of yacc.c  */
#line 1209 "cfg-grammar.y"
    { (yyval.node) = filter_facility_new(0x80000000 | (yyvsp[(3) - (4)].num)); }
    break;

  case 356:

/* Line 1455 of yacc.c  */
#line 1210 "cfg-grammar.y"
    { (yyval.node) = filter_level_new((yyvsp[(3) - (4)].num)); }
    break;

  case 357:

/* Line 1455 of yacc.c  */
#line 1211 "cfg-grammar.y"
    { (yyval.node) = filter_call_new((yyvsp[(3) - (4)].cptr), configuration); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 358:

/* Line 1455 of yacc.c  */
#line 1212 "cfg-grammar.y"
    { (yyval.node) = filter_netmask_new((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 359:

/* Line 1455 of yacc.c  */
#line 1214 "cfg-grammar.y"
    { 
	    last_re_filter = (FilterRE *) filter_re_new(LOG_MESSAGE_BUILTIN_FIELD(PROGRAM)); 
          }
    break;

  case 360:

/* Line 1455 of yacc.c  */
#line 1218 "cfg-grammar.y"
    {
            if(!filter_re_set_regexp(last_re_filter, (yyvsp[(3) - (6)].cptr)))
              YYERROR;
            free((yyvsp[(3) - (6)].cptr)); 

            (yyval.node) = &last_re_filter->super;
          }
    break;

  case 361:

/* Line 1455 of yacc.c  */
#line 1226 "cfg-grammar.y"
    {
	    last_re_filter = (FilterRE *) filter_re_new(LOG_MESSAGE_BUILTIN_FIELD(HOST)); 
          }
    break;

  case 362:

/* Line 1455 of yacc.c  */
#line 1230 "cfg-grammar.y"
    {
            if(!filter_re_set_regexp(last_re_filter, (yyvsp[(3) - (6)].cptr)))
              YYERROR;
            free((yyvsp[(3) - (6)].cptr)); 
            
            (yyval.node) = &last_re_filter->super;
          }
    break;

  case 363:

/* Line 1455 of yacc.c  */
#line 1238 "cfg-grammar.y"
    { 
	    last_re_filter = (FilterRE *) filter_match_new(); 
	  }
    break;

  case 364:

/* Line 1455 of yacc.c  */
#line 1242 "cfg-grammar.y"
    {
            if(!filter_re_set_regexp(last_re_filter, (yyvsp[(3) - (6)].cptr)))
              YYERROR;
            free((yyvsp[(3) - (6)].cptr)); 
            (yyval.node) = &last_re_filter->super;
            
            if (last_re_filter->value_name == 0)
              {
                static gboolean warn_written = FALSE;
                
                if (!warn_written)
                  {
                    msg_warning("WARNING: the match() filter without the use of the value() option is deprecated and hinders performance, please update your configuration",
                                NULL);
                    warn_written = TRUE;
                  }
              }
          }
    break;

  case 365:

/* Line 1455 of yacc.c  */
#line 1261 "cfg-grammar.y"
    {
	    last_re_filter = (FilterRE *) filter_re_new(LOG_MESSAGE_BUILTIN_FIELD(MESSAGE)); 
          }
    break;

  case 366:

/* Line 1455 of yacc.c  */
#line 1265 "cfg-grammar.y"
    {
            if(!filter_re_set_regexp(last_re_filter, (yyvsp[(3) - (6)].cptr)))
              YYERROR;
	    free((yyvsp[(3) - (6)].cptr)); 
            (yyval.node) = &last_re_filter->super;
          }
    break;

  case 367:

/* Line 1455 of yacc.c  */
#line 1272 "cfg-grammar.y"
    {
	    last_re_filter = (FilterRE *) filter_re_new(LOG_MESSAGE_BUILTIN_FIELD(SOURCE)); 
            filter_re_set_matcher(last_re_filter, log_matcher_string_new());
          }
    break;

  case 368:

/* Line 1455 of yacc.c  */
#line 1277 "cfg-grammar.y"
    {
            if(!filter_re_set_regexp(last_re_filter, (yyvsp[(3) - (6)].cptr)))
              YYERROR;
	    free((yyvsp[(3) - (6)].cptr)); 
            (yyval.node) = &last_re_filter->super;
          }
    break;

  case 372:

/* Line 1455 of yacc.c  */
#line 1292 "cfg-grammar.y"
    { last_re_filter->value_name = log_msg_translate_value_name((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 375:

/* Line 1455 of yacc.c  */
#line 1302 "cfg-grammar.y"
    { 
            filter_re_set_matcher(last_re_filter, log_matcher_new((yyvsp[(3) - (4)].cptr)));
            free((yyvsp[(3) - (4)].cptr)); 
          }
    break;

  case 376:

/* Line 1455 of yacc.c  */
#line 1306 "cfg-grammar.y"
    { filter_re_set_flags(last_re_filter, (yyvsp[(3) - (4)].num)); }
    break;

  case 377:

/* Line 1455 of yacc.c  */
#line 1310 "cfg-grammar.y"
    { (yyval.num) = log_matcher_lookup_flag((yyvsp[(1) - (2)].cptr)) | (yyvsp[(2) - (2)].num); free((yyvsp[(1) - (2)].cptr)); }
    break;

  case 378:

/* Line 1455 of yacc.c  */
#line 1311 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 379:

/* Line 1455 of yacc.c  */
#line 1316 "cfg-grammar.y"
    { (yyval.num) = (1 << ((yyvsp[(1) - (2)].num) >> 3)) | (yyvsp[(2) - (2)].num); }
    break;

  case 380:

/* Line 1455 of yacc.c  */
#line 1317 "cfg-grammar.y"
    { (yyval.num) = (1 << ((yyvsp[(1) - (1)].num) >> 3)); }
    break;

  case 381:

/* Line 1455 of yacc.c  */
#line 1321 "cfg-grammar.y"
    { (yyval.num) = (yyvsp[(1) - (2)].num) | (yyvsp[(2) - (2)].num); }
    break;

  case 382:

/* Line 1455 of yacc.c  */
#line 1322 "cfg-grammar.y"
    { (yyval.num) = (yyvsp[(1) - (1)].num); }
    break;

  case 383:

/* Line 1455 of yacc.c  */
#line 1327 "cfg-grammar.y"
    { 
	    (yyval.num) = syslog_make_range((yyvsp[(1) - (3)].num), (yyvsp[(3) - (3)].num));
	  }
    break;

  case 384:

/* Line 1455 of yacc.c  */
#line 1331 "cfg-grammar.y"
    { 
	    (yyval.num) = 1 << (yyvsp[(1) - (1)].num);
	  }
    break;

  case 385:

/* Line 1455 of yacc.c  */
#line 1339 "cfg-grammar.y"
    { 
            last_parser = (LogParser *) log_csv_parser_new(); 
          }
    break;

  case 386:

/* Line 1455 of yacc.c  */
#line 1343 "cfg-grammar.y"
    { (yyval.ptr) = last_parser; }
    break;

  case 387:

/* Line 1455 of yacc.c  */
#line 1345 "cfg-grammar.y"
    {
            last_parser = (LogParser *) log_db_parser_new();
          }
    break;

  case 388:

/* Line 1455 of yacc.c  */
#line 1349 "cfg-grammar.y"
    { (yyval.ptr) = last_parser; }
    break;

  case 391:

/* Line 1455 of yacc.c  */
#line 1359 "cfg-grammar.y"
    { log_db_parser_set_db_file(((LogDBParser *) last_parser), (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 393:

/* Line 1455 of yacc.c  */
#line 1364 "cfg-grammar.y"
    { log_column_parser_set_columns((LogColumnParser *) last_parser, (yyvsp[(3) - (4)].ptr)); }
    break;

  case 394:

/* Line 1455 of yacc.c  */
#line 1368 "cfg-grammar.y"
    { 
                                                  LogTemplate *template = cfg_check_inline_template(configuration, (yyvsp[(3) - (4)].cptr));
                                                  if (!cfg_check_template(template))
                                                    {
                                                      YYERROR;
                                                    }
                                                  log_parser_set_template(last_parser, template); 
                                                  free((yyvsp[(3) - (4)].cptr)); 
                                                }
    break;

  case 398:

/* Line 1455 of yacc.c  */
#line 1387 "cfg-grammar.y"
    { log_csv_parser_set_flags((LogColumnParser *) last_parser, (yyvsp[(3) - (4)].num)); }
    break;

  case 399:

/* Line 1455 of yacc.c  */
#line 1388 "cfg-grammar.y"
    { log_csv_parser_set_delimiters((LogColumnParser *) last_parser, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 400:

/* Line 1455 of yacc.c  */
#line 1389 "cfg-grammar.y"
    { log_csv_parser_set_quotes((LogColumnParser *) last_parser, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 401:

/* Line 1455 of yacc.c  */
#line 1390 "cfg-grammar.y"
    { log_csv_parser_set_quote_pairs((LogColumnParser *) last_parser, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 402:

/* Line 1455 of yacc.c  */
#line 1391 "cfg-grammar.y"
    { log_csv_parser_set_null_value((LogColumnParser *) last_parser, (yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 403:

/* Line 1455 of yacc.c  */
#line 1395 "cfg-grammar.y"
    { (yyval.num) = log_csv_parser_lookup_flag((yyvsp[(1) - (2)].cptr)) | (yyvsp[(2) - (2)].num); free((yyvsp[(1) - (2)].cptr)); }
    break;

  case 404:

/* Line 1455 of yacc.c  */
#line 1396 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 405:

/* Line 1455 of yacc.c  */
#line 1400 "cfg-grammar.y"
    { (yyval.ptr) = g_list_reverse((yyvsp[(1) - (1)].ptr)); }
    break;

  case 406:

/* Line 1455 of yacc.c  */
#line 1404 "cfg-grammar.y"
    { (yyval.ptr) = g_list_append((yyvsp[(2) - (2)].ptr), (yyvsp[(1) - (2)].ptr)); }
    break;

  case 407:

/* Line 1455 of yacc.c  */
#line 1405 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 408:

/* Line 1455 of yacc.c  */
#line 1410 "cfg-grammar.y"
    { 
            last_rewrite = log_rewrite_subst_new((yyvsp[(4) - (4)].cptr)); 
            free((yyvsp[(4) - (4)].cptr));  
          }
    break;

  case 409:

/* Line 1455 of yacc.c  */
#line 1415 "cfg-grammar.y"
    { 
            if(!log_rewrite_set_regexp(last_rewrite, (yyvsp[(3) - (8)].cptr)))
              YYERROR;
            free((yyvsp[(3) - (8)].cptr));
            (yyval.ptr) = last_rewrite; 
          }
    break;

  case 410:

/* Line 1455 of yacc.c  */
#line 1422 "cfg-grammar.y"
    {
            last_rewrite = log_rewrite_set_new((yyvsp[(3) - (3)].cptr)); 
            free((yyvsp[(3) - (3)].cptr));
          }
    break;

  case 411:

/* Line 1455 of yacc.c  */
#line 1426 "cfg-grammar.y"
    { (yyval.ptr) = last_rewrite; }
    break;

  case 414:

/* Line 1455 of yacc.c  */
#line 1435 "cfg-grammar.y"
    { last_rewrite->value_name = log_msg_translate_value_name((yyvsp[(3) - (4)].cptr)); free((yyvsp[(3) - (4)].cptr)); }
    break;

  case 415:

/* Line 1455 of yacc.c  */
#line 1437 "cfg-grammar.y"
    { 
            if (strcmp((yyvsp[(3) - (4)].cptr), "glob") == 0)
              {
                msg_error("Rewrite rules do not support glob expressions",
                          NULL);
                YYERROR;
              }
            log_rewrite_set_matcher(last_rewrite, log_matcher_new((yyvsp[(3) - (4)].cptr)));
            free((yyvsp[(3) - (4)].cptr)); 
          }
    break;

  case 416:

/* Line 1455 of yacc.c  */
#line 1447 "cfg-grammar.y"
    { log_rewrite_set_flags(last_rewrite, (yyvsp[(3) - (4)].num)); }
    break;

  case 417:

/* Line 1455 of yacc.c  */
#line 1451 "cfg-grammar.y"
    { (yyval.num) = 1; }
    break;

  case 418:

/* Line 1455 of yacc.c  */
#line 1452 "cfg-grammar.y"
    { (yyval.num) = 0; }
    break;

  case 419:

/* Line 1455 of yacc.c  */
#line 1453 "cfg-grammar.y"
    { (yyval.num) = (yyvsp[(1) - (1)].num); }
    break;

  case 420:

/* Line 1455 of yacc.c  */
#line 1457 "cfg-grammar.y"
    { (yyval.num) = (yyvsp[(1) - (1)].num); }
    break;

  case 421:

/* Line 1455 of yacc.c  */
#line 1458 "cfg-grammar.y"
    { (yyval.num) = 2; }
    break;

  case 424:

/* Line 1455 of yacc.c  */
#line 1464 "cfg-grammar.y"
    { (yyval.cptr) = cfg_lex_get_keyword_string((yyvsp[(1) - (1)].token)); }
    break;

  case 449:

/* Line 1455 of yacc.c  */
#line 1496 "cfg-grammar.y"
    { (yyval.cptr) = (yyvsp[(1) - (1)].cptr); }
    break;

  case 450:

/* Line 1455 of yacc.c  */
#line 1497 "cfg-grammar.y"
    { char buf[32]; snprintf(buf, sizeof(buf), "%" G_GINT64_FORMAT, (yyvsp[(1) - (1)].num)); (yyval.cptr) = strdup(buf); }
    break;

  case 451:

/* Line 1455 of yacc.c  */
#line 1501 "cfg-grammar.y"
    { (yyval.ptr) = g_list_reverse((yyvsp[(1) - (1)].ptr)); }
    break;

  case 452:

/* Line 1455 of yacc.c  */
#line 1505 "cfg-grammar.y"
    { (yyval.ptr) = g_list_append((yyvsp[(2) - (2)].ptr), g_strdup((yyvsp[(1) - (2)].cptr))); free((yyvsp[(1) - (2)].cptr)); }
    break;

  case 453:

/* Line 1455 of yacc.c  */
#line 1506 "cfg-grammar.y"
    { (yyval.ptr) = NULL; }
    break;

  case 454:

/* Line 1455 of yacc.c  */
#line 1511 "cfg-grammar.y"
    {
	    /* return the numeric value of the "level" */
	    int n = syslog_name_lookup_level_by_name((yyvsp[(1) - (1)].cptr));
	    if (n == -1)
	      {
	        msg_error("Unknown priority level",
                          evt_tag_str("priority", (yyvsp[(1) - (1)].cptr)),
                          NULL);
	        YYERROR;
	      }
	    free((yyvsp[(1) - (1)].cptr));
            (yyval.num) = n;
	  }
    break;

  case 455:

/* Line 1455 of yacc.c  */
#line 1528 "cfg-grammar.y"
    {
            /* return the numeric value of facility */
	    int n = syslog_name_lookup_facility_by_name((yyvsp[(1) - (1)].cptr));
	    if (n == -1)
	      {
	        msg_error("Unknown facility",
	                  evt_tag_str("facility", (yyvsp[(1) - (1)].cptr)),
	                  NULL);
                YYERROR;
	      }
	    free((yyvsp[(1) - (1)].cptr));
	    (yyval.num) = n;
	  }
    break;

  case 456:

/* Line 1455 of yacc.c  */
#line 1541 "cfg-grammar.y"
    { (yyval.num) = LOG_SYSLOG; }
    break;



/* Line 1455 of yacc.c  */
#line 5740 "cfg-grammar.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1675 of yacc.c  */
#line 1545 "cfg-grammar.y"


extern int linenum;

void 
yyerror(char *msg)
{
  fprintf(stderr, "%s in %s at line %d.\n\n"
                  "syslog-ng documentation: http://www.balabit.com/support/documentation/?product=syslog-ng\n"
                  "mailing list: https://lists.balabit.hu/mailman/listinfo/syslog-ng\n", msg, cfg_lex_get_current_file(), cfg_lex_get_current_lineno());
}


