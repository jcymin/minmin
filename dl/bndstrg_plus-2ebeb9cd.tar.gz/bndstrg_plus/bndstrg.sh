if ps | grep bndstrg; then
	exit 0;
else
	bndstrg
fi
